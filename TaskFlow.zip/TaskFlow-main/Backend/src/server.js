import http from "http";
import dotenv from "dotenv";
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import app from "./app.js";
import { connectDB } from "./config/db.js";
import { initSocket } from "./services/socketService.js";

// Get the directory name of the current module
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load .env from the Backend root directory (one level up from src/)
dotenv.config({ path: join(__dirname, '..', '.env') });

console.log('[Server] Environment loaded. EMAIL_USER:', process.env.EMAIL_USER ? 'Set' : 'Missing');

const PORT = process.env.PORT || 4000;

const startServer = async () => {
  try {
    await connectDB();
    const server = http.createServer(app);
    await initSocket(server);
    server.listen(PORT, () => {
      console.info(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error("Failed to start server", error);
    process.exit(1);
  }
};

if (process.env.NODE_ENV !== "test") {
  startServer();
}

export default startServer;
