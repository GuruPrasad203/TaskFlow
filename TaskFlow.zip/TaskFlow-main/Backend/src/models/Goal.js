import mongoose from "mongoose";

const goalStatuses = ["active", "completed", "archived"];

const goalSchema = new mongoose.Schema(
  {
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    title: {
      type: String,
      required: true,
      trim: true,
      maxlength: 200,
    },
    description: {
      type: String,
      trim: true,
    },
    status: {
      type: String,
      enum: goalStatuses,
      default: "active",
    },
    dueDate: {
      type: Date,
    },
    progress: {
      type: Number,
      default: 0,
      min: 0,
      max: 100,
    },
    tasks: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Task",
      },
    ],
    metadata: {
      type: Map,
      of: mongoose.Schema.Types.Mixed,
    },
    executionLogs: {
      type: [
        {
          iteration: Number,
          action: String,
          result: mongoose.Schema.Types.Mixed,
          reasoning: String,
          timestamp: { type: Date, default: Date.now },
        },
      ],
      default: [],
    },
    finalSynthesis: {
      type: mongoose.Schema.Types.Mixed,
    },
    completedAt: {
      type: Date,
    },
  },
  { timestamps: true }
);

goalSchema.methods.markCompletedIfDone = function markCompletedIfDone() {
  if (this.progress >= 100 && this.status !== "completed") {
    this.status = "completed";
  }
};

export default mongoose.model("Goal", goalSchema);
