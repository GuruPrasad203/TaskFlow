import mongoose from "mongoose";
import { updateGoalProgress } from "../utils/goalProgress.js";

const taskStatuses = ["pending", "in-progress", "completed", "blocked"];

const taskSchema = new mongoose.Schema(
  {
    goal: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Goal",
      required: true,
    },
    title: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
    },
    status: {
      type: String,
      enum: taskStatuses,
      default: "pending",
    },
    dueDate: {
      type: Date,
    },
    completedAt: {
      type: Date,
    },
    metadata: {
      type: Map,
      of: mongoose.Schema.Types.Mixed,
    },
    executionLog: {
      type: [
        {
          ranAt: { type: Date, default: Date.now },
          notes: String,
          output: mongoose.Schema.Types.Mixed,
        },
      ],
      default: [],
    },
  },
  { timestamps: true }
);

const recomputeProgress = async function recomputeProgress(doc) {
  if (!doc?.goal) return;
  await updateGoalProgress(doc.goal);
};

const autoComplete = function autoComplete(next) {
  if (this.isModified("status") && this.get("status") === "completed") {
    this.set("completedAt", this.get("completedAt") || new Date());
  }
  next();
};

taskSchema.pre("save", autoComplete);
taskSchema.post("save", recomputeProgress);
taskSchema.post("remove", recomputeProgress);
taskSchema.post("deleteOne", { document: true, query: false }, recomputeProgress);

taskSchema.methods.appendExecutionLog = function appendExecutionLog(entry) {
  this.executionLog.push(entry);
  return this.save();
};

export default mongoose.model("Task", taskSchema);
