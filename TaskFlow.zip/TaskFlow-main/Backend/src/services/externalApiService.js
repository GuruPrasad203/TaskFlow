import axios from "axios";

const toTitleCase = (value = "") =>
  value
    .toString()
    .split(/\s+/)
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")
    .trim();

const buildQueryString = (params = {}) =>
  Object.entries(params)
    .filter(([, value]) => value !== undefined && value !== null)
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
    .join("&");

export const googleSearch = async (query) => {
  const endpoint = process.env.GOOGLE_SEARCH_ENDPOINT;
  const apiKey = process.env.GOOGLE_SEARCH_API_KEY;
  const cx = process.env.GOOGLE_SEARCH_ENGINE_ID;

  if (!endpoint || !apiKey || !cx) {
    throw new Error("Google search API not configured");
  }

  const url = `${endpoint}?${buildQueryString({ key: apiKey, cx, q: query })}`;
  const { data } = await axios.get(url);
  return data;
};

const buildFallbackWeather = ({ city, lat, lon }, reason) => {
  const locationLabel = city || (lat && lon ? `${lat},${lon}` : "Destination");
  const normalizedLocation = toTitleCase(locationLabel);

  return {
    location: normalizedLocation,
    overview: `Seasonal conditions expected in ${normalizedLocation}. Detailed weather data unavailable (${reason}).`,
    details: [
      { day: "Day 1", condition: "Mild", highC: 30, lowC: 22 },
      { day: "Day 2", condition: "Pleasant", highC: 29, lowC: 21 },
    ],
    source: "fallback",
  };
};

const buildRequestKey = ({ city, lat, lon }) => {
  if (city) return `city:${city.toString().trim().toLowerCase()}`;
  if (lat !== undefined && lon !== undefined) return `coords:${lat},${lon}`;
  return "generic";
};

const WEATHER_CACHE_TTL = Number(process.env.WEATHER_CACHE_TTL_MS || 1000 * 60 * 30);
const weatherCache = new Map();
let weatherApiDisabled = false;
let weatherDisableReason = "weather API disabled";

const getCachedWeather = (key) => {
  if (!key) return null;
  const payload = weatherCache.get(key);
  if (!payload) return null;
  if (Date.now() - payload.timestamp > WEATHER_CACHE_TTL) {
    weatherCache.delete(key);
    return null;
  }
  return payload.data;
};

const storeWeatherCache = (key, data) => {
  if (!key) return;
  weatherCache.set(key, { data, timestamp: Date.now() });
};

export const getWeather = async ({ city, lat, lon }) => {
  const endpoint = process.env.WEATHER_API_ENDPOINT;
  const apiKey = process.env.WEATHER_API_KEY;

  const requestKey = buildRequestKey({ city, lat, lon });

  if (weatherApiDisabled) {
    return buildFallbackWeather({ city, lat, lon }, weatherDisableReason);
  }

  if (!endpoint || !apiKey) {
    return buildFallbackWeather({ city, lat, lon }, "weather API not configured");
  }

  const cached = getCachedWeather(requestKey);
  if (cached) {
    return cached;
  }

  const params =
    lat && lon
      ? { lat, lon, appid: apiKey, units: "metric" }
      : { q: city, appid: apiKey, units: "metric" };
  const url = `${endpoint}?${buildQueryString(params)}`;

  try {
    const { data } = await axios.get(url);
    storeWeatherCache(requestKey, data);
    return data;
  } catch (error) {
    const status = error.response?.status;
    const message = error.response?.data?.message || error.message;
    const isAuthError = status === 401 || status === 403;
    const reason = isAuthError ? "invalid API key" : message || "request failed";

    if (isAuthError) {
      weatherApiDisabled = true;
      weatherDisableReason = reason;
    }

    const shouldLog = process.env.NODE_ENV !== "test" && (!isAuthError || !getCachedWeather("__logged__"));
    if (shouldLog) {
      console.warn("Weather API error", { status, message: reason });
      if (isAuthError) {
        storeWeatherCache("__logged__", true);
      }
    }

    const fallback = buildFallbackWeather({ city, lat, lon }, reason);
    storeWeatherCache(requestKey, fallback);
    return fallback;
  }
};
