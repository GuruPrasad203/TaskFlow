let ioInstance = null;

export const initSocket = async (server) => {
  const enabled = (process.env.SOCKET_IO_ENABLED || "true").toLowerCase() === "true";
  if (!enabled) {
    return null;
  }

  const { Server } = await import("socket.io");
  ioInstance = new Server(server, {
    cors: {
      origin: process.env.CLIENT_ORIGIN || "*",
      methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
    },
  });

  ioInstance.on("connection", (socket) => {
    socket.on("joinGoal", (goalId) => socket.join(`goal:${goalId}`));
    socket.on("leaveGoal", (goalId) => socket.leave(`goal:${goalId}`));
  });

  return ioInstance;
};

export const getIO = () => ioInstance;

export const emitGoalUpdate = (goalId, payload) => {
  if (!ioInstance) return;
  ioInstance.to(`goal:${goalId}`).emit("goal:update", payload);
};
