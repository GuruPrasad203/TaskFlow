import { execSync } from "child_process";

class OllamaService {
  constructor(model = "phi3", host = "http://localhost:11434") {
    this.model = model;
    this.host = host;
  }

  /**
   * Check if Ollama is running and the model is available
   */
  async checkHealth() {
    try {
      const host = process.env.OLLAMA_HOST || this.host;
      const env = { ...process.env };
      if (host) {
        env.OLLAMA_HOST = host;
      }
      
      const result = execSync(`ollama list`, { 
        encoding: 'utf-8',
        timeout: 5000,
        env: env
      });
      
      const models = result.split('\n').filter(line => line.trim());
      const hasModel = models.some(line => line.includes(this.model));
      
      return {
        isRunning: true,
        hasModel,
        availableModels: models
      };
    } catch (error) {
      return {
        isRunning: false,
        hasModel: false,
        error: error.message
      };
    }
  }

  /**
   * Pull the Phi3 model if not available
   */
  async pullModel() {
    try {
      console.log(`Pulling ${this.model} model...`);
      const host = process.env.OLLAMA_HOST || this.host;
      const env = { ...process.env };
      if (host) {
        env.OLLAMA_HOST = host;
      }
      
      const result = execSync(`ollama pull ${this.model}`, { 
        encoding: 'utf-8',
        timeout: 300000, // 5 minutes timeout
        env: env
      });
      
      return {
        success: true,
        message: `Model ${this.model} pulled successfully`,
        output: result
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Query the Ollama model with a prompt
   */
  async query(prompt, options = {}) {
    console.log('[OllamaService] query() called');
    console.log('[OllamaService] Prompt length:', prompt.length);
    console.log('[OllamaService] Model:', this.model);
    
    try {
      const sanitizedPrompt = this.sanitizePrompt(prompt);
      console.log('[OllamaService] Sanitized prompt length:', sanitizedPrompt.length);
      
      const host = process.env.OLLAMA_HOST || this.host;
      console.log('[OllamaService] Ollama host:', host);
      
      // Set environment variable for Windows compatibility
      const env = { ...process.env };
      if (host) {
        env.OLLAMA_HOST = host;
      }
      
      const command = `ollama run ${this.model}`;
      console.log('[OllamaService] Executing command:', command);
      console.log('[OllamaService] Timeout:', options.timeout || 60000, 'ms');
      
      const result = execSync(command, {
        encoding: 'utf-8',
        maxBuffer: 1024 * 1024 * 10, // 10MB buffer
        stdio: ['pipe', 'pipe', 'pipe'],
        input: `${sanitizedPrompt}\n`,
        timeout: options.timeout || 60000, // 1 minute default timeout
        env: env
      }).trim();

      console.log('[OllamaService] ✅ Command executed successfully');
      console.log('[OllamaService] Result length:', result.length);
      console.log('[OllamaService] Result preview (first 300 chars):', result.substring(0, 300));

      return {
        success: true,
        response: result,
        model: this.model
      };
    } catch (error) {
      console.error('[OllamaService] ❌ Ollama Query Error:', error.message);
      console.error('[OllamaService] Error code:', error.code);
      console.error('[OllamaService] Error signal:', error.signal);
      console.error('[OllamaService] Error stdout:', error.stdout?.toString());
      console.error('[OllamaService] Error stderr:', error.stderr?.toString());
      
      return {
        success: false,
        error: error.message,
        model: this.model
      };
    }
  }

  /**
   * Sanitize prompt to prevent command injection
   */
  sanitizePrompt(input = "") {
    if (typeof input !== "string") return "";
    return input.replace(/"/g, "'").replace(/`/g, "'").replace(/\$/g, "\\$");
  }

  /**
   * Generate a chat response for the chatbot
   */
  async generateChatResponse(message, context = {}) {
    const systemPrompt = `You are an AI travel planning assistant powered by Ollama Phi3. You help users plan trips, create itineraries, and organize travel goals.

Your capabilities:
- Trip planning and itinerary creation
- Budget estimation and cost analysis
- Destination recommendations
- Travel logistics and booking suggestions
- Cultural insights and local tips

Guidelines:
- Be helpful, friendly, and informative
- Provide practical, actionable advice
- Ask clarifying questions when needed
- Keep responses concise but comprehensive
- Focus on travel-related topics

Context: ${JSON.stringify(context, null, 2)}`;

    const userPrompt = `User message: "${message}"

Please provide a helpful response about travel planning. If the user is asking for a specific trip plan, acknowledge their request and let them know you can help create a detailed travel plan with tasks and recommendations.`;

    const fullPrompt = `${systemPrompt}\n\n${userPrompt}`;

    const result = await this.query(fullPrompt);
    
    if (result.success) {
      return {
        success: true,
        response: result.response,
        model: this.model,
        timestamp: new Date().toISOString()
      };
    } else {
      return {
        success: false,
        error: result.error,
        fallback: "I'm here to help you plan amazing trips! I can assist with itinerary creation, budget planning, destination recommendations, and travel logistics. What kind of trip are you planning?"
      };
    }
  }

  /**
   * Generate a structured travel plan response
   */
  async generateTravelPlan(message) {
    const prompt = `You are an expert travel planner specializing in Indian destinations. Analyze this travel request and create a detailed, budget-conscious plan with day-by-day itinerary.

User Request: "${message}"

CRITICAL FORMATTING RULES:
- Respond with ONLY valid, complete JSON
- Use DOUBLE QUOTES (") for ALL strings - both property names AND values
- NEVER use single quotes (')
- Do NOT include markdown code blocks like \`\`\`json
- Do NOT add comments inside the JSON
- Keep descriptions concise (under 100 characters each)
- Ensure the JSON is properly closed with all brackets and braces

Important Instructions:
1. Analyze the destination, duration, and budget from the user's message
2. Provide EXACTLY 3 hotel recommendations matching the categories in the schema
3. Create a simple day-by-day itinerary (2-3 places per day maximum)
4. Include weather information for the destination
5. Break down the budget allocation
6. Suggest REAL attractions for that specific destination
7. **CRITICAL**: Use ONLY the fields shown in the example schema - DO NOT add "ambience", "meals", "weather" per day, or any other fields
8. Hotels must have ONLY: name, category, pricePerNight, location, rating
9. Places must have ONLY: name, time, description, cost

Provide your response in this EXACT JSON format using DOUBLE QUOTES (must be complete and valid):
STRICT JSON SCHEMA - Use ONLY these exact fields, NO ADDITIONS:
{
  "acknowledgment": "A warm acknowledgment mentioning their specific destination and budget",
  "destination": "The specific destination from their request",
  "duration": "X days",
  "budget": "₹X,XXX",
  "weather": {
    "temperature": "Temperature range (e.g., 25-32°C)",
    "condition": "Weather condition (e.g., Sunny, Partly cloudy, Monsoon)",
    "bestTimeToVisit": "Best season/months to visit"
  },
  "hotels": [
    {
      "name": "Hotel name 1",
      "category": "Budget",
      "pricePerNight": "₹XXX",
      "location": "Area",
      "rating": "4.2/5"
    },
    {
      "name": "Hotel name 2",
      "category": "Mid-range",
      "pricePerNight": "₹XXX",
      "location": "Area",
      "rating": "4.5/5"
    },
    {
      "name": "Hotel name 3",
      "category": "Premium",
      "pricePerNight": "₹XXX",
      "location": "Area",
      "rating": "4.7/5"
    }
  ],
  "dayByDayItinerary": [
    {
      "day": 1,
      "title": "Day 1 theme",
      "places": [
        {
          "name": "Place name",
          "time": "Morning",
          "description": "Brief what to do",
          "cost": "₹XXX"
        }
      ]
    },
    {
      "day": 2,
      "title": "Day 2 theme",
      "places": [
        {
          "name": "Place/attraction name",
          "time": "Morning/Afternoon/Evening",
          "duration": "2-3 hours",
          "description": "What to do here",
          "cost": "₹XXX"
        }
      ],
      "meals": {
        "breakfast": "Where to eat breakfast",
        "lunch": "Where to eat lunch",
        "dinner": "Where to eat dinner"
      }
    }
  ],
  "highlights": [
    "Must-visit landmark 1",
    "Must-visit landmark 2",
    "Must-visit landmark 3"
  ],
  "budgetBreakdown": {
    "accommodation": "₹X,XXX (2 nights)",
    "food": "₹X,XXX (meals)",
    "transport": "₹X,XXX",
    "activities": "₹X,XXX (entry fees)",
    "miscellaneous": "₹XXX (emergency)"
  },
  "transportation": {
    "local": "Local transport options with costs",
    "intercity": "How to reach the destination"
  },
  "nextSteps": [
    "Specific action 1",
    "Specific action 2",
    "Specific action 3"
  ]
}

⚠️ FIELD RESTRICTION REMINDER:
- Hotels: ONLY 5 fields (name, category, pricePerNight, location, rating) - NO "ambience", NO "amenities"
- Places: ONLY 4 fields (name, time, description, cost) - NO "duration", NO "tips"
- Days: ONLY 3 fields (day, title, places) - NO "weather", NO "meals"
- Use the EXACT schema above - removing or adding fields will cause parsing errors

Example for "Plan 2-day Chennai trip with ₹15,000":
{
  "acknowledgment": "Great choice! Chennai offers rich culture and heritage. With ₹15,000, you can enjoy a comfortable 2-day trip.",
  "destination": "Chennai, Tamil Nadu",
  "duration": "2 days",
  "budget": "₹15,000",
  "highlights": [
    "Marina Beach - World's second longest beach",
    "Kapaleeshwar Temple - Ancient Shiva temple",
    "Fort St. George - Historic British fort and museum"
  ],
  "recommendations": {
    "accommodation": "Budget hotel in T Nagar or Mylapore (₹1,500-2,000/night)",
    "transportation": "Use Metro Rail (₹20-50/trip) and auto-rickshaws (₹100-200/day)",
    "activities": [
      "Visit Marina Beach at sunrise - Free",
      "Explore Kapaleeshwar Temple - ₹50 entry",
      "Tour Government Museum - ₹250 entry"
    ]
  },
  "budgetBreakdown": {
    "accommodation": "₹4,000 (2 nights)",
    "food": "₹3,000 (street food & restaurants)",
    "transport": "₹2,000 (metro, auto)",
    "activities": "₹2,500 (entry fees, guided tours)",
    "miscellaneous": "₹3,500 (shopping, emergency)"
  },
  "nextSteps": [
    "Book accommodation in T Nagar area near metro station",
    "Download Chennai Metro app for easy travel",
    "Check weather forecast and pack light cotton clothes"
  ]
}

Now analyze the user's request and provide the JSON response:`;

    console.log('[OllamaService] generateTravelPlan() calling query with prompt length:', prompt.length);
    const result = await this.query(prompt, { timeout: 90000 });
    
    console.log('[OllamaService] query() returned. Success:', result.success);
    
    if (result.success) {
      console.log('[OllamaService] Raw response length:', result.response?.length);
      console.log('[OllamaService] Raw response preview (first 500 chars):', result.response?.substring(0, 500));
      
      try {
        // First, remove markdown code blocks if present
        let cleanedResponse = result.response.trim();
        if (cleanedResponse.startsWith('```json')) {
          cleanedResponse = cleanedResponse.replace(/```json\s*/g, '').replace(/```\s*$/g, '');
        } else if (cleanedResponse.startsWith('```')) {
          cleanedResponse = cleanedResponse.replace(/```\s*/g, '');
        }
        
        console.log('[OllamaService] Cleaned response (first 300 chars):', cleanedResponse.substring(0, 300));
        
        const jsonMatch = cleanedResponse.match(/\{[\s\S]*\}/);
        console.log('[OllamaService] JSON regex match:', !!jsonMatch);
        
        if (jsonMatch) {
          console.log('[OllamaService] Matched JSON length:', jsonMatch[0].length);
          
          let jsonString = jsonMatch[0];
          
          // Check if JSON appears incomplete (doesn't end properly)
          const trimmed = jsonString.trim();
          if (!trimmed.endsWith('}')) {
            console.log('[OllamaService] ⚠️ JSON appears truncated, attempting to fix...');
            // Try to close any open structures
            let openBraces = (jsonString.match(/\{/g) || []).length;
            let closeBraces = (jsonString.match(/\}/g) || []).length;
            let openBrackets = (jsonString.match(/\[/g) || []).length;
            let closeBrackets = (jsonString.match(/\]/g) || []).length;
            
            // Close open arrays
            while (openBrackets > closeBrackets) {
              jsonString += ']';
              closeBrackets++;
            }
            // Close open objects
            while (openBraces > closeBraces) {
              jsonString += '}';
              closeBraces++;
            }
            console.log('[OllamaService] Added closing brackets/braces. New length:', jsonString.length);
          }
          
          // Comprehensive fix for mixed quote styles from Ollama
          // Step 1: Fix property names - convert 'property': to "property":
          jsonString = jsonString.replace(/'([a-zA-Z_][a-zA-Z0-9_]*)'\s*:/g, '"$1":');
          
          // Step 2: Fix string values with single quotes
          // Match patterns like : 'value' or [ 'value' or , 'value'
          // This regex looks for single-quoted strings after : , or [
          jsonString = jsonString.replace(/([:\[,]\s*)'([^']*?)'/g, function(match, prefix, content) {
            // Escape any double quotes inside the content
            const escapedContent = content.replace(/"/g, '\\"');
            return prefix + '"' + escapedContent + '"';
          });
          
          // Step 3: Remove comments in JSON like "(used assumed values)"
          jsonString = jsonString.replace(/"\s*\([^)]+\)\s*,/g, '",');
          jsonString = jsonString.replace(/"\s*\([^)]+\)\s*$/gm, '"');
          
          // Step 4: Fix common JSON syntax errors
          // Remove trailing commas before closing brackets/braces
          jsonString = jsonString.replace(/,(\s*[}\]])/g, '$1');
          
          console.log('[OllamaService] Fixed JSON preview (first 500 chars):', jsonString.substring(0, 500));
          console.log('[OllamaService] Fixed JSON last 200 chars:', jsonString.substring(jsonString.length - 200));
          
          const parsed = JSON.parse(jsonString);
          console.log('[OllamaService] ✅ Successfully parsed JSON');
          console.log('[OllamaService] Parsed destination:', parsed?.destination);
          
          return {
            success: true,
            structuredResponse: parsed,
            rawResponse: result.response,
            model: this.model
          };
        } else {
          console.log('[OllamaService] ❌ No JSON found in response');
          return {
            success: false,
            error: "No JSON structure found in response",
            rawResponse: result.response,
            fallback: {
              acknowledgment: "I'd love to help you plan this trip!",
              destination: "Your chosen destination",
              duration: 3,
              highlights: ["Local attractions", "Cultural experiences", "Scenic spots"],
              recommendations: {
                accommodation: "Comfortable hotel or guesthouse",
                transportation: "Local transport options",
                activities: ["Sightseeing", "Local cuisine", "Cultural experiences"]
              },
              nextSteps: ["Research accommodation", "Plan itinerary", "Book transportation"]
            }
          };
        }
      } catch (parseError) {
        console.error('[OllamaService] ❌ JSON parse error:', parseError.message);
        console.error('[OllamaService] Failed to parse response:', result.response?.substring(0, 1000));
        
        return {
          success: false,
          error: "Failed to parse structured response",
          rawResponse: result.response,
          fallback: {
            acknowledgment: "I'd love to help you plan this trip!",
            destination: "Your chosen destination",
            duration: 3,
            highlights: ["Local attractions", "Cultural experiences", "Scenic spots"],
            recommendations: {
              accommodation: "Comfortable hotel or guesthouse",
              transportation: "Local transport options",
              activities: ["Sightseeing", "Local cuisine", "Cultural experiences"]
            },
            nextSteps: ["Research accommodation", "Plan itinerary", "Book transportation"]
          }
        };
      }
    } else {
      console.error('[OllamaService] ❌ Query failed:', result.error);
      
      return {
        success: false,
        error: result.error,
        fallback: {
          acknowledgment: "I'd love to help you plan this trip!",
          destination: "Your chosen destination",
          duration: 3,
          highlights: ["Local attractions", "Cultural experiences", "Scenic spots"],
          recommendations: {
            accommodation: "Comfortable hotel or guesthouse",
            transportation: "Local transport options",
            activities: ["Sightseeing", "Local cuisine", "Cultural experiences"]
          },
          nextSteps: ["Research accommodation", "Plan itinerary", "Book transportation"]
        }
      };
    }
  }
}

export default OllamaService;
