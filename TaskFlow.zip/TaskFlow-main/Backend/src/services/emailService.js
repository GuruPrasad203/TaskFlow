import nodemailer from 'nodemailer';

class EmailService {
  constructor() {
    this.transporter = null;
    this.isEmailEnabled = false;
    this._initialized = false;
  }

  _initialize() {
    if (this._initialized) return;
    this._initialized = true;

    const {
      EMAIL_SERVICE = 'gmail',
      EMAIL_USER,
      EMAIL_APP_PASSWORD,
      EMAIL_HOST,
      EMAIL_PORT,
      EMAIL_SECURE,
    } = process.env;

    // Debug log to verify environment variables are loaded
    console.log('[EmailService] Checking email configuration...');
    console.log('[EmailService] EMAIL_USER:', EMAIL_USER ? 'Set' : 'Missing');
    console.log('[EmailService] EMAIL_APP_PASSWORD:', EMAIL_APP_PASSWORD ? 'Set (' + EMAIL_APP_PASSWORD.length + ' chars)' : 'Missing');

    if (EMAIL_USER && (EMAIL_APP_PASSWORD || (EMAIL_HOST && EMAIL_PORT))) {
      // Configure transporter with provided credentials
      this.transporter = nodemailer.createTransport({
        service: EMAIL_HOST ? undefined : EMAIL_SERVICE,
        host: EMAIL_HOST,
        port: EMAIL_PORT ? Number(EMAIL_PORT) : undefined,
        secure: EMAIL_SECURE ? EMAIL_SECURE === 'true' : undefined,
        auth: {
          user: EMAIL_USER,
          pass: EMAIL_APP_PASSWORD,
        },
      });
      this.isEmailEnabled = true;
      console.log('[EmailService] ✅ Email service enabled with Gmail');
    } else {
      // Fallback transporter that just logs the message instead of sending
      this.transporter = nodemailer.createTransport({ jsonTransport: true });
      this.isEmailEnabled = false;
      console.warn(
        '[EmailService] Email credentials are missing. Emails will be logged instead of sent. '
        + 'Set EMAIL_USER and EMAIL_APP_PASSWORD (or SMTP host/port) to enable real email delivery.'
      );
    }
  }

  async sendOTP(email, otp) {
    // Initialize on first use (lazy initialization)
    this._initialize();
    
    try {
      const mailOptions = {
        from: 'sentilteam2025@gmail.com',
        to: email,
        subject: 'Your OTP Verification Code',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #3B82F6, #1E40AF); padding: 30px; border-radius: 10px; text-align: center;">
              <h1 style="color: white; margin: 0; font-size: 28px;">🔐 OTP Verification</h1>
            </div>
            
            <div style="background: #f8fafc; padding: 30px; border-radius: 10px; margin-top: 20px;">
              <h2 style="color: #1F2937; margin-bottom: 20px;">Your Verification Code</h2>
              
              <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; border: 2px dashed #3B82F6;">
                <h1 style="color: #3B82F6; font-size: 36px; letter-spacing: 8px; margin: 0; font-family: 'Courier New', monospace;">${otp}</h1>
              </div>
              
              <p style="color: #6B7280; margin-top: 20px; line-height: 1.6;">
                This code will expire in <strong>10 minutes</strong>. Please enter this code in the app to verify your email address.
              </p>
              
              <div style="background: #FEF3C7; border: 1px solid #F59E0B; padding: 15px; border-radius: 8px; margin-top: 20px;">
                <p style="color: #92400E; margin: 0; font-size: 14px;">
                  <strong>⚠️ Security Notice:</strong> Never share this code with anyone. Our team will never ask for your verification code.
                </p>
              </div>
            </div>
            
            <div style="text-align: center; margin-top: 30px; color: #9CA3AF; font-size: 12px;">
              <p>This email was sent by your AI Travel Assistant</p>
              <p>If you didn't request this code, please ignore this email.</p>
            </div>
          </div>
        `
      };

      const result = await this.transporter.sendMail(mailOptions);

      if (this.isEmailEnabled) {
        console.log('OTP email sent successfully:', result.messageId);
      } else {
        console.log('[EmailService] OTP email logged (email disabled):', result.message);
      }

      return {
        success: true,
        messageId: result.messageId,
        emailSent: this.isEmailEnabled,
      };
    } catch (error) {
      console.error('Failed to send OTP email:', error);

      const allowFallback = process.env.NODE_ENV !== 'production';

      if (allowFallback) {
        console.warn('[EmailService] Falling back to development mode (OTP logged).');
        console.log(`[EmailService] OTP for ${email}: ${otp}`);
        return {
          success: true,
          emailSent: false,
          warning: error.message,
        };
      }

      return { success: false, error: error.message };
    }
  }

  async sendWelcomeEmail(email, name) {
    try {
      const mailOptions = {
        from: 'sentilteam2025@gmail.com',
        to: email,
        subject: 'Welcome to AI Travel Assistant! 🎉',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #10B981, #059669); padding: 30px; border-radius: 10px; text-align: center;">
              <h1 style="color: white; margin: 0; font-size: 28px;">🎉 Welcome to AI Travel Assistant!</h1>
            </div>
            
            <div style="background: #f8fafc; padding: 30px; border-radius: 10px; margin-top: 20px;">
              <h2 style="color: #1F2937; margin-bottom: 20px;">Hi ${name}! 👋</h2>
              
              <p style="color: #6B7280; line-height: 1.6; margin-bottom: 20px;">
                Welcome to your AI-powered travel planning assistant! We're excited to help you plan amazing trips and organize your travel goals.
              </p>
              
              <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="color: #3B82F6; margin-top: 0;">🚀 What you can do:</h3>
                <ul style="color: #6B7280; line-height: 1.8;">
                  <li>Plan trips with AI-powered recommendations</li>
                  <li>Create detailed itineraries and budgets</li>
                  <li>Track your travel goals and progress</li>
                  <li>Get personalized travel suggestions</li>
                </ul>
              </div>
              
              <div style="text-align: center; margin-top: 30px;">
                <a href="#" style="background: #3B82F6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; display: inline-block;">
                  Start Planning Your Trip
                </a>
              </div>
            </div>
            
            <div style="text-align: center; margin-top: 30px; color: #9CA3AF; font-size: 12px;">
              <p>Happy travels! 🌍✈️</p>
              <p>Your AI Travel Assistant Team</p>
            </div>
          </div>
        `
      };

      const result = await this.transporter.sendMail(mailOptions);

      if (this.isEmailEnabled) {
        console.log('Welcome email sent successfully:', result.messageId);
      } else {
        console.log('[EmailService] Welcome email logged (email disabled).');
      }

      return {
        success: true,
        messageId: result.messageId,
        emailSent: this.isEmailEnabled,
      };
    } catch (error) {
      console.error('Failed to send welcome email:', error);

      if (process.env.NODE_ENV !== 'production') {
        console.warn('[EmailService] Skipping welcome email in development due to error:', error.message);
        return {
          success: true,
          emailSent: false,
          warning: error.message,
        };
      }

      return { success: false, error: error.message };
    }
  }
}

export default new EmailService();
