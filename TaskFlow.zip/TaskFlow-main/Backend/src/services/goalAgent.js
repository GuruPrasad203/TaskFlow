import travelTools from "./tools/travelTools.js";

const extractDestination = (title = "", fallback = "Destination") => {
  if (!title) return fallback;
  if (title.includes("near")) {
    const [, place] = title.split(/near/i);
    const cleaned = place?.trim();
    if (cleaned) return cleaned;
  }
  const match = title.match(/to\s+([a-z\s]+)/i);
  if (match?.[1]) return match[1].trim();
  return title;
};

const getAverageNightlyRate = (hotels = []) => {
  if (!hotels.length) return 3000;
  const total = hotels.reduce((sum, hotel) => sum + (hotel.approxRate || hotel.pricePerNight || 3000), 0);
  return Math.round(total / hotels.length);
};

const formatHotel = (hotel) => {
  if (!hotel) return null;
  if (typeof hotel === "string") return hotel;
  const { name, approxRate, pricePerNight, highlight } = hotel;
  const rate = approxRate || pricePerNight;
  const rateDisplay = rate ? `(~₹${rate}/night)` : "";
  const highlightText = highlight ? ` – ${highlight}` : "";
  return `${name || "Hotel"}${highlightText} ${rateDisplay}`.trim();
};

const buildSummary = ({ destination, durationDays, travelers, origin, preferencesMatched }) => {
  const base = `${durationDays}-day itinerary for ${destination}`;
  const travelerText = travelers > 1 ? `${travelers} travelers` : "a solo traveler";
  const fromText = origin ? ` starting from ${origin}` : "";
  const preferenceText = preferencesMatched?.length ? `, matching your interest in ${preferencesMatched.join(", ")}` : "";
  return `${base} designed for ${travelerText}${fromText}${preferenceText}.`;
};

const buildNextSteps = (travelTips = []) => {
  const defaults = [
    "Review the itinerary and book stays early to lock in rates",
    "Share travel plan with companions and align on departure times",
  ];
  const tips = Array.isArray(travelTips) ? travelTips : [];
  return [...new Set([...tips, ...defaults])].slice(0, 6);
};

const buildRecommendedTasks = ({ destination, origin, itinerary, food = [], lodging = [], preferences = [], budgetFit }) => {
  const tasks = new Set();
  if (lodging.length) tasks.add(`Book accommodation in ${destination}`);
  if (origin && destination) tasks.add(`Plan travel route from ${origin} to ${destination}`);
  if (itinerary?.length) tasks.add("Confirm day-wise schedule and activity timings");
  if (food.length) tasks.add("List must-try eateries and make reservations if needed");
  if (preferences.includes("romantic")) tasks.add("Reserve sunset or candlelight experience");
  if (preferences.includes("hill station")) tasks.add("Pack layers and check ghat road conditions");
  if (budgetFit && budgetFit.withinBudget === false) tasks.add("Adjust itinerary or budget to stay within spend limits");
  if (preferences.includes("adventure")) tasks.add("Pre-book adventure activities with trusted operators");
  return Array.from(tasks).slice(0, 6);
};

export const executeGoal = async (goal) => {
  const safeGoal = goal || {};
  const metadata = safeGoal.metadata || {};
  const origin = metadata.origin || "Origin";
  const preferences = metadata.preferences || [];
  const durationDays = Number(metadata.durationDays) || 3;
  const travelers = Number(metadata.travelers) || 2;
  const destination = extractDestination(safeGoal.title, metadata.destination || "Destination");
  const budgetINR = Number(metadata.budgetINR) || undefined;

  const tripPlan = await travelTools.tripPlanner.execute({
    origin,
    destination,
    durationDays,
    preferences,
    budget: budgetINR,
  });

  const weather = await travelTools.weatherTool.execute({ location: tripPlan.destination });

  const hotelPerNight = getAverageNightlyRate(tripPlan.hotelRecommendations);
  const budget = await travelTools.budgetCalculator.execute({
    days: durationDays,
    people: travelers,
    hotelPerNight,
    destination: tripPlan.destination,
    origin,
  });

  const lodging = (tripPlan.hotelRecommendations || [])
    .map(formatHotel)
    .filter(Boolean);

  const food = tripPlan.foodRecommendations || [];
  const attractions = tripPlan.attractionHighlights || [];
  const specialExperiences = tripPlan.culturalNotes || [];
  const itinerary = tripPlan.itinerary || [];
  const recommendedTasks = buildRecommendedTasks({
    destination: tripPlan.destination,
    origin,
    itinerary,
    food,
    lodging,
    preferences,
    budgetFit: tripPlan.budgetFit,
  });

  safeGoal.finalSynthesis = {
    summary: buildSummary({
      destination: tripPlan.destination,
      durationDays,
      travelers,
      origin,
      preferencesMatched: tripPlan.preferencesMatched,
    }),
    weather,
    itinerary,
    lodging: lodging.length ? lodging : ["Review stay options based on comfort and budget."],
    food: food.length ? food : ["Sample local specialties and comfort meals."],
    mustSeeAttractions: attractions.length ? attractions : ["Explore key landmarks and nearby day trips."],
    budget,
    specialExperiences: specialExperiences.length ? specialExperiences : ["Reserve time for a cultural workshop or guided experience."],
    nextSteps: buildNextSteps(tripPlan.travelTips),
    recommendedTasks,
    generatedFromFallback: false,
  };

  return safeGoal;
};

export default {
  executeGoal,
};

// Utility: format a human-friendly trip plan summary
export const formatPlanText = ({
  title,
  destination,
  durationDays,
  travelers,
  origin,
  budget,
  weather,
  itinerary,
  food,
  mustSeeAttractions,
  nextSteps,
} = {}) => {
  const lines = [];
  const budgetLine = budget?.estimate ? `₹${budget.estimate.toLocaleString("en-IN")}` : "—";
  const weatherLine = weather?.overview || "Weather details unavailable.";

  lines.push(`${title || `Weekend Trip Plan: ${destination || "Destination"}`}`);
  if (durationDays) lines.push(`Duration: ${durationDays} day${durationDays > 1 ? "s" : ""}`);
  if (travelers) lines.push(`Travelers: ${travelers}`);
  if (origin && destination) lines.push(`Travel: ${origin} → ${destination}`);
  lines.push(`Estimated Budget: ${budgetLine}`);
  lines.push(`Weather: ${weatherLine}`);

  if (Array.isArray(itinerary) && itinerary.length) {
    lines.push("", "Itinerary:");
    lines.push(...itinerary.map((d, i) => `- Day ${i + 1}: ${d.plan || d}`));
  }

  const highlights = [];
  if (Array.isArray(food) && food.length) highlights.push("Food highlights");
  if (Array.isArray(mustSeeAttractions) && mustSeeAttractions.length) highlights.push("Must-see attractions");
  if (highlights.length) {
    lines.push("", `Highlights: ${highlights.join(", ")}`);
  }

  if (Array.isArray(nextSteps) && nextSteps.length) {
    lines.push("", "Tips:");
    lines.push(...nextSteps.map((t) => `- ${t}`));
  }

  return lines.join("\n");
};
