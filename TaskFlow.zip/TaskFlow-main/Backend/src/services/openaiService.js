import OpenAI from "openai";

let client;

const getClient = () => {
  if (!client) {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      throw new Error("OPENAI_API_KEY not configured");
    }
    client = new OpenAI({ apiKey });
  }
  return client;
};

export const decomposeGoal = async ({ goalTitle, goalDescription }) => {
  const systemPrompt = `You are an expert planner. Break goals into 3-7 concise tasks.
Return JSON array with objects {"title": string, "description": string}.`;
  const userPrompt = `Goal: ${goalTitle}\nDescription: ${goalDescription || "(none)"}`;

  const completion = await getClient().responses.create({
    model: "gpt-4.1-mini",
    input: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "task_decomposition",
        schema: {
          type: "object",
          properties: {
            tasks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                },
                required: ["title"],
              },
              minItems: 1,
              maxItems: 10,
            },
          },
          required: ["tasks"],
        },
      },
    },
  });

  const text = completion?.output?.[0]?.content?.[0]?.text;
  if (!text) {
    throw new Error("OpenAI decomposition failed to produce content");
  }

  const parsed = JSON.parse(text);
  return parsed.tasks || [];
};
