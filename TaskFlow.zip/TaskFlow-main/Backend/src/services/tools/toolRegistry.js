import WebSearchTool from "./implementations/webSearchTool.js";
import WeatherTool from "./implementations/weatherTool.js";
import PriceCompareTool from "./implementations/priceCompareTool.js";
import BudgetCalculatorTool from "./implementations/budgetCalculatorTool.js";
import TripPlannerTool from "./implementations/tripPlannerTool.js";
import DistanceCalculatorTool from "./implementations/distanceCalculatorTool.js";

export class ToolRegistry {
  constructor(initialTools = {}) {
    this.tools = new Map(Object.entries(initialTools));
  }

  register(name, tool) {
    if (!name || !tool) {
      throw new Error("Tool name and implementation are required");
    }
    this.tools.set(name, tool);
  }

  unregister(name) {
    this.tools.delete(name);
  }

  get(name) {
    return this.tools.get(name);
  }

  list() {
    return Array.from(this.tools.keys());
  }
}

const defaultTools = {
  web_search: WebSearchTool,
  weather: WeatherTool,
  price_compare: PriceCompareTool,
  budget_calculator: BudgetCalculatorTool,
  trip_planner: TripPlannerTool,
  distance_calculator: DistanceCalculatorTool,
};

const toolRegistry = new ToolRegistry(defaultTools);

export default toolRegistry;
