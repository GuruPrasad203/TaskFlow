const DESTINATION_GUIDES = {
  "new delhi": {
    displayName: "New Delhi, India",
    dayPlans: [
      "Visit India Gate, Rashtrapati Bhavan, and explore Connaught Place cafes.",
      "Tour Qutub Minar, Humayun's Tomb, and browse Dilli Haat for handicrafts.",
      "Experience Old Delhi: Red Fort, Jama Masjid, and Chandni Chowk food trail."
    ],
    attractions: [
      "India Gate illuminated at night",
      "Humayun's Tomb and surrounding Mughal gardens",
      "Red Fort sound and light show"
    ],
    foods: [
      "Chandni Chowk chaat and jalebi",
      "Paranthas at Paranthe Wali Gali",
      "Butter chicken at iconic Delhi dhabas"
    ],
    hotels: [
      { name: "Bloomrooms @ New Delhi Railway Station", approxRate: 3200, highlight: "Bright rooms near Connaught Place" },
      { name: "The Park New Delhi", approxRate: 6000, highlight: "Business-class stay with city views" },
      { name: "Zostel Delhi", approxRate: 1800, highlight: "Backpacker-friendly hostel in central Delhi" }
    ],
    culturalHighlights: [
      "Catch a performance at the India Habitat Centre",
      "Plan a sunset walk around Lodhi Art District murals"
    ],
    tips: [
      "Use the Delhi Metro for quick cross-city travel",
      "Carry cash for street food and market bargaining"
    ],
    averageDailyCost: 5500
  },
  chennai: {
    displayName: "Chennai, India",
    dayPlans: [
      "Sunrise at Marina Beach and visit Kapaleeshwarar Temple.",
      "Explore Government Museum and savor filter coffee trails.",
      "Day trip to Mahabalipuram for UNESCO heritage sites."
    ],
    attractions: [
      "Marina Beach promenade",
      "Kapaleeshwarar Temple in Mylapore",
      "Mahabalipuram shore temple"
    ],
    foods: [
      "Ghee podi dosa",
      "Fresh filter coffee",
      "Chettinad chicken"
    ],
    hotels: [
      { name: "The Residency", approxRate: 4500, highlight: "Central location with hearty breakfast" },
      { name: "Taj Club House", approxRate: 6500, highlight: "Upscale stay near business district" }
    ],
    culturalHighlights: [
      "Watch a Bharatanatyam recital in Mylapore",
      "Browse handicrafts at Kalakshetra Foundation"
    ],
    tips: [
      "Hydrate often; coastal humidity is high",
      "Plan temple visits early morning to avoid heat"
    ],
    averageDailyCost: 4800
  },
  salem: {
    displayName: "Salem, India",
    dayPlans: [
      "Explore Yercaud hill station viewpoints and Emerald Lake.",
      "Visit 1008 Lingam Temple and local silk weaving clusters.",
      "Take a spice and coffee trail around Pagoda Point."
    ],
    attractions: [
      "Yercaud's Lady's Seat viewpoint",
      "1008 Lingam Temple",
      "Pagoda Point sunrise"
    ],
    foods: [
      "Yercaud pepper chicken",
      "Traditional millets-based breakfast",
      "Homemade chocolates from hill stalls"
    ],
    hotels: [
      { name: "Grand Estancia", approxRate: 3800, highlight: "City hotel with pool and buffet" },
      { name: "Great Trails Yercaud", approxRate: 7200, highlight: "Resort stay with valley views" }
    ],
    culturalHighlights: [
      "Shop for Salem silk sarees",
      "Attend local coffee plantation tours"
    ],
    tips: [
      "Carry light sweaters for Yercaud evenings",
      "Plan taxi rides in advance for hill trips"
    ],
    averageDailyCost: 4200
  }
};

const DEFAULT_GUIDE = {
  dayPlans: [
    "Discover top landmarks and get oriented with a guided city walk.",
    "Dive into local cuisine, museums, and cultural districts.",
    "Plan a nearby excursion or relax with shopping and leisure."],
  attractions: ["Explore signature landmarks", "Join a cultural experience", "Shop at local markets"],
  foods: ["Sample regional street food", "Try a beloved local dessert"],
  hotels: [{ name: "Comfort Stay Central", approxRate: 4500, highlight: "Reliable mid-range option with breakfast" }],
  culturalHighlights: ["Engage with local art or music venues"],
  tips: ["Check local transport passes for savings"],
  averageDailyCost: 5000
};

const formatItinerary = (destination, days, dayPlans) => {
  const itinerary = [];
  for (let i = 0; i < days; i += 1) {
    const basePlan = dayPlans[i] || dayPlans[i % dayPlans.length];
    itinerary.push({
      day: i + 1,
      plan: basePlan.replace(/\{destination\}/gi, destination),
    });
  }
  return itinerary;
};

class TripPlannerTool {
  static name = "trip_planner";

  static description = "Generate an itinerary with food, hotel, attraction highlights, and budget insights";

  static parameters = {
    destination: "string",
    days: "number",
    budget: "number",
  };

  static async execute({ destination = "Bangalore", days = 3, budget } = {}) {
    if (!destination) {
      throw new Error("trip_planner tool requires a destination");
    }

    const normalizedKey = destination.trim().toLowerCase();
    const guide = DESTINATION_GUIDES[normalizedKey] || DEFAULT_GUIDE;
    const resolvedDestination = guide.displayName || destination;

    const itinerary = formatItinerary(resolvedDestination, Number(days) || 3, guide.dayPlans);
    const averageDailyCost = guide.averageDailyCost || 5000;
    const suggestedBudget = Math.round(averageDailyCost * itinerary.length);

    const budgetNumber = budget !== undefined ? Number(budget) : undefined;
    let budgetFit;
    if (budgetNumber !== undefined && !Number.isNaN(budgetNumber)) {
      const difference = Number((budgetNumber - suggestedBudget).toFixed(2));
      budgetFit = {
        providedBudget: budgetNumber,
        suggestedBudget,
        withinBudget: budgetNumber >= suggestedBudget,
        difference,
        message:
          budgetNumber >= suggestedBudget
            ? "Planned itinerary fits within the provided budget."
            : "Consider reducing costs or increasing the budget."
      };
    }

    return {
      destination: resolvedDestination,
      days: itinerary.length,
      itinerary,
      foodRecommendations: guide.foods,
      hotelRecommendations: guide.hotels,
      attractionHighlights: guide.attractions,
      culturalNotes: guide.culturalHighlights,
      travelTips: guide.tips,
      suggestedBudget,
      ...(budgetFit ? { budgetFit } : {}),
    };
  }
}

export default TripPlannerTool;
