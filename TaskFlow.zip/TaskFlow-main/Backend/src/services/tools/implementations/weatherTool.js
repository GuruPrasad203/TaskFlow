import { getWeather } from "../../externalApiService.js";

const WeatherTool = {
  name: "weather",
  description: "Fetch weather forecast for a location",
  async execute(params = {}) {
    const { city, lat, lon } = params;
    if (!city && !(lat && lon)) {
      throw new Error("Weather tool requires city or lat/lon");
    }
    return getWeather({ city, lat, lon });
  },
};

export default WeatherTool;
