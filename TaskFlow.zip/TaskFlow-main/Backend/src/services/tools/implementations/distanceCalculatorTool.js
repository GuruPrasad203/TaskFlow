import axios from "axios";

const NOMINATIM_URL = "https://nominatim.openstreetmap.org/search";
const OSRM_URL = "https://router.project-osrm.org/route/v1/driving";

const defaultHeaders = {
  "User-Agent": "goal-orchestrator/1.0",
};

const geocode = async (place) => {
  const { data } = await axios.get(NOMINATIM_URL, {
    params: {
      q: place,
      format: "json",
      limit: 1,
    },
    headers: defaultHeaders,
  });

  if (!Array.isArray(data) || data.length === 0) {
    throw new Error(`Unable to geocode location: ${place}`);
  }

  const [{ lat, lon, display_name: displayName }] = data;
  return {
    lat: Number(lat),
    lon: Number(lon),
    label: displayName,
  };
};

const fetchRoute = async ({ origin, destination }) => {
  const coords = `${origin.lon},${origin.lat};${destination.lon},${destination.lat}`;
  const url = `${OSRM_URL}/${coords}`;

  const { data } = await axios.get(url, {
    params: {
      overview: "false",
      alternatives: "false",
      steps: "false",
    },
    headers: defaultHeaders,
  });

  if (!data?.routes?.length) {
    throw new Error("Unable to compute route between locations");
  }

  const route = data.routes[0];
  return {
    distanceMeters: route.distance,
    durationSeconds: route.duration,
  };
};

class DistanceCalculatorTool {
  static name = "distance_calculator";

  static description = "Estimate travel distance and duration between two locations";

  static parameters = {
    origin: "string",
    destination: "string",
  };

  static async execute({ origin, destination } = {}) {
    if (!origin || !destination) {
      throw new Error("distance_calculator tool requires origin and destination");
    }

    const [originGeo, destinationGeo] = await Promise.all([geocode(origin), geocode(destination)]);
    const route = await fetchRoute({ origin: originGeo, destination: destinationGeo });

    const distanceKm = route.distanceMeters / 1000;
    const durationHours = route.durationSeconds / 3600;

    return {
      origin: originGeo,
      destination: destinationGeo,
      distanceMeters: route.distanceMeters,
      distanceKm: Math.round(distanceKm * 100) / 100,
      durationSeconds: route.durationSeconds,
      durationHours: Math.round(durationHours * 100) / 100,
    };
  }
}

export default DistanceCalculatorTool;
