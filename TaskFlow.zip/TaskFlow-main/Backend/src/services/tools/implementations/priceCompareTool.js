import axios from "axios";

const PriceCompareTool = {
  name: "price_compare",
  description: "Compare prices for flights or hotels using external API",
  async execute(params = {}) {
    const { endpoint, query } = params;
    if (!endpoint) {
      throw new Error("price_compare tool requires an endpoint");
    }

    try {
      const { data } = await axios.get(endpoint, { params: query });
      return data;
    } catch (error) {
      throw new Error(`Price comparison failed: ${error.message}`);
    }
  },
};

export default PriceCompareTool;
