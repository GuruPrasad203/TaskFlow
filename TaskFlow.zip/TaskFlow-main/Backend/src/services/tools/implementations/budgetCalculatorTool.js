class BudgetCalculatorTool {
  static name = "budget_calculator";

  static description = "Estimate trip cost";

  static parameters = {
    days: "number",
    people: "number",
    hotelPerNight: "number",
    transport: "number",
    foodPerDay: "number",
    budget: "number",
  };

  static async execute({
    days = 3,
    people = 2,
    hotelPerNight = 2000,
    transport = 4000,
    foodPerDay = 800,
    budget,
  } = {}) {
    const nDays = Number(days);
    const nPeople = Number(people);
    const nHotelPerNight = Number(hotelPerNight);
    const nTransport = Number(transport);
    const nFoodPerDay = Number(foodPerDay);
    const nBudget = budget !== undefined ? Number(budget) : undefined;

    if ([nDays, nPeople, nHotelPerNight, nTransport, nFoodPerDay].some((value) => Number.isNaN(value))) {
      throw new Error("budget_calculator tool requires numeric inputs");
    }

    const hotel = nHotelPerNight * nDays;
    const food = nFoodPerDay * nPeople * nDays;
    const total = hotel + nTransport + food;

    const payload = {
      total,
      breakdown: {
        hotel,
        transport: nTransport,
        food,
      },
    };

    if (nBudget !== undefined && !Number.isNaN(nBudget)) {
      const balance = Number((nBudget - total).toFixed(2));
      payload.budgetAssessment = {
        providedBudget: nBudget,
        withinBudget: balance >= 0,
        difference: balance,
        message: balance >= 0 ? "Trip fits within the provided budget." : "Projected cost exceeds the provided budget.",
      };
    }

    return payload;
  }
}

export default BudgetCalculatorTool;
