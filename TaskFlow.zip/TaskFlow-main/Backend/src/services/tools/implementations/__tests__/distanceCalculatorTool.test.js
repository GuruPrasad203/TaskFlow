jest.mock("axios");
import { jest } from "@jest/globals";
import axios from "axios";
import DistanceCalculatorTool from "../distanceCalculatorTool.js";

describe("DistanceCalculatorTool", () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  it("calculates distance and duration between two locations", async () => {
    const getSpy = jest.spyOn(axios, "get");
    getSpy
      .mockResolvedValueOnce({
        data: [
          { lat: "13.0827", lon: "80.2707", display_name: "Chennai" },
        ],
      })
      .mockResolvedValueOnce({
        data: [
          { lat: "11.6643", lon: "78.1460", display_name: "Salem" },
        ],
      })
      .mockResolvedValueOnce({
        data: {
          routes: [
            {
              distance: 340000,
              duration: 18000,
            },
          ],
        },
      });

    const result = await DistanceCalculatorTool.execute({ origin: "Chennai", destination: "Salem" });

    expect(result.distanceKm).toBe(340);
    expect(result.durationHours).toBe(5);
    expect(getSpy).toHaveBeenCalledTimes(3);
  });

  it("throws when missing parameters", async () => {
    await expect(DistanceCalculatorTool.execute({ origin: "Chennai" })).rejects.toThrow(
      "distance_calculator tool requires origin and destination"
    );
  });
});
