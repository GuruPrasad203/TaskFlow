import TripPlannerTool from "../tripPlannerTool.js";

describe("TripPlannerTool", () => {
  it("returns rich itinerary and budget fit for New Delhi", async () => {
    const result = await TripPlannerTool.execute({ destination: "New Delhi", days: 3, budget: 20000 });

    expect(result.destination).toContain("New Delhi");
    expect(Array.isArray(result.itinerary)).toBe(true);
    expect(result.itinerary).toHaveLength(3);
    expect(result.foodRecommendations.length).toBeGreaterThan(0);
    expect(result.hotelRecommendations.length).toBeGreaterThan(0);
    expect(result.attractionHighlights.length).toBeGreaterThan(0);
    expect(typeof result.suggestedBudget).toBe("number");
    expect(result.budgetFit.withinBudget).toBe(true);
  });

  it("falls back to defaults for unknown destination", async () => {
    const result = await TripPlannerTool.execute({ destination: "Atlantis", days: 2 });

    expect(result.destination).toContain("Atlantis");
    expect(result.itinerary).toHaveLength(2);
    expect(result.foodRecommendations.length).toBeGreaterThan(0);
    expect(result.hotelRecommendations.length).toBeGreaterThan(0);
    expect(result.suggestedBudget).toBeGreaterThan(0);
  });
});
