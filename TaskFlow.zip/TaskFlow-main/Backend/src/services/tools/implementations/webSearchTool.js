import { googleSearch } from "../../externalApiService.js";

const WebSearchTool = {
  name: "web_search",
  description: "Search the web for relevant information",
  async execute(params = {}) {
    const { query } = params;
    if (!query) {
      throw new Error("web_search tool requires a query parameter");
    }
    return googleSearch(query);
  },
};

export default WebSearchTool;
