import TripPlannerImplementation from "./implementations/tripPlannerTool.js";

const toKey = (value = "") => value.toString().trim().toLowerCase();

const WEATHER_PRESETS = {
  salem: {
    overview: "Expect warm days (~28-32°C) in Salem city with cooler 20-24°C evenings in nearby Yercaud.",
    details: [
      { day: "Saturday", condition: "Warm & breezy", temp: "30°C" },
      { day: "Sunday", condition: "Pleasant with light clouds", temp: "28°C" },
    ],
  },
  yercaud: {
    overview: "Hill-station chill with misty mornings (~20-24°C) and clear afternoons.",
    details: [
      { day: "Saturday", condition: "Misty sunrise", temp: "21°C" },
      { day: "Sunday", condition: "Sunny spells", temp: "24°C" },
    ],
  },
  pondicherry: {
    overview: "Coastal breeze with 26-31°C highs and a chance of light evening drizzle along the promenade.",
    details: [
      { day: "Saturday", condition: "Humid & breezy", temp: "30°C" },
      { day: "Sunday", condition: "Partly cloudy", temp: "29°C" },
    ],
  },
  chennai: {
    overview: "Tropical humidity with 30-33°C afternoons; mornings near the coast stay pleasant.",
    details: [
      { day: "Saturday", condition: "Sunny & humid", temp: "32°C" },
      { day: "Sunday", condition: "Warm with sea breeze", temp: "31°C" },
    ],
  },
};

const DEFAULT_WEATHER = (location) => ({
  overview: `Seasonal conditions expected in ${location}. Carry layers for evenings and stay hydrated during the day.`,
  details: [
    { day: "Day 1", condition: "Mild", temp: "28°C" },
    { day: "Day 2", condition: "Pleasant", temp: "27°C" },
  ],
});

const computeTransportEstimate = (originKey, destinationKey) => {
  if (!originKey || !destinationKey) return 4000;

  const routeKey = `${originKey}->${destinationKey}`;
  const estimates = {
    "chennai->salem": 4800,
    "chennai->pondicherry": 2600,
    "salem->pondicherry": 5200,
    "salem->chennai": 4800,
    "bangalore->salem": 3200,
  };

  if (estimates[routeKey]) return estimates[routeKey];
  if (originKey === destinationKey) return 1500;
  return 4000;
};

const computeFoodCost = (destinationKey) => {
  const foodBands = {
    salem: 700,
    yercaud: 850,
    pondicherry: 900,
    chennai: 850,
    "new delhi": 950,
  };
  return foodBands[destinationKey] || 800;
};

const findMatches = (preferences = [], haystack = "") => {
  if (!Array.isArray(preferences)) return [];
  const lowerHaystack = haystack.toLowerCase();
  return preferences.filter((pref) => lowerHaystack.includes(pref.toLowerCase()));
};

class TripPlannerTool {
  static description = "Plan itinerary, food, hotel, and culture highlights for a destination";

  static parameters = {
    origin: "string",
    destination: "string",
    durationDays: "number",
    preferences: "array",
    budget: "number",
  };

  static async execute({ origin, destination, durationDays, preferences, budget } = {}) {
    const resolvedDestination = destination || "Destination";
    const resolvedDuration = Number(durationDays) || 3;
    const normalizedPrefs = Array.isArray(preferences) ? preferences : [];

    const plannerResult = await TripPlannerImplementation.execute({
      destination: resolvedDestination,
      days: resolvedDuration,
      budget,
    });

    const itineraryText = plannerResult.itinerary.map((day) => day.plan).join(" \n ");
    const matchedPreferences = findMatches(
      normalizedPrefs,
      `${itineraryText} ${plannerResult.attractionHighlights.join(" ")} ${plannerResult.foodRecommendations.join(" ")}`
    );

    return {
      destination: plannerResult.destination,
      durationDays: plannerResult.days,
      itinerary: plannerResult.itinerary,
      attractionHighlights: plannerResult.attractionHighlights,
      foodRecommendations: plannerResult.foodRecommendations,
      hotelRecommendations: plannerResult.hotelRecommendations,
      culturalNotes: plannerResult.culturalNotes,
      travelTips: plannerResult.travelTips,
      suggestedBudget: plannerResult.suggestedBudget,
      budgetFit: plannerResult.budgetFit,
      preferencesMatched: matchedPreferences,
      origin: origin || "Origin",
    };
  }
}

class WeatherTool {
  static description = "Get contextual mock weather info for a location";

  static parameters = {
    location: "string",
  };

  static async execute({ location } = {}) {
    const resolvedLocation = location || "Destination";
    const normalizedLocation = toKey(resolvedLocation);
    const preset = WEATHER_PRESETS[normalizedLocation] || WEATHER_PRESETS[toKey(resolvedLocation.replace(/beach/i, ""))];
    const weather = preset || DEFAULT_WEATHER(resolvedLocation);

    return {
      location: resolvedLocation,
      overview: weather.overview,
      details: weather.details,
    };
  }
}

class BudgetCalculatorTool {
  static description = "Estimate travel costs";

  static parameters = {
    days: "number",
    people: "number",
    hotelPerNight: "number",
    transport: "number",
    foodPerDay: "number",
    destination: "string",
    origin: "string",
  };

  static async execute({
    days = 3,
    people = 2,
    hotelPerNight = 3000,
    transport,
    foodPerDay,
    destination,
    origin,
  } = {}) {
    const normalizedDestination = toKey(destination || "");
    const normalizedOrigin = toKey(origin || "");

    const resolvedFoodPerDay = foodPerDay || computeFoodCost(normalizedDestination);
    const resolvedTransport = transport !== undefined ? transport : computeTransportEstimate(normalizedOrigin, normalizedDestination);

    const hotel = hotelPerNight * days;
    const food = resolvedFoodPerDay * people * days;
    const total = hotel + food + resolvedTransport;

    return {
      estimate: total,
      breakdown: {
        hotel,
        food,
        transport: resolvedTransport,
      },
      withinBudget: total <= 20000,
      notes:
        total <= 20000
          ? "Estimated spend fits within a typical weekend budget of ₹20k."
          : "Consider adjusting resort category, reducing activities, or extending the budget.",
    };
  }
}

export { TripPlannerTool, WeatherTool, BudgetCalculatorTool };

export default {
  tripPlanner: TripPlannerTool,
  weatherTool: WeatherTool,
  budgetCalculator: BudgetCalculatorTool,
};
