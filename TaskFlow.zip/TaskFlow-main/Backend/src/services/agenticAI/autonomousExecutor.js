import Goal from "../../models/Goal.js";
import FreeAgent from "./freeAgent.js";
import toolRegistry from "../tools/index.js";
import { getGoalProgressSnapshot, updateGoalProgress } from "../../utils/goalProgress.js";

const properCase = (value = "") =>
  value
    .toString()
    .split(/\s+/)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")
    .trim();

const toKey = (value = "") => value.toString().trim().toLowerCase();

const FALLBACK_PRESETS = [
  {
    key: "salem-weekend",
    matchers: ["salem", "yercaud"],
    tags: ["hill", "city"],
    destination: "Salem & Yercaud Weekend",
    theme: "hill-station retreat",
    distance: (origin) =>
      origin
        ? `Approx. 340 km (5 hr 45 min) drive from ${origin} to Salem via NH44; continue 22 km uphill to Yercaud's viewpoints.`
        : "Plan the NH44 drive to Salem and include the 22 km ghat road to Yercaud.",
    averageHotelPerNight: 3200,
    transportEstimate: () => 5500,
    weatherOverview: "Expect pleasant hill-station weather (~20-26°C) with cooler evenings in Yercaud—carry a light jacket.",
    lodging: [
      "Grand Estancia – business-class stay in Salem city (~₹4800/night)",
      "CJ Pallazzio – centrally located boutique hotel (~₹4200/night)",
      "The Brook Resorts & Spa, Yercaud – forest stay with campfire (~₹3500/night)",
      "Great Trails Yercaud – lake-facing cottages for sunrise views (~₹5200/night)",
    ],
    food: [
      "Filter coffee and piping hot pongal at Saravana Bhavan, Salem",
      "Pepper chicken and Malabar parotta at Kumar Mess",
      "Try jackfruit payasam and home-style meals at Yercaud lake cafes",
    ],
    attractions: [
      "Day trip to Yercaud: Loop Road drive, Lady's Seat viewpoint, and Emerald Lake boating",
      "Montfort School and Shevaroy Temple hike for panoramic vistas",
      "Evening shopping at Salem's cherry seed and textile markets",
      "Explore 1008 Lingam Temple and heritage steel plant museum",
    ],
    special: [
      "Book a plantation walk with local pepper and coffee growers",
      "Experience night safari at Karadiyur view point (with guide)",
      "Pick up handmade soaps and spices from Cauvery Peak estate",
    ],
    nextSteps: [
      "Block a city hotel for night one and Yercaud resort for night two",
      "Arrange a self-drive or cab with experienced hill drivers",
      "Reserve dinner slots at Kumar Mess or Salem RR for authentic fare",
      "Pack layers for the hill station plus comfy shoes for short treks",
    ],
    tasks: [
      "Book Salem city hotel and Yercaud hill resort",
      "Confirm cab/self-drive with ghat-road experience",
      "Plan Loop Road drive and Emerald Lake boating slots",
      "List cafes for pepper coffee and regional snacks",
    ],
  },
  {
    key: "mahabalipuram",
    matchers: ["chennai", "mahabalipuram", "mamallapuram"],
    tags: ["beach"],
    destination: "Mahabalipuram Beach",
    theme: "coastal escape",
    distance: (origin) =>
      origin.toLowerCase().includes("chennai")
        ? `Approx. 60 km (1 hr 30 min) drive from ${origin} to Mahabalipuram via East Coast Road.`
        : `Approx. 350 km drive from ${origin} to Mahabalipuram via NH16 (verify current route conditions).`,
    averageHotelPerNight: 3500,
    transportEstimate: (origin) => (origin.toLowerCase().includes("chennai") ? 2500 : 7000),
    weatherOverview: "Expect warm, humid coastal weather (~28-32°C) with pleasant evenings.",
    lodging: [
      "Radisson Blu Resort Temple Bay – beachfront resort with infinity pool (~₹8500/night)",
      "Chariot Beach Resort – family-friendly stay right on Mahabalipuram beach (~₹6000/night)",
      "Grande Bay Resort & Spa – boutique resort with seafood restaurant (~₹5500/night)",
      "Greenwoods Beach Resort – budget-friendly cottages near Shore Temple (~₹3200/night)",
    ],
    food: [
      "Try the famed fried prawns and fish curry at Moonrakers",
      "Breakfast with masala dosas and filter coffee at local tiffin stalls",
      "Sunset beach barbecue (check with resort for arrangements)",
    ],
    attractions: [
      "Shore Temple at sunrise for panoramic Bay of Bengal views",
      "Pancha Rathas and Arjuna's Penance rock carvings",
      "Evening stroll along Mahabalipuram Beach + lighthouse viewpoint",
      "Optional scuba or surfing session with local adventure operators",
    ],
    special: [
      "Attend the light-and-sound show at Shore Temple",
      "Shop handcrafted stone sculptures along the Artists' Village street",
      "Take a short drive to Kovalam (Covelong) for water sports",
    ],
    nextSteps: [
      "Confirm resort booking based on budget and availability",
      "Pre-book cab or self-drive hire for Chennai ↔ Mahabalipuram",
      "Reserve seafood lunch at Moonrakers or Sea Shore Restaurant",
      "Pack beachwear, sunscreen, and light cottons for humid weather",
    ],
    tasks: [
      "Compare beachfront resorts and lock weekend rate",
      "Reserve seafood dinner along Mahabalipuram promenade",
      "Plan sightseeing slots for Shore Temple and Pancha Rathas",
      "Arrange transport from origin via ECR with buffer for traffic",
    ],
  },
  {
    key: "pondicherry",
    matchers: ["salem", "pondicherry", "puducherry", "cuddalore"],
    destination: "Pondicherry Rock Beach",
    tags: ["beach"],
    theme: "French-quarter beach break",
    distance: (origin) =>
      origin
        ? `Approx. 230 km (4 hr 30 min) drive from ${origin} to Pondicherry via NH79 & NH32; consider an early morning start to beat city traffic.`
        : "Plan your route to Pondicherry and account for NH32 tolls.",
    averageHotelPerNight: 4200,
    transportEstimate: () => 6000,
    weatherOverview: "Expect breezy coastal weather (~26-31°C) with occasional evening drizzle—carry a light rain jacket.",
    lodging: [
      "The Promenade – upscale sea-facing stay on Goubert Avenue (~₹7500/night)",
      "Palais de Mahe – heritage French Quarter hotel with pool (~₹6500/night)",
      "Le Pondy Beach Resort – lagoon-view villas with private beach access (~₹5800/night)",
      "Villa Shanti – boutique stay with courtyard dining (~₹4800/night)",
    ],
    food: [
      "Fresh seafood platters at Le Dupleix or Theevu Plage",
      "Croissants and filter coffee breakfast crawl around White Town",
      "Evening stroll with street snacks along Rock Beach promenade",
    ],
    attractions: [
      "Sunrise meditation at Sri Aurobindo Ashram beach entrance",
      "Explore the French & Tamil Quarters on a heritage walk",
      "Boat ride through the Pichavaram mangroves (en route via Chidambaram)",
      "Relax at Paradise Beach for soft sands and calmer waters",
    ],
    special: [
      "Book an Ayurvedic spa session at Auroville",
      "Sign up for a Pondicherry cycling tour at dawn",
      "Shop handmade candles and ceramics at local ateliers",
    ],
    nextSteps: [
      "Block your stay in White Town or Paradise Beach depending on vibe",
      "Reserve a table for a seafood dinner overlooking the promenade",
      "Plan a detour to Auroville for cafes and community spaces",
      "Carry beachwear plus modest attire for temple visits",
    ],
    tasks: [
      "Book White Town heritage stay or Paradise Beach resort",
      "Schedule Auroville visit with pre-booked entry times",
      "List French-Indian fusion cafes for meals",
      "Plan mangrove boat ride via Pichavaram eco-tour",
    ],
  },
  {
    key: "kodaikanal",
    matchers: ["kodaikanal", "kodai", "madurai", "palani"],
    destination: "Kodaikanal Hill Retreat",
    tags: ["hill", "romantic"],
    theme: "misty lake getaway",
    distance: (origin) =>
      origin
        ? `Approx. 120 km (3 hr 30 min) scenic drive from ${origin} to Kodaikanal via Palani Ghat Road; plan buffer for hairpin bends.`
        : "Plan the uphill Palani ghat route and schedule breaks for viewpoints.",
    averageHotelPerNight: 3600,
    transportEstimate: (origin) => (origin.toLowerCase().includes("madurai") ? 3200 : 5400),
    weatherOverview: "Expect cool 18-24°C days with misty mornings around Kodaikanal Lake—carry light sweaters and rain shields.",
    lodging: [
      "Kodai Resort Hotel – cottages near Coaker's Walk (~₹4500/night)",
      "The Carlton – lakefront luxury stay with spa (~₹9000/night)",
      "Great Trails Kodaikanal – cliff-edge rooms with valley views (~₹6200/night)",
      "Lilly's Valley Resort – heritage stone cottages with gardens (~₹3800/night)",
    ],
    food: [
      "Hot chocolate & brownies at Pastry Corner",
      "Homemade chocolates and cheese tasting at local co-op",
      "Cozy dinner at Cloud Street Café with wood-fired pizza",
    ],
    attractions: [
      "Boat ride across Kodaikanal Lake at sunrise",
      "Visit Pillar Rocks, Guna Caves, and Pine Forest for photo stops",
      "Romantic stroll along Coaker's Walk and Bryant Park",
      "Day trip to Mannavanur Lake for meadows and horse rides",
    ],
    special: [
      "Book a night astronomy session at Kodaikanal Observatory",
      "Sign up for a handmade chocolate workshop",
      "Catch sunset at Moir Point with picnic setup",
    ],
    nextSteps: [
      "Reserve lake-facing cottage or boutique stay",
      "Pre-book boating slots and Mannavanur eco-tour permits",
      "Arrange cab with hill-driving experience from origin city",
      "Pack layers, rain jacket, and comfortable trekking shoes",
    ],
    tasks: [
      "Book accommodation near Kodaikanal Lake",
      "Secure cab or self-drive permits for ghat roads",
      "List romantic viewpoints (Coaker's Walk, Pillar Rocks)",
      "Plan café-hopping for hot chocolate and local treats",
    ],
  },
];

const inferLocationHint = (goal = {}) => {
  const title = goal.title?.toLowerCase() || "";
  const description = goal.description?.toLowerCase() || "";
  const combined = `${title} ${description}`;
  const nearMatch = combined.match(/near\s+([a-z\s]+)/i);
  if (nearMatch?.[1]) {
    return nearMatch[1].trim();
  }
  const visitMatch = combined.match(/to\s+([a-z\s]+)/i);
  return visitMatch?.[1]?.trim() || "";
};

const pickFallbackPreset = (goal = {}, origin = "", locationHint = "", metadataDestination = "") => {
  const haystack = `${origin} ${locationHint} ${metadataDestination}`.toLowerCase();
  const content = `${goal.title || ""} ${goal.description || ""}`.toLowerCase();
  const isBeachGoal = content.includes("beach");
  const destinationKey = toKey(metadataDestination);

  if (destinationKey) {
    const directMatch = FALLBACK_PRESETS.find((preset) =>
      preset.matchers.some((matcher) => destinationKey.includes(matcher))
    );
    if (directMatch) return directMatch;
  }

  const matches = FALLBACK_PRESETS.filter((preset) =>
    preset.matchers.some((matcher) => haystack.includes(matcher))
  );

  if (matches.length === 0) {
    if (isBeachGoal) {
      const beachPreset = FALLBACK_PRESETS.find((preset) => preset.tags?.includes("beach"));
      if (beachPreset) return beachPreset;
    }
    return FALLBACK_PRESETS[0];
  }

  if (isBeachGoal) {
    const preferred = matches.find((preset) => preset.tags?.includes("beach"));
    if (preferred) return preferred;
  }

  return matches[0];
};

const buildFallbackSummary = (goal, metadata = {}, progress = []) => {
  const originRaw = metadata.origin || "Chennai";
  const origin = properCase(originRaw);
  const locationHint = inferLocationHint(goal);
  const metadataDestination = metadata.destination ? metadata.destination.toString() : "";
  const preset = pickFallbackPreset(goal, originRaw, locationHint, metadataDestination);
  const destination = properCase(metadataDestination || preset.destination);
  const travelers = Number(metadata.travelers) || 2;
  const durationDays = Number(metadata.durationDays) || Number(metadata.days) || 3;
  const budget = Number(metadata.budgetINR) || 20000;

  const averageHotelPerNight = preset.averageHotelPerNight;
  const foodPerDay = 900;
  const transportEstimate = preset.transportEstimate(origin);
  const totalHotel = averageHotelPerNight * durationDays;
  const totalFood = foodPerDay * travelers * durationDays;
  const totalBudget = totalHotel + totalFood + transportEstimate;
  const withinBudget = budget >= totalBudget;

  const weatherDetails = [
    "Carry UV protection and stay hydrated during day outings.",
    "Pack layers for cooler evenings and sudden weather shifts.",
  ];

  const theme = preset.theme || "travel escape";
  const recommendedTasks = preset.tasks || [
    "Book accommodation matching budget and theme",
    "Confirm transport options and travel timings",
    "List top attractions and dining spots",
    "Check weather and pack essentials",
  ];

  return {
    summary: `Plan locked for ${destination}: a ${durationDays}-day ${theme} tailored for ${travelers > 1 ? `${travelers} travelers` : "a solo traveler"}.
Distance reminder: ${preset.distance(origin)}`,
    weather: {
      overview: preset.weatherOverview,
      details: weatherDetails,
    },
    lodging: preset.lodging,
    food: preset.food,
    mustSeeAttractions: preset.attractions,
    budget: {
      estimate: totalBudget,
      withinBudget,
      notes: withinBudget
        ? `Estimated spend (~₹${totalBudget}) fits within the provided budget of ₹${budget}.`
        : `Estimated spend (~₹${totalBudget}) exceeds the provided budget of ₹${budget}; consider adjusting resort category or trip length.`,
    },
    specialExperiences: preset.special,
    nextSteps: preset.nextSteps,
    recommendedTasks: recommendedTasks,
    generatedFromFallback: true,
  };
};

const DEFAULT_MAX_ITERATIONS = Number(process.env.AGENT_MAX_ITERATIONS || 10);

const defaultAgent = new FreeAgent(process.env.OLLAMA_MODEL || "llama3");

export const startExecution = async (goalId, userId, options = {}) => {
  const {
    agentInstance = defaultAgent,
    toolRegistryInstance = toolRegistry,
    progressUtils = { getGoalProgressSnapshot, updateGoalProgress },
    maxIterations = DEFAULT_MAX_ITERATIONS,
  } = options;

  const goal = await Goal.findOne({ _id: goalId, owner: userId }).populate("tasks");
  if (!goal) throw new Error("Goal not found");

  console.info(`🚀 Starting execution for goal: ${goal.title}`);

  let context = {
    goal: goal.title,
    description: goal.description,
    metadata: goal.metadata ? Object.fromEntries(goal.metadata) : {},
    progress: [],
    tasks: goal.tasks.map((task) => ({
      id: task._id.toString(),
      title: task.title,
      status: task.status,
      metadata: task.metadata,
    })),
  };

  let iteration = 0;

  while (iteration < maxIterations) {
    const action = await agentInstance.decideNextAction(context);

    if (!action.shouldContinue) {
      console.info("🛑 Agent decided to stop.");
      break;
    }

    const { tool, parameters } = action;
    const ToolClass = toolRegistryInstance.get(tool);

    if (!ToolClass) {
      console.warn(`⚠️ Unknown tool: ${tool}`);
      break;
    }

    try {
      const result = await ToolClass.execute(parameters || {});
      context.progress.push({ tool, parameters, result });
      goal.executionLogs = goal.executionLogs || [];
      goal.executionLogs.push({
        iteration,
        action: tool,
        result,
        reasoning: action.reasoning,
        timestamp: new Date(),
      });
      await goal.save();
    } catch (err) {
      console.error("Tool error:", err);
      context.progress.push({ tool, parameters, error: err.message });
    }

    iteration += 1;
  }

  let finalSummary = await agentInstance.synthesizeResults(goal.title, context.progress);

  const summaryMissing = !finalSummary || !finalSummary.summary || finalSummary.summary.includes("No summary");
  const noWeather = !finalSummary?.weather?.overview;
  const noLodging = !finalSummary?.lodging || finalSummary.lodging.length === 0;

  if ((context.progress.length === 0 && summaryMissing) || (summaryMissing && noWeather && noLodging)) {
    finalSummary = buildFallbackSummary(goal, goal.metadata ? Object.fromEntries(goal.metadata) : {}, context.progress);
    goal.executionLogs = goal.executionLogs || [];
    goal.executionLogs.push({
      iteration,
      action: "fallback_summary",
      result: finalSummary,
      reasoning: "Generated structured summary via fallback presets because agent synthesis returned incomplete data.",
      timestamp: new Date(),
    });
  }

  // Enrich minimal summaries with fallback details (merge strategy)
  const ensureEnriched = () => {
    const needsEnrichment =
      !finalSummary ||
      !finalSummary.budget || !finalSummary.budget.estimate || finalSummary.budget.estimate <= 0 ||
      !finalSummary.lodging || finalSummary.lodging.length === 0 ||
      !finalSummary.mustSeeAttractions || finalSummary.mustSeeAttractions.length === 0 ||
      !finalSummary.nextSteps || finalSummary.nextSteps.length === 0;

    if (!needsEnrichment) return;

    const metaObj = goal.metadata ? Object.fromEntries(goal.metadata) : {};
    const fallback = buildFallbackSummary(goal, metaObj, context.progress);

    const pickArray = (a, b) => (Array.isArray(a) && a.length ? a : b || []);
    const pickBudget = (a, b) => (a && a.estimate && a.estimate > 0 ? a : b);
    const pickWeather = (a, b) => {
      if (!a || !a.overview) return b;
      const hasDetails = Array.isArray(a.details) && a.details.length > 0;
      return hasDetails ? a : b || a;
    };

    finalSummary = {
      ...fallback,
      ...finalSummary,
      weather: pickWeather(finalSummary.weather, fallback.weather),
      lodging: pickArray(finalSummary.lodging, fallback.lodging),
      food: pickArray(finalSummary.food, fallback.food),
      mustSeeAttractions: pickArray(finalSummary.mustSeeAttractions, fallback.mustSeeAttractions),
      nextSteps: pickArray(finalSummary.nextSteps, fallback.nextSteps),
      recommendedTasks: pickArray(finalSummary.recommendedTasks, fallback.recommendedTasks),
      budget: pickBudget(finalSummary.budget, fallback.budget),
      enrichedWithFallback: true,
    };

    goal.executionLogs = goal.executionLogs || [];
    goal.executionLogs.push({
      iteration: iteration + 1,
      action: "fallback_enrichment",
      result: finalSummary,
      reasoning: "Enriched agent summary with fallback presets to fill missing sections.",
      timestamp: new Date(),
    });
  };

  ensureEnriched();

  goal.finalSynthesis = finalSummary;
  goal.status = "completed";
  goal.completedAt = new Date();
  await goal.save();

  await progressUtils.updateGoalProgress(goal._id);

  console.info("✅ Goal execution complete.");
  return {
    goal,
    progressSnapshot: await progressUtils.getGoalProgressSnapshot(goal._id),
  };
};

export default {
  startExecution,
};
