import { execSync } from "child_process";

const sanitizePrompt = (input = "") => {
  if (typeof input !== "string") return "";
  return input.replace(/"/g, "'").replace(/`/g, "'");
};

const runOllamaCommand = (command, input) => {
  try {
    return execSync(command, {
      encoding: "utf-8",
      maxBuffer: 1024 * 1024 * 10,
      stdio: ["pipe", "pipe", "pipe"],
      input,
    }).trim();
  } catch (error) {
    const stderr = error.stderr?.toString() || error.message;
    throw new Error(stderr || "Error running Ollama model.");
  }
};

const toTitleCase = (value = "") =>
  value
    .toString()
    .split(/\s+/)
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")
    .trim();

const extractNumber = (text = "", regex, mapper = Number) => {
  const match = text.match(regex);
  if (!match) return undefined;
  const normalized = match[1]?.replace(/[,₹\s]/g, "");
  const value = mapper(normalized);
  return Number.isFinite(value) && !Number.isNaN(value) ? value : undefined;
};

const detectPreferences = (text = "") => {
  const keywords = [
    "beach",
    "hill",
    "hill station",
    "romantic",
    "adventure",
    "wildlife",
    "heritage",
    "food",
    "foodie",
    "photography",
    "luxury",
    "budget",
    "spa",
    "shopping",
    "nature",
  ];
  const lower = text.toLowerCase();
  const prefs = keywords.filter((keyword) => lower.includes(keyword)).map((keyword) => keyword.replace(/\s+/g, " "));
  return Array.from(new Set(prefs));
};

const buildDefaultTasks = ({ destination, origin, durationDays, budgetINR, preferences }) => {
  const tasks = [
    {
      title: `Book stay in ${destination}`,
      description: `Research and reserve accommodation that fits the budget of ₹${budgetINR || "—"}.`,
    },
    {
      title: `Plan travel from ${origin} to ${destination}`,
      description: "Compare transport options, timings, and transfer logistics.",
    },
    {
      title: `Create a ${durationDays}-day itinerary for ${destination}`,
      description: "Balance sightseeing, dining, and downtime for each day.",
    },
    {
      title: "Estimate detailed trip budget",
      description: "Account for lodging, transport, food, activities, and contingency costs.",
    },
  ];

  const lowerPrefs = preferences.map((pref) => pref.toLowerCase());
  if (lowerPrefs.includes("wildlife")) {
    tasks.push({
      title: "Reserve safari or sanctuary permits",
      description: "Check availability, rules, and timing for wildlife experiences.",
    });
  }
  if (lowerPrefs.includes("romantic")) {
    tasks.push({
      title: "Plan romantic experiences",
      description: "Schedule sunset viewpoints, private dinners, or couple-friendly activities.",
    });
  }
  if (lowerPrefs.includes("adventure")) {
    tasks.push({
      title: "Arrange adventure activities",
      description: "Confirm availability and safety requirements for treks or adventure sports.",
    });
  }
  return tasks.slice(0, 6);
};

const inferStructureFromMessage = (message = "") => {
  const cleanMessage = message || "Plan a trip";
  const lower = cleanMessage.toLowerCase();

  const destinationMatch = cleanMessage.match(/to\s+([a-zA-Z\s]+)/i) || cleanMessage.match(/in\s+([a-zA-Z\s]+)/i);
  const originMatch = cleanMessage.match(/from\s+([a-zA-Z\s]+)/i);
  const duration = extractNumber(lower, /(\d+)\s*(?:day|night)/i) || 3;
  const travelers = extractNumber(lower, /(\d+)\s*(?:people|persons|travellers|travelers)/i) || 2;
  const budget = extractNumber(lower, /(?:₹|rs\.?|inr)?\s*([\d,]+)\s*(?:budget|rupees|rs|inr)?/i);

  const destination = destinationMatch ? toTitleCase(destinationMatch[1]) : "Destination";
  const origin = originMatch ? toTitleCase(originMatch[1]) : "Origin City";
  const preferences = detectPreferences(lower);

  return {
    title: `Plan a trip to ${destination}`,
    description: cleanMessage.trim(),
    metadata: {
      origin,
      destination,
      durationDays: duration,
      travelers,
      preferences,
      ...(budget ? { budgetINR: budget } : {}),
    },
  };
};

const normalizeTaskItem = (task) => {
  if (!task) return null;
  if (typeof task === "string") {
    return { title: toTitleCase(task), description: "" };
  }
  if (typeof task === "object") {
    const title = task.title || task.name || task.summary;
    if (!title) return null;
    const description = task.description || task.details || "";
    return { title: title.trim(), description: description.trim() };
  }
  return null;
};

const mergeTripStructures = (base, incoming) => {
  const result = { ...base };
  if (incoming.title) result.title = incoming.title;
  if (incoming.description) result.description = incoming.description;

  const baseMetadata = { ...(base.metadata || {}) };
  const incomingMetadata = { ...(incoming.metadata || {}) };

  const mergedMetadata = { ...baseMetadata, ...incomingMetadata };

  if (Array.isArray(mergedMetadata.preferences)) {
    mergedMetadata.preferences = Array.from(new Set(mergedMetadata.preferences.map((pref) => pref.toString())));
  }

  result.metadata = mergedMetadata;

  const incomingTasks = Array.isArray(incoming.tasks) ? incoming.tasks.map(normalizeTaskItem).filter(Boolean) : [];
  if (incomingTasks.length > 0) {
    result.tasks = incomingTasks;
  }

  return result;
};

export default class FreeAgent {
  constructor(model = process.env.OLLAMA_MODEL || "phi3") {
    this.model = model;
  }

  async queryOllama(prompt) {
    const sanitizedPrompt = sanitizePrompt(prompt);
    const host = process.env.OLLAMA_HOST;
    const hostEnv = host ? `OLLAMA_HOST=${host} ` : "";
    const command = `${hostEnv}ollama run ${this.model}`;
    try {
      return runOllamaCommand(command, `${sanitizedPrompt}\n`);
    } catch (error) {
      console.error("Ollama Error:", error.message);
      return "Error running Ollama model.";
    }
  }

  async interpretTripRequest(message, context = {}) {
    const fallback = inferStructureFromMessage(message);
    const prompt = `You convert travel requests into structured JSON.
Message: """${message}"""

Return ONLY JSON with keys:
{
  "title": string,
  "description": string,
  "metadata": {
    "origin": string,
    "destination": string,
    "durationDays": number,
    "travelers": number,
    "budgetINR": number | null,
    "preferences": string[]
  },
  "tasks": [
    { "title": string, "description": string }
  ]
}

Rules:
- Infer reasonable defaults when details are missing.
- Use integer rupee values for budgetINR if mentioned; otherwise null.
- Keep preferences as lowercase keywords (e.g., "wildlife", "romantic").
- Provide 3-5 relevant tasks covering lodging, travel, activities, and budgeting.
- Do not include commentary or markdown.
`;

    let parsed = {};
    const response = await this.queryOllama(prompt);
    try {
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      parsed = jsonMatch ? JSON.parse(jsonMatch[0]) : {};
    } catch (error) {
      console.warn("Failed to parse interpretTripRequest output", error.message);
    }

    const merged = mergeTripStructures(fallback, parsed);

    const metadata = {
      ...(merged.metadata || {}),
      ...(context.metadata || {}),
    };

    if (!metadata.destination && context.defaultDestination) {
      metadata.destination = context.defaultDestination;
    }

    metadata.origin = metadata.origin ? toTitleCase(metadata.origin) : fallback.metadata.origin;
    metadata.destination = metadata.destination ? toTitleCase(metadata.destination) : fallback.metadata.destination;

    metadata.durationDays = Number(metadata.durationDays) || fallback.metadata.durationDays || 3;
    metadata.travelers = Number(metadata.travelers) || fallback.metadata.travelers || 2;

    if (metadata.budgetINR !== null && metadata.budgetINR !== undefined) {
      metadata.budgetINR = Number(metadata.budgetINR);
    } else if (fallback.metadata.budgetINR) {
      metadata.budgetINR = fallback.metadata.budgetINR;
    }

    if (!Array.isArray(metadata.preferences) || metadata.preferences.length === 0) {
      metadata.preferences = fallback.metadata.preferences || [];
    } else {
      metadata.preferences = Array.from(new Set(metadata.preferences.map((pref) => pref.toString().toLowerCase())));
    }

    const tasks = Array.isArray(merged.tasks) && merged.tasks.length > 0
      ? merged.tasks.map(normalizeTaskItem).filter(Boolean)
      : buildDefaultTasks({
          destination: metadata.destination,
          origin: metadata.origin,
          durationDays: metadata.durationDays,
          budgetINR: metadata.budgetINR,
          preferences: metadata.preferences,
        });

    return {
      title: merged.title || fallback.title,
      description: merged.description || fallback.description,
      metadata,
      tasks,
      originalMessage: message,
      raw: response,
    };
  }

  async decomposeGoal(goalDescription, constraints = {}) {
    const prompt = `
You are an intelligent travel planner assistant.
Break down this goal into clear, actionable tasks.

Goal: "${goalDescription}"
Constraints: ${JSON.stringify(constraints)}

Return ONLY valid JSON array like this:
[
  {"title":"Find travel dates","description":"Choose suitable dates and duration","priority":1},
  {"title":"Plan budget","description":"Estimate travel and stay cost","priority":2},
  {"title":"Find hotels","description":"Search budget hotels in the destination","priority":3},
  {"title":"Prepare itinerary","description":"List key places to visit","priority":4}
]
`;
    const output = await this.queryOllama(prompt);
    try {
      const jsonMatch = output.match(/\[[\s\S]*\]/);
      return jsonMatch ? JSON.parse(jsonMatch[0]) : [];
    } catch (error) {
      console.warn("Failed to parse decomposeGoal output", error.message);
      return [];
    }
  }

  async decideNextAction(context) {
    const prompt = `
You are deciding the next best action for a trip-planning goal.

Context (goal, description, metadata may include budget, travel dates, origin/destination, group size):
${JSON.stringify(context, null, 2)}

Tools available:
- "web_search": search travel info (provide a clear query string)
- "weather": get weather forecast (provide { "city": "Destination" })
- "price_compare": compare flight/hotel prices (requires an API endpoint; use only if configured)
- "budget_calculator": estimate total trip cost (include days, people, transport, foodPerDay, hotelPerNight, and optional budget)
- "trip_planner": generate daily itinerary plus food, hotel, attraction highlights (provide destination, days, and optional budget)
- "distance_calculator": estimate travel distance/duration between origin and destination (provide { "origin": "City", "destination": "City" })

Guidelines:
- Use metadata (e.g., destination, budget) when present.
- Call weather early to report conditions for travel dates.
- Use budget_calculator after gathering key cost inputs to confirm if the plan fits the budget.
- Stop when you have weather insight, itinerary (trip_planner), budget evaluation, and at least one cultural/food/hotel insight.

Return ONLY JSON:
{
  "tool": "web_search" | "weather" | "price_compare" | "budget_calculator" | "trip_planner" | "distance_calculator" | null,
  "parameters": {},
  "reasoning": "why this step is next",
  "shouldContinue": true | false
}
`;
    const output = await this.queryOllama(prompt);
    try {
      const jsonMatch = output.match(/\{[\s\S]*\}/);
      return jsonMatch ? JSON.parse(jsonMatch[0]) : { tool: null, reasoning: "No response", shouldContinue: false };
    } catch (error) {
      console.warn("Failed to parse decideNextAction output", error.message);
      return { tool: null, reasoning: "Failed to parse", shouldContinue: false };
    }
  }

  async synthesizeResults(goal, discoveries) {
    const prompt = `
You have gathered the following trip-planning info. Summarize and make final recommendations.

Goal: ${goal}
Data: ${JSON.stringify(discoveries, null, 2)}

Return ONLY JSON:
{
  "summary": "",
  "weather": {
    "overview": "",
    "details": ["", ""]
  },
  "lodging": ["", ""],
  "food": ["", ""],
  "mustSeeAttractions": ["", ""],
  "budget": {
    "estimate": 0,
    "withinBudget": true,
    "notes": ""
  },
  "specialExperiences": ["", ""],
  "nextSteps": ["", ""]
}
`;
    const output = await this.queryOllama(prompt);
    try {
      const jsonMatch = output.match(/\{[\s\S]*\}/);
      return jsonMatch
        ? JSON.parse(jsonMatch[0])
        : {
            summary: "No summary available.",
            weather: { overview: "", details: [] },
            lodging: [],
            food: [],
            mustSeeAttractions: [],
            budget: { estimate: 0, withinBudget: true, notes: "" },
            specialExperiences: [],
            nextSteps: [],
          };
    } catch (error) {
      console.warn("Failed to parse synthesizeResults output", error.message);
      return {
        summary: "No summary available.",
        weather: { overview: "", details: [] },
        lodging: [],
        food: [],
        mustSeeAttractions: [],
        budget: { estimate: 0, withinBudget: true, notes: "" },
        specialExperiences: [],
        nextSteps: [],
      };
    }
  }
}
