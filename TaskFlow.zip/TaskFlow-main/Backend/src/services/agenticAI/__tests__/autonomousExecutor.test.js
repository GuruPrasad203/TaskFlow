import { jest } from "@jest/globals";
import Goal from "../../../models/Goal.js";
import toolRegistry from "../../tools/toolRegistry.js";
import { startExecution } from "../autonomousExecutor.js";

describe("autonomousExecutor", () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  it("should throw if goal not found", async () => {
    jest.spyOn(Goal, "findOne").mockReturnValue({
      populate: jest.fn().mockResolvedValue(null),
    });
    await expect(startExecution("goal", "user")).rejects.toThrow("Goal not found");
  });

  it("should stop when agent says to stop", async () => {
    const mockGoal = {
      title: "Test",
      description: "",
      tasks: [],
      executionLogs: [],
      save: jest.fn(),
      _id: "123",
    };
    jest.spyOn(Goal, "findOne").mockReturnValue({
      populate: jest.fn().mockResolvedValue(mockGoal),
    });
    const agentMock = {
      decideNextAction: jest.fn().mockResolvedValue({ shouldContinue: false }),
      synthesizeResults: jest.fn().mockResolvedValue({ summary: "done" }),
    };
    const toolsMock = {
      get: jest.fn().mockReturnValue(null),
    };
    const progressMock = {
      updateGoalProgress: jest.fn().mockResolvedValue(null),
      getGoalProgressSnapshot: jest.fn().mockResolvedValue({}),
    };

    const result = await startExecution("goal", "user", {
      agentInstance: agentMock,
      toolRegistryInstance: toolsMock,
      progressUtils: progressMock,
    });
    expect(result.goal).toBe(mockGoal);
    expect(mockGoal.save).toHaveBeenCalled();
  });

  it("falls back to the Salem preset for hill-station weekend requests", async () => {
    const mockGoal = {
      title: "Need a weekend plan to go Salem",
      description: "",
      metadata: new Map(),
      tasks: [],
      executionLogs: [],
      save: jest.fn(),
      _id: "456",
    };

    jest.spyOn(Goal, "findOne").mockReturnValue({
      populate: jest.fn().mockResolvedValue(mockGoal),
    });

    const agentMock = {
      decideNextAction: jest.fn().mockResolvedValue({ shouldContinue: false }),
      synthesizeResults: jest.fn().mockResolvedValue({}),
    };

    const progressMock = {
      updateGoalProgress: jest.fn().mockResolvedValue(null),
      getGoalProgressSnapshot: jest.fn().mockResolvedValue({}),
    };

    await startExecution("goal", "user", {
      agentInstance: agentMock,
      toolRegistryInstance: toolRegistry,
      progressUtils: progressMock,
    });

    expect(mockGoal.finalSynthesis.summary).toContain("Salem & Yercaud Weekend");
    expect(mockGoal.finalSynthesis.generatedFromFallback).toBe(true);
    expect(mockGoal.finalSynthesis.recommendedTasks.length).toBeGreaterThan(0);
  });

  it("uses metadata destination to pick the Kodaikanal preset", async () => {
    const mockGoal = {
      title: "Plan a romantic hill getaway",
      description: "",
      metadata: new Map(Object.entries({ origin: "Madurai", destination: "Kodaikanal" })),
      tasks: [],
      executionLogs: [],
      save: jest.fn(),
      _id: "789",
    };

    jest.spyOn(Goal, "findOne").mockReturnValue({
      populate: jest.fn().mockResolvedValue(mockGoal),
    });

    const agentMock = {
      decideNextAction: jest.fn().mockResolvedValue({ shouldContinue: false }),
      synthesizeResults: jest.fn().mockResolvedValue({}),
    };

    const progressMock = {
      updateGoalProgress: jest.fn().mockResolvedValue(null),
      getGoalProgressSnapshot: jest.fn().mockResolvedValue({}),
    };

    await startExecution("goal", "user", {
      agentInstance: agentMock,
      toolRegistryInstance: toolRegistry,
      progressUtils: progressMock,
    });

    expect(mockGoal.finalSynthesis.summary).toContain("Kodaikanal");
    expect(mockGoal.finalSynthesis.summary).toContain("misty");
    expect(mockGoal.finalSynthesis.lodging.some((item) => /Kodaikanal/i.test(item))).toBe(true);
    expect(mockGoal.finalSynthesis.recommendedTasks).toEqual(
      expect.arrayContaining([expect.stringMatching(/Kodaikanal Lake|ghat/i)])
    );
  });
});
