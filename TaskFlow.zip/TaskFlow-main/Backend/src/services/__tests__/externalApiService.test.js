import { beforeEach, describe, expect, it, jest } from "@jest/globals";

const resetEnv = () => {
  delete process.env.WEATHER_API_ENDPOINT;
  delete process.env.WEATHER_API_KEY;
  delete process.env.WEATHER_CACHE_TTL_MS;
};

describe("externalApiService.getWeather", () => {
  beforeEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
    resetEnv();
    jest.unstable_mockModule("axios", () => ({
      __esModule: true,
      default: { get: jest.fn() },
    }));
  });

  it("returns fallback weather when API is not configured", async () => {
    const { getWeather } = await import("../externalApiService.js");
    const { default: axios } = await import("axios");

    const result = await getWeather({ city: "Chennai" });

    expect(result).toMatchObject({
      location: "Chennai",
      source: "fallback",
    });
    expect(result.overview).toContain("weather data unavailable");
    expect(axios.get).not.toHaveBeenCalled();
  });

  it("disables remote weather calls after authentication errors", async () => {
    process.env.WEATHER_API_ENDPOINT = "https://example.com/weather";
    process.env.WEATHER_API_KEY = "invalid";

    const authError = new Error("Unauthorized");
    authError.response = { status: 401, data: { message: "invalid API key" } };
    const { default: axios } = await import("axios");
    axios.get.mockRejectedValue(authError);

    const { getWeather } = await import("../externalApiService.js");

    const firstResult = await getWeather({ city: "Chennai" });
    expect(firstResult.source).toBe("fallback");
    expect(firstResult.overview).toContain("invalid API key");
    expect(axios.get).toHaveBeenCalledTimes(1);

  const secondResult = await getWeather({ city: "Pondicherry" });
    expect(secondResult.source).toBe("fallback");
    expect(secondResult.overview).toContain("invalid API key");
    expect(axios.get).toHaveBeenCalledTimes(1);
  });
});
