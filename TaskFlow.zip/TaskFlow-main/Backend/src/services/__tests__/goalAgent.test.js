import { executeGoal } from "../goalAgent.js";

describe("goalAgent", () => {
  it("crafts a Salem and Yercaud themed plan instead of a beach getaway", async () => {
    const goal = {
      title: "Plan a weekend trip to Salem",
      metadata: {
        origin: "Chennai",
        durationDays: 2,
        travelers: 2,
        preferences: ["scenic views", "hill station"],
        budgetINR: 16000,
      },
    };

    const result = await executeGoal(goal);

    expect(result.finalSynthesis).toBeDefined();
    expect(result.finalSynthesis.summary).toMatch(/Salem/i);
    expect(result.finalSynthesis.lodging.join(" ")).toMatch(/Yercaud|Grand Estancia/);
    expect(result.finalSynthesis.mustSeeAttractions.some((item) => /Yercaud|Pagoda Point/i.test(item))).toBe(true);
    expect(result.finalSynthesis.generatedFromFallback).toBe(false);
    expect(result.finalSynthesis.recommendedTasks.length).toBeGreaterThan(0);
  });

  it("matches preferences when the itinerary covers requested interests", async () => {
    const goal = {
      title: "Plan a cultural weekend to Chennai",
      metadata: {
        origin: "Hyderabad",
        durationDays: 3,
        travelers: 4,
        preferences: ["cultural", "coffee", "heritage"],
      },
    };

    const { finalSynthesis } = await executeGoal(goal);

    expect(finalSynthesis.summary).toMatch(/Chennai/i);
    expect(finalSynthesis.food.some((item) => /coffee/i.test(item))).toBe(true);
    expect(finalSynthesis.specialExperiences.length).toBeGreaterThan(0);
    expect(finalSynthesis.generatedFromFallback).toBe(false);
    expect(finalSynthesis.recommendedTasks.length).toBeGreaterThan(0);
  });
});
