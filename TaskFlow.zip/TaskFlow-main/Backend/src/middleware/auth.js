import jwt from "jsonwebtoken";
import User from "../models/User.js";

const extractToken = (req) => {
  const authHeader = req.headers.authorization || "";
  if (authHeader.startsWith("Bearer ")) {
    return authHeader.substring(7).trim();
  }

  const headerToken = req.headers["x-access-token"] || req.headers["token"];
  if (headerToken) {
    return headerToken;
  }

  if (req.cookies?.token) {
    return req.cookies.token;
  }

  if (req.query?.token) {
    return req.query.token;
  }

  if (req.body?.token) {
    return req.body.token;
  }

  return null;
};

export const authMiddleware = async (req, res, next) => {
  const token = extractToken(req);

  if (!token) {
    return res.status(401).json({ message: "Authentication token missing" });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select("-password");
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({ message: "Invalid or expired token" });
  }
};

