import mongoose from "mongoose";

let connection = null;

export const connectDB = async (mongoUri) => {
  if (connection) {
    return connection;
  }

  const uri = mongoUri || process.env.MONGO_URI;
  if (!uri) {
    throw new Error("MongoDB connection string missing. Set MONGO_URI environment variable.");
  }

  mongoose.set("strictQuery", true);

  connection = mongoose
    .connect(uri, {
      autoIndex: true,
      serverSelectionTimeoutMS: 5000,
    })
    .then((conn) => {
      if (process.env.NODE_ENV !== "test") {
        console.info(`MongoDB connected: ${conn.connection.host}`);
      }
      return conn;
    })
    .catch((err) => {
      connection = null;
      console.error("MongoDB connection error", err);
      throw err;
    });

  return connection;
};

export const disconnectDB = async () => {
  if (!connection) {
    return;
  }

  await mongoose.disconnect();
  connection = null;
};
