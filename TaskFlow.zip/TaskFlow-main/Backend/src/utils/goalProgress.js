import mongoose from "mongoose";
import Goal from "../models/Goal.js";

const TaskModel = () => mongoose.model("Task");

export const calculateGoalProgress = (completedCount, totalCount) => {
  if (totalCount === 0) return 0;
  const percentage = Math.round((completedCount / totalCount) * 100);
  return Math.min(100, Math.max(0, percentage));
};

export const updateGoalProgress = async (goalId) => {
  if (!goalId) return null;

  const Task = TaskModel();
  const [completed, total] = await Promise.all([
    Task.countDocuments({ goal: goalId, status: "completed" }),
    Task.countDocuments({ goal: goalId }),
  ]);

  const goal = await Goal.findById(goalId);
  if (!goal) return null;

  goal.progress = calculateGoalProgress(completed, total);
  goal.markCompletedIfDone();
  await goal.save();
  return goal;
};

export const getGoalProgressSnapshot = async (goalId) => {
  const Task = TaskModel();
  const total = await Task.countDocuments({ goal: goalId });
  const completed = await Task.countDocuments({ goal: goalId, status: "completed" });
  return {
    total,
    completed,
    remaining: Math.max(total - completed, 0),
    progress: calculateGoalProgress(completed, total),
  };
};
