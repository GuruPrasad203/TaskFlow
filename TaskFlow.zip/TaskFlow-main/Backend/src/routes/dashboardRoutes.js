import { Router } from "express";
import { authMiddleware } from "../middleware/auth.js";
import { getDashboardStats } from "../controllers/dashboardController.js";

const router = Router();

router.use(authMiddleware);
router.get("/stats", getDashboardStats);

export default router;
