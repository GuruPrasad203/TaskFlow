import { Router } from "express";
import { authMiddleware } from "../middleware/auth.js";
import { handleChatTripPlan } from "../controllers/chatbotController.js";
import { handleChatMessage, handleTravelPlan, checkOllamaHealth } from "../controllers/chatController.js";

const router = Router();

// Existing trip planning endpoint
router.post("/trip-plan", authMiddleware, handleChatTripPlan);

// New Ollama-powered chat endpoints
router.post("/", authMiddleware, handleChatMessage);
router.post("/travel-plan", authMiddleware, handleTravelPlan);
router.get("/health", authMiddleware, checkOllamaHealth);

export default router;
