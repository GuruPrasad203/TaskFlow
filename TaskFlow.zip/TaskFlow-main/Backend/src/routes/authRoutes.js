import { Router } from "express";
import { signup, login, getProfile, sendOTP, verifyOTP, signupWithOTP } from "../controllers/authController.js";
import { authMiddleware } from "../middleware/auth.js";

const router = Router();

router.post("/signup", signup);
router.post("/login", login);
router.get("/me", authMiddleware, getProfile);

// OTP routes
router.post("/send-otp", sendOTP);
router.post("/verify-otp", verifyOTP);
router.post("/signup-with-otp", signupWithOTP);

export default router;
