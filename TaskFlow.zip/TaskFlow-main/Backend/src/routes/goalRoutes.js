import { Router } from "express";
import { authMiddleware } from "../middleware/auth.js";
import {
  createGoal,
  listGoals,
  getGoal,
  updateGoal,
  deleteGoal,
  reDecomposeGoal,
  searchGoalContext,
  goalWeather,
} from "../controllers/goalController.js";
import { createTask, listTasks, updateTask, executeTask, deleteTask } from "../controllers/taskController.js";
import { runGoalAutomation } from "../controllers/agentController.js";

const router = Router();

router.use(authMiddleware);

router.route("/").post(createGoal).get(listGoals);
router
  .route("/:goalId")
  .get(getGoal)
  .put(updateGoal)
  .patch(updateGoal)
  .delete(deleteGoal);

router.post("/:goalId/decompose", reDecomposeGoal);
router.get("/:goalId/external/search", searchGoalContext);
router.get("/:goalId/external/weather", goalWeather);
router.post("/:goalId/agent/run", runGoalAutomation);

router.route("/:goalId/tasks").post(createTask).get(listTasks);
router
  .route("/:goalId/tasks/:taskId")
  .patch(updateTask)
  .delete(deleteTask);
router.post("/:goalId/tasks/:taskId/execute", executeTask);

export default router;
