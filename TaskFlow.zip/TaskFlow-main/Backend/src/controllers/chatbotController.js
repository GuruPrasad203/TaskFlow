import Goal from "../models/Goal.js";
import Task from "../models/Task.js";
import FreeAgent from "../services/agenticAI/freeAgent.js";
import { startExecution } from "../services/agenticAI/autonomousExecutor.js";
import { updateGoalProgress, getGoalProgressSnapshot } from "../utils/goalProgress.js";

const plannerAgent = new FreeAgent(process.env.OLLAMA_MODEL || "phi3");

const normalizeTasks = (tasks = [], goalId) =>
  tasks
    .map((task) => {
      if (!task) return null;
      if (typeof task === "string") {
        return { goal: goalId, title: task, description: "" };
      }
      if (typeof task === "object") {
        const title = task.title || task.name || task.summary;
        if (!title) return null;
        return {
          goal: goalId,
          title: title.trim(),
          description: (task.description || task.details || "").trim(),
        };
      }
      return null;
    })
    .filter(Boolean);

export const handleChatTripPlan = async (req, res, next) => {
  try {
    const { message, metadata: metadataOverride, autoExecute = true } = req.body || {};
    if (!message || typeof message !== "string") {
      return res.status(400).json({ message: "message string is required" });
    }

    const structured = await plannerAgent.interpretTripRequest(message, {
      metadata: metadataOverride,
    });

    const goal = await Goal.create({
      owner: req.user._id,
      title: structured.title || "Trip Planning Goal",
      description: structured.description || message,
      metadata: { ...(structured.metadata || {}), ...(metadataOverride || {}) },
    });

    const taskPayloads = normalizeTasks(structured.tasks, goal._id);
    if (taskPayloads.length > 0) {
      const created = await Task.insertMany(taskPayloads);
      goal.tasks = created.map((task) => task._id);
      await goal.save();
    }

    await updateGoalProgress(goal._id);

    let executionResult = null;
    if (autoExecute) {
      executionResult = await startExecution(goal._id, req.user._id);
    } else {
      const freshGoal = await Goal.findById(goal._id).populate("tasks");
      executionResult = {
        goal: freshGoal,
        progressSnapshot: await getGoalProgressSnapshot(goal._id),
      };
    }

    res.status(201).json({
      message: "Trip plan generated",
      structuredRequest: structured,
      goal: executionResult.goal,
      progressSnapshot: executionResult.progressSnapshot,
    });
  } catch (error) {
    next(error);
  }
};

export default {
  handleChatTripPlan,
};
