import Goal from "../models/Goal.js";
import Task from "../models/Task.js";
import { emitGoalUpdate } from "../services/socketService.js";
import { getGoalProgressSnapshot } from "../utils/goalProgress.js";

const ensureTaskOwnership = async (goalId, taskId, userId) => {
  const goal = await Goal.findOne({ _id: goalId, owner: userId });
  if (!goal) {
    const err = new Error("Goal not found");
    err.status = 404;
    throw err;
  }

  const task = await Task.findOne({ _id: taskId, goal: goal._id });
  if (!task) {
    const err = new Error("Task not found");
    err.status = 404;
    throw err;
  }

  return { goal, task };
};

const broadcast = async (goalId) => {
  try {
    const snapshot = await getGoalProgressSnapshot(goalId);
    emitGoalUpdate(goalId.toString(), snapshot);
  } catch (err) {
    if (process.env.NODE_ENV !== "test") {
      console.warn("Socket emit failed", err.message);
    }
  }
};

export const createTask = async (req, res, next) => {
  try {
    const { goalId } = req.params;
    const { title, description, dueDate } = req.body;
    if (!title) {
      return res.status(400).json({ message: "Title is required" });
    }

    const goal = await Goal.findOne({ _id: goalId, owner: req.user._id });
    if (!goal) {
      return res.status(404).json({ message: "Goal not found" });
    }

    const task = await Task.create({ goal: goal._id, title, description, dueDate });
    goal.tasks.push(task._id);
    await goal.save();

    await broadcast(goal._id);

    res.status(201).json({ task, progressSnapshot: await getGoalProgressSnapshot(goal._id) });
  } catch (error) {
    next(error);
  }
};

export const listTasks = async (req, res, next) => {
  try {
    const { goalId } = req.params;
    const goal = await Goal.findOne({ _id: goalId, owner: req.user._id });
    if (!goal) {
      return res.status(404).json({ message: "Goal not found" });
    }

    const tasks = await Task.find({ goal: goal._id }).sort({ createdAt: 1 });
    res.json({ tasks });
  } catch (error) {
    next(error);
  }
};

export const updateTask = async (req, res, next) => {
  try {
    const { goalId, taskId } = req.params;
    const { status, title, description, dueDate, metadata, executionLogEntry } = req.body;

    const { goal, task } = await ensureTaskOwnership(goalId, taskId, req.user._id);

    if (status !== undefined) task.status = status;
    if (title !== undefined) task.title = title;
    if (description !== undefined) task.description = description;
    if (dueDate !== undefined) task.dueDate = dueDate;
    if (metadata !== undefined) task.metadata = metadata;

    if (executionLogEntry) {
      task.executionLog.push({ ...executionLogEntry, ranAt: executionLogEntry.ranAt || new Date() });
    }

    await task.save();
    await broadcast(goal._id);

    res.json({ task, progressSnapshot: await getGoalProgressSnapshot(goal._id) });
  } catch (error) {
    next(error);
  }
};

export const executeTask = async (req, res, next) => {
  try {
    const { goalId, taskId } = req.params;
    const { notes, output } = req.body;

    const { goal, task } = await ensureTaskOwnership(goalId, taskId, req.user._id);

    task.executionLog.push({ notes, output, ranAt: new Date() });
    task.status = "in-progress";
    await task.save();

    await broadcast(goal._id);

    res.json({ task, progressSnapshot: await getGoalProgressSnapshot(goal._id) });
  } catch (error) {
    next(error);
  }
};

export const deleteTask = async (req, res, next) => {
  try {
    const { goalId, taskId } = req.params;
    const { goal, task } = await ensureTaskOwnership(goalId, taskId, req.user._id);

    await task.deleteOne();
    goal.tasks = goal.tasks.filter((id) => id.toString() !== task._id.toString());
    await goal.save();

    await broadcast(goal._id);

    res.status(204).send();
  } catch (error) {
    next(error);
  }
};
