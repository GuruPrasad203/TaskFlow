import Goal from "../models/Goal.js";
import Task from "../models/Task.js";
import { decomposeGoal } from "../services/openaiService.js";
import { emitGoalUpdate } from "../services/socketService.js";
import { getGoalProgressSnapshot, updateGoalProgress } from "../utils/goalProgress.js";
import { googleSearch, getWeather } from "../services/externalApiService.js";

const populateGoal = () => ({
  path: "tasks",
  options: { sort: { createdAt: 1 } },
});

const ensureOwnership = async (goalId, userId) => {
  const goal = await Goal.findOne({ _id: goalId, owner: userId }).populate(populateGoal());
  if (!goal) {
    const err = new Error("Goal not found");
    err.status = 404;
    throw err;
  }
  return goal;
};

const broadcast = async (goal) => {
  try {
    emitGoalUpdate(goal._id.toString(), {
      goalId: goal._id,
      progress: goal.progress,
      status: goal.status,
    });
  } catch (err) {
    if (process.env.NODE_ENV !== "test") {
      console.warn("Socket emit failed", err.message);
    }
  }
};

export const createGoal = async (req, res, next) => {
  try {
    const { title, description, dueDate, useAI, tasks = [], metadata } = req.body;
    if (!title) {
      return res.status(400).json({ message: "Title is required" });
    }

    const goal = await Goal.create({
      owner: req.user._id,
      title,
      description,
      dueDate,
      ...(metadata !== undefined ? { metadata } : {}),
    });

    let taskPayloads = tasks;
    if (useAI) {
      try {
        const aiTasks = await decomposeGoal({ goalTitle: title, goalDescription: description });
        taskPayloads = aiTasks;
      } catch (err) {
        if (process.env.NODE_ENV !== "test") {
          console.warn("OpenAI decomposition failed", err.message);
        }
      }
    }

    if (Array.isArray(taskPayloads) && taskPayloads.length > 0) {
      const createdTasks = await Task.insertMany(
        taskPayloads.map(({ title: taskTitle, description: taskDescription }) => ({
          goal: goal._id,
          title: taskTitle,
          description: taskDescription,
        }))
      );
      goal.tasks = createdTasks.map((task) => task._id);
      await goal.save();
      await updateGoalProgress(goal._id);
    }

    await updateGoalProgress(goal._id);
    const freshGoal = await Goal.findById(goal._id).populate(populateGoal());
    await broadcast(freshGoal);

    res.status(201).json({
      goal: freshGoal,
      progressSnapshot: await getGoalProgressSnapshot(goal._id),
    });
  } catch (error) {
    next(error);
  }
};

export const listGoals = async (req, res, next) => {
  try {
    const { status } = req.query;
    const query = { owner: req.user._id };
    if (status) {
      query.status = status;
    }
    const goals = await Goal.find(query).populate(populateGoal()).sort({ updatedAt: -1 });
    res.json({ goals });
  } catch (error) {
    next(error);
  }
};

export const getGoal = async (req, res, next) => {
  try {
    const goal = await ensureOwnership(req.params.goalId, req.user._id);
  const freshGoal = await Goal.findById(goal._id).populate(populateGoal());
  res.json({ goal: freshGoal, progressSnapshot: await getGoalProgressSnapshot(goal._id) });
  } catch (error) {
    next(error);
  }
};

export const updateGoal = async (req, res, next) => {
  try {
    const { title, description, status, dueDate, metadata } = req.body;
    const goal = await ensureOwnership(req.params.goalId, req.user._id);

    if (title !== undefined) goal.title = title;
    if (description !== undefined) goal.description = description;
    if (status !== undefined) goal.status = status;
    if (dueDate !== undefined) goal.dueDate = dueDate;
    if (metadata !== undefined) goal.metadata = metadata;

  await goal.save();
  await updateGoalProgress(goal._id);
  const freshGoal = await Goal.findById(goal._id).populate(populateGoal());
  await broadcast(freshGoal);

  res.json({ goal: freshGoal, progressSnapshot: await getGoalProgressSnapshot(goal._id) });
  } catch (error) {
    next(error);
  }
};

export const deleteGoal = async (req, res, next) => {
  try {
    const goal = await ensureOwnership(req.params.goalId, req.user._id);
    await Task.deleteMany({ goal: goal._id });
    await goal.deleteOne();
    await broadcast(goal);
    res.status(204).send();
  } catch (error) {
    next(error);
  }
};

export const reDecomposeGoal = async (req, res, next) => {
  try {
    const goal = await ensureOwnership(req.params.goalId, req.user._id);

    const aiTasks = await decomposeGoal({ goalTitle: goal.title, goalDescription: goal.description });
    const createdTasks = await Task.insertMany(
      aiTasks.map(({ title, description }) => ({ goal: goal._id, title, description }))
    );

    goal.tasks.push(...createdTasks.map((task) => task._id));
    await goal.save();
    await updateGoalProgress(goal._id);
    const freshGoal = await Goal.findById(goal._id).populate(populateGoal());
    await broadcast(freshGoal);

    res.json({ goal: freshGoal, progressSnapshot: await getGoalProgressSnapshot(goal._id) });
  } catch (error) {
    next(error);
  }
};

export const searchGoalContext = async (req, res, next) => {
  try {
    const goal = await ensureOwnership(req.params.goalId, req.user._id);
    const { query } = req.query;
    if (!query) {
      return res.status(400).json({ message: "Query parameter is required" });
    }
    const results = await googleSearch(`${goal.title} ${query}`);
    res.json({ results });
  } catch (error) {
    next(error);
  }
};

export const goalWeather = async (req, res, next) => {
  try {
    await ensureOwnership(req.params.goalId, req.user._id);
    const { city, lat, lon } = req.query;
    if (!city && !(lat && lon)) {
      return res.status(400).json({ message: "Provide city or lat/lon" });
    }
    const weather = await getWeather({ city, lat, lon });
    res.json({ weather });
  } catch (error) {
    next(error);
  }
};
