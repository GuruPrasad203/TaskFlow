import OllamaService from "../services/ollamaService.js";

const ollamaService = new OllamaService("phi3");

/**
 * Handle general chat messages
 */
export const handleChatMessage = async (req, res, next) => {
  try {
    const { message } = req.body || {};
    
    if (!message || typeof message !== "string") {
      return res.status(400).json({ 
        message: "Message string is required" 
      });
    }

    // Check if Ollama is available
    const healthCheck = await ollamaService.checkHealth();
    
    if (!healthCheck.isRunning) {
      return res.status(503).json({
        success: false,
        error: "Ollama service is not running. Please ensure Ollama is installed and running.",
        fallback: "🌍 Welcome to Smart Trip Planner!\n\nI'll help you plan the perfect trip with:\n✅ Budget-friendly hotels near attractions\n✅ Must-try local food recommendations\n✅ Weather information\n✅ Essential items to pack\n✅ Complete itinerary\n\nTell me: Where do you want to go and what's your budget?\nExample: \"Plan a 2-day Chennai trip with ₹15,000\""
      });
    }

    if (!healthCheck.hasModel) {
      // Try to pull the model
      const pullResult = await ollamaService.pullModel();
      if (!pullResult.success) {
        return res.status(503).json({
          success: false,
          error: `Phi3 model is not available. Please run: ollama pull phi3`,
          fallback: "🌍 Welcome to Smart Trip Planner!\n\nI'll help you plan the perfect trip with:\n✅ Budget-friendly hotels near attractions\n✅ Must-try local food recommendations\n✅ Weather information\n✅ Essential items to pack\n✅ Complete itinerary\n\nTell me: Where do you want to go and what's your budget?\nExample: \"Plan a 2-day Chennai trip with ₹15,000\""
        });
      }
    }

    // Generate response using Ollama
    const result = await ollamaService.generateChatResponse(message, {
      userId: req.user?._id,
      timestamp: new Date().toISOString()
    });

    if (result.success) {
      res.status(200).json({
        success: true,
        response: result.response,
        model: result.model,
        timestamp: result.timestamp
      });
    } else {
      res.status(200).json({
        success: true,
        response: result.fallback,
        model: "fallback",
        timestamp: new Date().toISOString(),
        note: "Using fallback response due to model error"
      });
    }

  } catch (error) {
    console.error("Chat message error:", error);
    next(error);
  }
};

/**
 * Handle travel planning requests
 */
export const handleTravelPlan = async (req, res, next) => {
  try {
    console.log('[ChatController] handleTravelPlan called');
    const { message } = req.body || {};
    console.log('[ChatController] Message:', message);
    
    if (!message || typeof message !== "string") {
      return res.status(400).json({ 
        message: "Message string is required" 
      });
    }

    // Check if Ollama is available
    console.log('[ChatController] Checking Ollama health...');
    const healthCheck = await ollamaService.checkHealth();
    console.log('[ChatController] Health check result:', healthCheck);
    
    if (!healthCheck.isRunning || !healthCheck.hasModel) {
      console.log('[ChatController] ⚠️ Ollama not available, returning 503');
      return res.status(503).json({
        success: false,
        error: "Ollama service is not available. Please ensure Ollama is installed and the Phi3 model is pulled.",
        fallback: {
          acknowledgment: "I'd love to help you plan this trip!",
          destination: "Your chosen destination",
          duration: 3,
          highlights: ["Local attractions", "Cultural experiences", "Scenic spots"],
          recommendations: {
            accommodation: "Comfortable hotel or guesthouse",
            transportation: "Local transport options",
            activities: ["Sightseeing", "Local cuisine", "Cultural experiences"]
          },
          nextSteps: ["Research accommodation", "Plan itinerary", "Book transportation"]
        }
      });
    }

    // Generate structured travel plan
    console.log('[ChatController] Calling ollamaService.generateTravelPlan...');
    const result = await ollamaService.generateTravelPlan(message);

    console.log('[ChatController] generateTravelPlan returned. Success:', result.success);
    
    if (result.success) {
      console.log('[ChatController] ✅ Returning successful structured response');
      res.status(200).json({
        success: true,
        structuredResponse: result.structuredResponse,
        model: result.model,
        timestamp: new Date().toISOString()
      });
    } else {
      console.log('[ChatController] ⚠️ Returning fallback response. Error:', result.error);
      res.status(200).json({
        success: true,
        structuredResponse: result.fallback,
        model: "fallback",
        timestamp: new Date().toISOString(),
        note: "Using fallback response due to model error"
      });
    }

  } catch (error) {
    console.error("[ChatController] ❌ Travel plan error:", error);
    next(error);
  }
};

/**
 * Check Ollama service health
 */
export const checkOllamaHealth = async (req, res, next) => {
  try {
    const healthCheck = await ollamaService.checkHealth();
    
    res.status(200).json({
      success: true,
      health: healthCheck,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error("Health check error:", error);
    next(error);
  }
};

export default {
  handleChatMessage,
  handleTravelPlan,
  checkOllamaHealth
};
