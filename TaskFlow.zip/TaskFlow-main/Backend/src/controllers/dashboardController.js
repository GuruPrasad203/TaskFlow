import Goal from "../models/Goal.js";
import Task from "../models/Task.js";

export const getDashboardStats = async (req, res, next) => {
  try {
    const owner = req.user._id;

    const goals = await Goal.find({ owner }).select("_id status updatedAt");
    const goalIds = goals.map((goal) => goal._id);

    const [goalCounts, taskCounts] = await Promise.all([
      Goal.aggregate([
        { $match: { owner } },
        { $group: { _id: "$status", count: { $sum: 1 } } },
      ]),
      goalIds.length
        ? Task.aggregate([
            { $match: { goal: { $in: goalIds } } },
            { $group: { _id: "$status", count: { $sum: 1 } } },
          ])
        : [],
    ]);

    const goalsByStatus = goalCounts.reduce((acc, item) => ({ ...acc, [item._id]: item.count }), {});
    const tasksByStatus = taskCounts.reduce((acc, item) => ({ ...acc, [item._id]: item.count }), {});

    const activeGoals = goals
      .filter((goal) => goal.status === "active")
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .slice(0, 5);

    res.json({ goalsByStatus, tasksByStatus, activeGoals });
  } catch (error) {
    next(error);
  }
};
