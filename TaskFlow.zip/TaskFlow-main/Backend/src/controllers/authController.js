import User from "../models/User.js";
import { generateToken } from "../utils/token.js";
import crypto from "crypto";
import emailService from "../services/emailService.js";

const sanitizeUser = (user) => ({
  id: user._id,
  name: user.name,
  email: user.email,
  createdAt: user.createdAt,
  updatedAt: user.updatedAt,
});

export const signup = async (req, res, next) => {
  try {
    const { name, email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" });
    }

    const existing = await User.findOne({ email });
    if (existing) {
      return res.status(409).json({ message: "Email already registered" });
    }

    const user = await User.create({ name, email, password });
    const token = generateToken(user._id);
    res.status(201).json({ user: sanitizeUser(user), token });
  } catch (error) {
    next(error);
  }
};

export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const matches = await user.comparePassword(password);
    if (!matches) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const token = generateToken(user._id);
    res.json({ user: sanitizeUser(user), token });
  } catch (error) {
    next(error);
  }
};

export const getProfile = async (req, res) => {
  res.json({ user: sanitizeUser(req.user) });
};

// OTP functionality
const generateOTP = () => {
  return crypto.randomInt(100000, 999999).toString();
};

const otpStore = new Map(); // In production, use Redis or database

export const sendOTP = async (req, res, next) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ message: "Email is required" });
    }

    const otp = generateOTP();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Store OTP temporarily
    otpStore.set(email, {
      otp,
      expiresAt,
      attempts: 0
    });

    // Send OTP via email
    const emailResult = await emailService.sendOTP(email, otp);
    
    if (emailResult.success) {
      console.log(`OTP sent to ${email}: ${otp}`);
      res.json({ 
        message: "OTP sent successfully to your email",
        // In development, also return OTP for testing
        ...((process.env.NODE_ENV === 'development' || emailResult.emailSent === false) && { otp }),
        emailSent: emailResult.emailSent !== false,
        warning: emailResult.warning
      });
    } else {
      console.error(`Failed to send OTP email to ${email}:`, emailResult.error);

      if (process.env.NODE_ENV !== 'production') {
        console.warn('[AuthController] Returning OTP despite email failure (development mode).');
        res.json({
          message: 'OTP generated (email delivery failed in development).',
          otp,
          emailSent: false,
          error: emailResult.error,
        });
      } else {
        res.status(500).json({ 
          message: "Failed to send OTP email. Please try again.",
          error: emailResult.error
        });
      }
    }
  } catch (error) {
    next(error);
  }
};

export const verifyOTP = async (req, res, next) => {
  try {
    const { email, otp } = req.body;
    if (!email || !otp) {
      return res.status(400).json({ message: "Email and OTP are required" });
    }

    const storedData = otpStore.get(email);
    if (!storedData) {
      return res.status(400).json({ message: "OTP not found or expired" });
    }

    if (new Date() > storedData.expiresAt) {
      otpStore.delete(email);
      return res.status(400).json({ message: "OTP expired" });
    }

    if (storedData.attempts >= 3) {
      otpStore.delete(email);
      return res.status(400).json({ message: "Too many attempts. Please request a new OTP." });
    }

    if (storedData.otp !== otp) {
      storedData.attempts++;
      return res.status(400).json({ message: "Invalid OTP" });
    }

    // OTP verified successfully
    otpStore.delete(email);
    res.json({ message: "OTP verified successfully" });
  } catch (error) {
    next(error);
  }
};

export const signupWithOTP = async (req, res, next) => {
  try {
    const { name, email, password, otp } = req.body;
    if (!name || !email || !password || !otp) {
      return res.status(400).json({ message: "Name, email, password, and OTP are required" });
    }

    // Verify OTP first
    const storedData = otpStore.get(email);
    if (!storedData || storedData.otp !== otp || new Date() > storedData.expiresAt) {
      return res.status(400).json({ message: "Invalid or expired OTP" });
    }

    const existing = await User.findOne({ email });
    if (existing) {
      return res.status(409).json({ message: "Email already registered" });
    }

    const user = await User.create({ name, email, password });
    const token = generateToken(user._id);
    
    // Clear OTP after successful signup
    otpStore.delete(email);
    
    // Send welcome email (don't wait for it to complete)
    emailService.sendWelcomeEmail(email, name).catch(error => {
      console.error('Failed to send welcome email:', error);
    });
    
    res.status(201).json({ user: sanitizeUser(user), token });
  } catch (error) {
    next(error);
  }
};
