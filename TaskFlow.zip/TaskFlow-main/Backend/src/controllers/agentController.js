import { startExecution } from "../services/agenticAI/autonomousExecutor.js";

export const runGoalAutomation = async (req, res, next) => {
  try {
    const { goalId } = req.params;
    const { agentModel, maxIterations } = req.body || {};

    const options = {};
    if (agentModel) {
      const { default: FreeAgent } = await import("../services/agenticAI/freeAgent.js");
      options.agentInstance = new FreeAgent(agentModel);
    }
    if (maxIterations) {
      options.maxIterations = Number(maxIterations);
    }

    const result = await startExecution(goalId, req.user._id, options);

    res.json({
      message: "Autonomous execution completed",
      goal: result.goal,
      progressSnapshot: result.progressSnapshot,
    });
  } catch (error) {
    next(error);
  }
};
