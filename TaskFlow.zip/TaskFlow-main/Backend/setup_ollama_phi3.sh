#!/bin/bash

# Setup script for Ollama with Phi3 model
# This script helps set up Ollama and the Phi3 model for the chatbot

echo "🚀 Setting up Ollama with Phi3 model for the chatbot..."

# Check if Ollama is installed
if ! command -v ollama &> /dev/null; then
    echo "❌ Ollama is not installed. Installing Ollama..."
    
    # Install Ollama
    curl -fsSL https://ollama.com/install.sh | sh
    
    if [ $? -eq 0 ]; then
        echo "✅ Ollama installed successfully!"
    else
        echo "❌ Failed to install Ollama. Please install manually from https://ollama.com"
        exit 1
    fi
else
    echo "✅ Ollama is already installed"
fi

# Start Ollama service
echo "🔄 Starting Ollama service..."
ollama serve &
OLLAMA_PID=$!

# Wait for Ollama to start
echo "⏳ Waiting for Ollama to start..."
sleep 5

# Check if Ollama is running
if curl -s http://localhost:11434/api/tags > /dev/null; then
    echo "✅ Ollama service is running"
else
    echo "❌ Ollama service failed to start. Please check the installation."
    exit 1
fi

# Pull Phi3 model
echo "📥 Pulling Phi3 model (this may take a few minutes)..."
ollama pull phi3

if [ $? -eq 0 ]; then
    echo "✅ Phi3 model pulled successfully!"
else
    echo "❌ Failed to pull Phi3 model. Please check your internet connection and try again."
    exit 1
fi

# Test the model
echo "🧪 Testing Phi3 model..."
TEST_RESPONSE=$(echo "Hello, are you working?" | ollama run phi3 | head -1)

if [ ! -z "$TEST_RESPONSE" ]; then
    echo "✅ Phi3 model is working correctly!"
    echo "📝 Test response: $TEST_RESPONSE"
else
    echo "❌ Phi3 model test failed"
    exit 1
fi

# Set environment variable
echo "🔧 Setting up environment..."
export OLLAMA_MODEL=phi3

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "📝 Creating .env file..."
    cat > .env << EOF
# Database
MONGO_URI=mongodb://localhost:27017/goal-orchestrator

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
JWT_EXPIRES_IN=7d

# OpenAI Configuration (optional)
OPENAI_API_KEY=your-openai-api-key

# Ollama Configuration
OLLAMA_MODEL=phi3
OLLAMA_HOST=http://localhost:11434

# Server Configuration
PORT=4000
NODE_ENV=development

# Socket.io
SOCKET_IO_ENABLED=true
EOF
    echo "✅ .env file created with Ollama configuration"
else
    echo "📝 Adding Ollama configuration to existing .env file..."
    if ! grep -q "OLLAMA_MODEL" .env; then
        echo "" >> .env
        echo "# Ollama Configuration" >> .env
        echo "OLLAMA_MODEL=phi3" >> .env
        echo "OLLAMA_HOST=http://localhost:11434" >> .env
        echo "✅ Ollama configuration added to .env file"
    else
        echo "✅ Ollama configuration already exists in .env file"
    fi
fi

echo ""
echo "🎉 Setup complete! Ollama with Phi3 is ready to use."
echo ""
echo "📋 Next steps:"
echo "1. Make sure your backend server is running: npm start"
echo "2. The chatbot will now use Ollama Phi3 for responses"
echo "3. You can test the chatbot in the Flutter app"
echo ""
echo "🔧 Useful commands:"
echo "- Check Ollama status: ollama list"
echo "- Test Phi3: echo 'Hello' | ollama run phi3"
echo "- Stop Ollama: pkill ollama"
echo "- Start Ollama: ollama serve"
echo ""
echo "📚 For more information, visit: https://ollama.com"
