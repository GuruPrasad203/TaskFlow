# Goal Orchestrator Backend

An Express + MongoDB backend that lets users define goals, automatically decomposes them into tasks with OpenAI, and tracks execution progress. Includes authentication, optional real-time updates, and integrations for external data enrichment.

## Features

- User signup/login with hashed passwords and JWT auth
- Goal CRUD with auto-progress updates based on task completion
- Task management with execution logic and dynamic status
- OpenAI goal decomposition into actionable tasks
- Optional Socket.io server push for live updates
- Optional Google Search and Weather API enrichment for tasks
- Dashboard stats for quick overview
- Autonomous agent endpoint to orchestrate goal execution via registered tools

## Project Structure

```
src/
  app.js                # Express app configuration
  server.js             # Entry point + Socket.io bootstrap
  config/db.js          # MongoDB connection helper
  controllers/          # Route handlers
  middleware/           # Auth + error handling
  models/               # Mongoose models
  routes/               # Express routers
  services/             # OpenAI + external APIs + socket helpers
  utils/                # Shared utilities (progress calc, error helpers)
tests/
  *.test.js             # Jest + Supertest integration tests
```

## Quick Start

1. Install dependencies

```powershell
npm install
```

2. Copy `.env.example` to `.env` and fill in values (MongoDB, OpenAI, APIs).

3. Run the development server

```powershell
npm run dev
```

The API defaults to `http://localhost:4000`.

## Postman Collection

- Import `docs/Goal Orchestrator.postman_collection.json` and `docs/Goal Orchestrator.postman_environment.json` into Postman.
- Select the **Goal Orchestrator Local** environment and set the `authToken`, `goalId`, and `taskId` variables after running the auth and goal requests.
- The collection covers signup/login, goal CRUD, task management, dashboard stats, and the autonomous agent run endpoint.

## Testing

```powershell
npm test
```

Tests use an in-memory MongoDB instance and exercise the main authentication and goal flows.

## Key Environment Variables

- `MONGO_URI` – connection string for MongoDB
- `JWT_SECRET`, `JWT_EXPIRES_IN` – JWT configuration
- `OPENAI_API_KEY` – for goal decomposition
- `SOCKET_IO_ENABLED` – set to `false` to disable Socket.io entirely
- `GOOGLE_SEARCH_*`, `WEATHER_API_*` – populate to enable optional enrichment routes

## Autonomous Agent

Trigger the built-in agent to analyze and execute a goal:

```powershell
curl -X POST \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
        "agentModel": "phi3",
        "maxIterations": 5
      }' \
  http://localhost:4000/api/goals/<GOAL_ID>/agent/run
```

`agentModel` is optional (defaults to the model configured for Ollama/OpenAI). The response contains the refreshed goal document, execution logs, and an updated progress snapshot.

### Example: Plan a New Delhi trip with a ₹20,000 budget

1. Create a goal (either via Postman or curl) with metadata that captures the budget and travel dates:

   ```json
   {
     "title": "Plan New Delhi getaway",
     "description": "Use agentic AI to plan a 3-day New Delhi trip within ₹20,000",
     "metadata": {
       "destination": "New Delhi",
       "origin": "Chennai",
       "budgetINR": 20000,
       "days": 3,
       "travelDates": "2025-11-12 to 2025-11-15",
       "travelers": 2
     }
   }
   ```

2. Run the agent endpoint as shown above. The linked tools (trip planner, distance calculator, weather, budget calculator) will combine to produce:
   - Current weather for the travel window (requires `WEATHER_API_ENDPOINT` and `WEATHER_API_KEY`).
   - A 3-day itinerary with highlighted attractions, hotel options, and food picks.
   - Budget assessment compared to the provided ₹20,000.
   - Cultural tips and “must try” experiences around New Delhi.

> **Tip:** Configure `GOOGLE_SEARCH_*` values if you want the agent to augment plans with live web search results. Leave them empty to skip that tool.

## License

MIT
