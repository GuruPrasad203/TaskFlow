import request from "supertest";
import { testApp } from "./setup.js";

describe("Authentication", () => {
  it("registers a new user and returns a token", async () => {
    const res = await request(testApp).post("/api/auth/signup").send({
      name: "Test User",
      email: "test@example.com",
      password: "password123",
    });

    expect(res.status).toBe(201);
    expect(res.body.token).toBeDefined();
    expect(res.body.user.email).toBe("test@example.com");
  });

  it("logs in an existing user", async () => {
    await request(testApp).post("/api/auth/signup").send({
      name: "Test User",
      email: "login@example.com",
      password: "password123",
    });

    const res = await request(testApp).post("/api/auth/login").send({
      email: "login@example.com",
      password: "password123",
    });

    expect(res.status).toBe(200);
    expect(res.body.token).toBeDefined();
  });
});
