import { jest } from "@jest/globals";
import request from "supertest";
import { testApp } from "./setup.js";
import Goal from "../src/models/Goal.js";
import FreeAgent from "../src/services/agenticAI/freeAgent.js";

describe("Chatbot trip planning flow", () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  it("converts a natural language request into a goal, tasks, and final plan", async () => {
    const signup = await request(testApp).post("/api/auth/signup").send({
      name: "Planner Bot",
      email: "planner@example.com",
      password: "password123",
    });

    const token = signup.body.token;
    expect(token).toBeDefined();

    jest.spyOn(FreeAgent.prototype, "interpretTripRequest").mockResolvedValue({
      title: "Plan a weekend trip to Masinagudi",
      description: "Adventure trip with safari and campfire.",
      metadata: {
        origin: "Coimbatore",
        destination: "Masinagudi",
        durationDays: 2,
        travelers: 2,
        budgetINR: 15000,
        preferences: ["wildlife", "adventure"],
      },
      tasks: [
        { title: "Book jungle stay", description: "Find eco-resorts near Masinagudi forests." },
        { title: "Reserve safari slots", description: "Confirm Mudumalai jeep safari timings." },
      ],
      originalMessage: "Plan a weekend wildlife trip to Masinagudi from Coimbatore for two people, budget ₹15,000.",
      raw: "{}",
    });

    const res = await request(testApp)
      .post("/api/chatbot/trip-plan")
      .set("Authorization", `Bearer ${token}`)
      .send({
        message: "Plan a weekend wildlife trip to Masinagudi from Coimbatore for two people, budget ₹15,000.",
        autoExecute: false,
      });

    expect(res.status).toBe(201);
    expect(res.body.structuredRequest.metadata.destination).toBe("Masinagudi");
    expect(res.body.goal.tasks).toHaveLength(2);
    expect(res.body.progressSnapshot.total).toBe(2);

    const storedGoal = await Goal.findById(res.body.goal._id).populate("tasks");
    expect(storedGoal.tasks).toHaveLength(2);
    expect(storedGoal.status).toBe("active");
  });
});
