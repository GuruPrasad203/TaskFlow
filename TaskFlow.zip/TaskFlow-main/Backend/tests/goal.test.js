import request from "supertest";
import { testApp } from "./setup.js";

const registerAndLogin = async () => {
  const email = `user${Date.now()}@example.com`;
  const password = "password123";

  await request(testApp).post("/api/auth/signup").send({
    name: "Goal User",
    email,
    password,
  });

  const loginRes = await request(testApp).post("/api/auth/login").send({ email, password });
  return loginRes.body.token;
};

describe("Goals and Tasks", () => {
  it("creates a goal and tasks, updates progress when task completes", async () => {
    const token = await registerAndLogin();

    const goalRes = await request(testApp)
      .post("/api/goals")
      .set("Authorization", `Bearer ${token}`)
      .send({
        title: "Launch feature",
        description: "Prepare and launch",
        tasks: [
          { title: "Draft spec" },
          { title: "Implement feature" },
        ],
      });

    expect(goalRes.status).toBe(201);
    expect(goalRes.body.goal.title).toBe("Launch feature");
    expect(goalRes.body.goal.tasks).toHaveLength(2);
  const goalId = goalRes.body.goal._id;
  const taskId = goalRes.body.goal.tasks[0]._id;

    const taskUpdate = await request(testApp)
      .patch(`/api/goals/${goalId}/tasks/${taskId}`)
      .set("Authorization", `Bearer ${token}`)
      .send({ status: "completed" });

    expect(taskUpdate.status).toBe(200);
    expect(taskUpdate.body.task.status).toBe("completed");
    expect(taskUpdate.body.progressSnapshot.progress).toBe(50);
  });
});
