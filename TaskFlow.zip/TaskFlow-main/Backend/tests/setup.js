import { jest } from "@jest/globals";
import { MongoMemoryServer } from "mongodb-memory-server";
import mongoose from "mongoose";
import dotenv from "dotenv";
import { connectDB, disconnectDB } from "../src/config/db.js";

jest.setTimeout(30000);

dotenv.config({ path: ".env.test" });
process.env.JWT_SECRET = process.env.JWT_SECRET || "testsecret";
process.env.JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "1d";

const { default: app } = await import("../src/app.js");

let mongoServer;

beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  const uri = mongoServer.getUri();
  process.env.MONGO_URI = uri;
  await connectDB(uri);
});

afterAll(async () => {
  await disconnectDB();
  if (mongoServer) {
    await mongoServer.stop();
  }
});

afterEach(async () => {
  const collections = mongoose.connection.collections;
  await Promise.all(
    Object.values(collections).map((collection) => collection.deleteMany({}))
  );
});

export const testApp = app;
