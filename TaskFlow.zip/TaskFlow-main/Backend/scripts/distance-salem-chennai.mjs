import DistanceCalculatorTool from "../src/services/tools/implementations/distanceCalculatorTool.js";

const run = async () => {
  try {
    const result = await DistanceCalculatorTool.execute({
      origin: "Salem, Tamil Nadu, India",
      destination: "Chennai, Tamil Nadu, India",
    });

    console.log(JSON.stringify(result, null, 2));
  } catch (err) {
    console.error(err);
    process.exitCode = 1;
  }
};

run();
