import 'dart:async';

import 'package:todooo/services/gemini_service.dart';

Future<void> main(List<String> args) async {
  final prompt = args.isNotEmpty
      ? args.join(' ')
      : 'Plan a focused two-hour study routine for math revision.';

  try {
    final routine = await GeminiService.generateRoutine(prompt);
    print('Selected prompt: $prompt');
    print('--- Routine preview ---');
    print(routine.length > 400 ? '${routine.substring(0, 400)}...' : routine);
  } catch (e) {
    print('Gemini call failed: $e');
  }
}
