# AI Agent Todo System

An intelligent Flutter application that transforms high-level goals into self-driving project plans using an autonomous AI agent system.

## 🚀 Features

### Core AI Agent Capabilities
- **Goal Decomposition**: Automatically breaks down complex goals into manageable tasks
- **Autonomous Execution**: Executes tasks using simulated external tools (web search, APIs)
- **Dynamic State Updates**: Continuously updates task lists with results and discoveries
- **Real-time Progress Tracking**: Live visualization of agent actions and project progress

### Example Scenarios

#### 1. Travel Planning
**Input**: "Plan a weekend trip to a beach near Chennai for two people"

**AI Agent Process**:
1. **Goal Analysis**: Identifies this as a travel planning task
2. **Task Decomposition**: Creates tasks for:
   - Research destination options (Marina Beach, Covelong Beach, Mahabalipuram)
   - Find accommodation options (Taj Coromandel, ITC Grand Chola, Radisson Blu)
   - Estimate budget requirements
   - Create detailed itinerary
3. **Autonomous Execution**: 
   - Simulates web search for beaches near Chennai
   - Searches for hotels and resorts
   - Analyzes pricing and availability
   - Generates budget estimates
4. **Dynamic Updates**: Continuously updates the project with findings and next steps

#### 2. Business Proposal
**Input**: "Research and create a business proposal for a new mobile app"

**AI Agent Process**:
1. **Goal Analysis**: Identifies this as a business development task
2. **Task Decomposition**: Creates tasks for:
   - Research market and competitors
   - Analyze requirements and constraints
   - Create project timeline
   - Prepare presentation materials
3. **Autonomous Execution**:
   - Simulates market research
   - Analyzes competitive landscape
   - Generates timeline and milestones
   - Creates presentation framework
4. **Dynamic Updates**: Updates with market insights and recommendations

#### 3. Event Planning
**Input**: "Organize a team building event for 20 people"

**AI Agent Process**:
1. **Goal Analysis**: Identifies this as an event planning task
2. **Task Decomposition**: Creates tasks for:
   - Research venue options
   - Plan activities and schedule
   - Estimate costs and budget
   - Coordinate logistics
3. **Autonomous Execution**:
   - Searches for suitable venues
   - Researches team building activities
   - Calculates costs and logistics
   - Creates detailed event plan
4. **Dynamic Updates**: Updates with venue options, activity suggestions, and logistics

## 🏗️ Architecture

### Core Components

#### 1. AI Agent (`lib/services/ai_agent.dart`)
- Main orchestrator for goal execution
- Handles goal decomposition and task planning
- Manages autonomous task execution
- Provides real-time progress updates

#### 2. Tool Executor (`lib/services/tool_executor.dart`)
- Simulates external API calls and web searches
- Provides realistic data for different scenarios
- Handles various tool types (search, booking, analysis)

#### 3. State Management (`lib/providers/agent_provider.dart`)
- Manages project and task state
- Tracks agent actions and progress
- Provides reactive UI updates

#### 4. Data Models
- **Project**: Represents a complete project with tasks and metadata
- **Task**: Individual actionable items with status and dependencies
- **AgentAction**: Records of agent activities and tool executions

### UI Components

#### 1. Agent Screen (`lib/screens/agent_screen.dart`)
- Main interface for interacting with the AI agent
- Tabbed interface with Execute, Tasks, and Timeline views
- Goal input dialog with example suggestions

#### 2. Execution View (`lib/widgets/agent_execution_view.dart`)
- Real-time visualization of agent execution
- Progress indicators and status updates
- Action timeline and results display

#### 3. Task List View (`lib/widgets/task_list_view.dart`)
- Detailed view of all project tasks
- Task status, dependencies, and results
- Expandable cards with action history

#### 4. Action Timeline (`lib/widgets/action_timeline.dart`)
- Chronological view of all agent actions
- Detailed action parameters and results
- Execution statistics and performance metrics

## 🎯 Key Features Demonstrated

### 1. Goal Decomposition and Planning
The AI agent automatically analyzes high-level goals and breaks them down into specific, actionable tasks with proper dependencies and priorities.

### 2. Autonomous Tool Execution
The system simulates real-world tool usage including:
- Web search for information gathering
- API calls for data retrieval
- Analysis and decision-making processes
- Booking and reservation systems

### 3. Dynamic State Update
The agent continuously updates the project state with:
- New information discovered during execution
- Task completion status and results
- Next logical steps and recommendations
- Error handling and recovery

### 4. Real-time Visualization
The UI provides live updates showing:
- Current execution phase and progress
- Individual task status and results
- Agent actions and tool usage
- Performance statistics and metrics

## 🚀 Getting Started

### Prerequisites
- Flutter SDK (3.8.1 or higher)
- Dart SDK
- Android Studio / VS Code with Flutter extensions

### Installation
1. Clone the repository
2. Navigate to the project directory
3. Install dependencies:
   ```bash
   flutter pub get
   ```
4. Generate JSON serialization files:
   ```bash
   flutter packages pub run build_runner build
   ```
5. Run the application:
   ```bash
   flutter run
   ```

### Usage
1. **Start a New Project**: Tap the "AI Agent" tab or the psychology icon
2. **Enter Your Goal**: Use the goal input dialog to describe your high-level objective
3. **Watch the Magic**: The AI agent will automatically:
   - Analyze your goal
   - Create a detailed task plan
   - Execute tasks autonomously
   - Update progress in real-time
4. **Monitor Progress**: Use the different tabs to view:
   - **Execute**: Real-time execution status
   - **Tasks**: Detailed task breakdown and results
   - **Timeline**: Complete action history

## 🔧 Technical Implementation

### State Management
- Uses Provider pattern for reactive state management
- Stream-based updates for real-time UI synchronization
- Immutable data models with copyWith methods

### Tool Simulation
- Realistic API response simulation with proper delays
- Context-aware data generation based on query types
- Error handling and retry mechanisms

### UI/UX Design
- Material Design 3 with custom theming
- Responsive layout with proper spacing and typography
- Intuitive navigation with clear visual hierarchy
- Real-time progress indicators and status updates

## 🎨 Design Philosophy

The system demonstrates how AI agents can transform traditional productivity tools by:
- **Reducing Cognitive Load**: Users only need to provide high-level goals
- **Automating Execution**: The agent handles the complex task of breaking down and executing plans
- **Providing Transparency**: All actions and decisions are visible and traceable
- **Enabling Adaptation**: The system can dynamically adjust plans based on new information

## 🔮 Future Enhancements

- Integration with real APIs (Google Search, Booking.com, etc.)
- Machine learning for improved goal understanding
- Multi-language support
- Team collaboration features
- Advanced analytics and insights
- Voice input and output
- Integration with calendar and email systems

## 📱 Screenshots

The app features a clean, modern interface with:
- Dashboard with AI Agent promotion
- Goal input dialog with examples
- Real-time execution visualization
- Detailed task management
- Action timeline with full transparency

## 🤝 Contributing

This is a hackathon project demonstrating AI agent capabilities. Feel free to:
- Report issues and bugs
- Suggest new features
- Contribute improvements
- Share your own AI agent implementations

## 📄 License

This project is created for educational and demonstration purposes as part of a hackathon challenge.

---

**Built with ❤️ using Flutter and AI Agent principles**