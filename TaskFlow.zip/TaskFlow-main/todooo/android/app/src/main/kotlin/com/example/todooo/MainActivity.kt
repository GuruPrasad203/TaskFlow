package com.example.todooo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
