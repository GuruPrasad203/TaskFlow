import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class User {
  final String id;
  final String name;
  final String email;
  final String? token;

  User({
    required this.id,
    required this.name,
    required this.email,
    this.token,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['_id'] ?? json['id'] ?? '',
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      token: json['token'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'token': token,
    };
  }

  User copyWith({
    String? id,
    String? name,
    String? email,
    String? token,
  }) {
    return User(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      token: token ?? this.token,
    );
  }
}

class UserProvider extends ChangeNotifier {
  User? _currentUser;
  bool _isLoading = false;
  String? _error;

  User? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isLoggedIn => _currentUser != null;

  // Get user's first name for display
  String get displayName {
    if (_currentUser == null) return 'User';
    final nameParts = _currentUser!.name.split(' ');
    return nameParts.isNotEmpty ? nameParts.first : _currentUser!.name;
  }

  // Get user's initials for avatar
  String get initials {
    if (_currentUser == null) return 'U';
    final nameParts = _currentUser!.name.split(' ');
    if (nameParts.length >= 2) {
      return '${nameParts[0][0]}${nameParts[1][0]}'.toUpperCase();
    } else if (nameParts.isNotEmpty) {
      return nameParts[0][0].toUpperCase();
    }
    return 'U';
  }

  /// Initialize user from stored data
  Future<void> initializeUser() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      final userJson = prefs.getString('user_data');
      final token = prefs.getString('auth_token');

      if (userJson != null && token != null) {
        final userData = jsonDecode(userJson);
        _currentUser = User.fromJson(userData).copyWith(token: token);
        _error = null;
      }
    } catch (e) {
      _error = 'Failed to load user data: $e';
      await clearUser();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Set user after successful login/signup
  Future<void> setUser(User user) async {
    _currentUser = user;
    _error = null;
    notifyListeners();

    // Store user data locally
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_data', jsonEncode(user.toJson()));
      if (user.token != null) {
        await prefs.setString('auth_token', user.token!);
      }
    } catch (e) {
      _error = 'Failed to save user data: $e';
      notifyListeners();
    }
  }

  /// Update user data
  Future<void> updateUser(User updatedUser) async {
    _currentUser = updatedUser;
    notifyListeners();

    // Update stored data
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_data', jsonEncode(updatedUser.toJson()));
    } catch (e) {
      _error = 'Failed to update user data: $e';
      notifyListeners();
    }
  }

  /// Clear user data (logout)
  Future<void> clearUser() async {
    _currentUser = null;
    _error = null;
    notifyListeners();

    // Clear stored data
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('user_data');
      await prefs.remove('auth_token');
    } catch (e) {
      _error = 'Failed to clear user data: $e';
      notifyListeners();
    }
  }

  /// Get stored auth token
  Future<String?> getAuthToken() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString('auth_token');
    } catch (e) {
      return null;
    }
  }

  /// Set error message
  void setError(String error) {
    _error = error;
    notifyListeners();
  }

  /// Clear error message
  void clearError() {
    _error = null;
    notifyListeners();
  }
}
