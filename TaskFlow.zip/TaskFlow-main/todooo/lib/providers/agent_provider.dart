import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/project.dart';
import '../models/agent_action.dart';
import '../services/ai_agent.dart';

class AgentProvider extends ChangeNotifier {
  final AIAgent _aiAgent;
  StreamSubscription<Project>? _projectSubscription;
  StreamSubscription<AgentAction>? _actionSubscription;

  Project? _currentProject;
  final List<AgentAction> _actions = [];
  bool _isExecuting = false;
  String? _error;

  Project? get currentProject => _currentProject;
  List<AgentAction> get actions => List.unmodifiable(_actions);
  bool get isExecuting => _isExecuting;
  String? get error => _error;
  
  // Computed properties
  List<AgentAction> get recentActions => _actions.take(10).toList();
  List<AgentAction> get completedActions => _actions.where((a) => a.isCompleted).toList();
  List<AgentAction> get failedActions => _actions.where((a) => a.isFailed).toList();
  
  double get overallProgress {
    if (_currentProject == null) return 0.0;
    return _currentProject!.progress;
  }

  AgentProvider({AIAgent? aiAgent}) : _aiAgent = aiAgent ?? AIAgent() {
    _setupSubscriptions();
  }

  void _setupSubscriptions() {
    _projectSubscription = _aiAgent.projectStream.listen(
      (project) {
        _currentProject = project;
        notifyListeners();
      },
      onError: (error) {
        _error = error.toString();
        _isExecuting = false;
        notifyListeners();
      },
    );

    _actionSubscription = _aiAgent.actionStream.listen(
      (action) {
        _actions.insert(0, action); // Add to beginning for chronological order
        notifyListeners();
      },
      onError: (error) {
        _error = error.toString();
        notifyListeners();
      },
    );
  }

  /// Execute a new goal
  Future<void> executeGoal(String goal) async {
    if (_isExecuting) return;

    _isExecuting = true;
    _error = null;
    _actions.clear();
    notifyListeners();

    try {
      await _aiAgent.executeGoal(goal);
    } catch (e) {
      _error = e.toString();
    } finally {
      _isExecuting = false;
      notifyListeners();
    }
  }

  /// Get actions for a specific task
  List<AgentAction> getActionsForTask(String taskId) {
    return _actions.where((action) => action.taskId == taskId).toList();
  }

  /// Get actions for a specific project
  List<AgentAction> getActionsForProject(String projectId) {
    return _actions.where((action) => action.projectId == projectId).toList();
  }

  /// Get actions by type
  List<AgentAction> getActionsByType(ActionType type) {
    return _actions.where((action) => action.type == type).toList();
  }

  /// Get current phase description
  String getCurrentPhaseDescription() {
    if (_currentProject == null) return 'No active project';
    
    if (_currentProject!.isPlanning) {
      return 'Planning and decomposing goal into tasks...';
    } else if (_currentProject!.isActive) {
      final pendingTasks = _currentProject!.pendingTasks.length;
      final inProgressTasks = _currentProject!.inProgressTasks.length;
      final completedTasks = _currentProject!.completedTasks.length;
      
      if (inProgressTasks > 0) {
        return 'Executing tasks... ($completedTasks completed, $inProgressTasks in progress, $pendingTasks pending)';
      } else if (pendingTasks > 0) {
        return 'Ready to execute $pendingTasks pending tasks';
      } else {
        return 'All tasks completed!';
      }
    } else if (_currentProject!.isCompleted) {
      return 'Project completed successfully!';
    } else {
      return 'Project status: ${_currentProject!.status.name}';
    }
  }

  /// Get execution statistics
  Map<String, dynamic> getExecutionStats() {
    final totalActions = _actions.length;
    final completedActions = _actions.where((a) => a.isCompleted).length;
    final failedActions = _actions.where((a) => a.isFailed).length;
    final executingActions = _actions.where((a) => a.isExecuting).length;
    
    final totalExecutionTime = _actions
        .where((a) => a.executionTime != null)
        .fold<Duration>(Duration.zero, (sum, a) => sum + a.executionTime!);

    return {
      'total_actions': totalActions,
      'completed_actions': completedActions,
      'failed_actions': failedActions,
      'executing_actions': executingActions,
      'success_rate': totalActions > 0 ? completedActions / totalActions : 0.0,
      'total_execution_time': totalExecutionTime,
      'average_execution_time': totalActions > 0 
          ? Duration(milliseconds: totalExecutionTime.inMilliseconds ~/ totalActions)
          : Duration.zero,
    };
  }

  /// Clear current project and reset state
  void clearProject() {
    _currentProject = null;
    _actions.clear();
    _error = null;
    _isExecuting = false;
    notifyListeners();
  }

  /// Get project summary
  Map<String, dynamic> getProjectSummary() {
    if (_currentProject == null) {
      return {
        'has_project': false,
        'message': 'No active project',
      };
    }

    final project = _currentProject!;
    final stats = getExecutionStats();

    return {
      'has_project': true,
      'project_id': project.id,
      'title': project.title,
      'original_goal': project.originalGoal,
      'status': project.status.name,
      'progress': project.progress,
      'total_tasks': project.tasks.length,
      'completed_tasks': project.completedTasks.length,
      'pending_tasks': project.pendingTasks.length,
      'in_progress_tasks': project.inProgressTasks.length,
      'failed_tasks': project.failedTasks.length,
      'current_phase': project.currentPhase,
      'created_at': project.createdAt.toIso8601String(),
      'updated_at': project.updatedAt?.toIso8601String(),
      'execution_stats': stats,
    };
  }

  /// Get detailed task information
  List<Map<String, dynamic>> getTaskDetails() {
    if (_currentProject == null) return [];

    return _currentProject!.tasks.map((task) {
      final taskActions = getActionsForTask(task.id);
      
      return {
        'task': {
          'id': task.id,
          'title': task.title,
          'description': task.description,
          'status': task.status.name,
          'priority': task.priority.name,
          'created_at': task.createdAt.toIso8601String(),
          'updated_at': task.updatedAt?.toIso8601String(),
          'completed_at': task.completedAt?.toIso8601String(),
          'result': task.result,
          'error': task.error,
          'dependencies': task.dependencies,
          'metadata': task.metadata,
        },
        'actions': taskActions.map((action) => {
          'id': action.id,
          'type': action.type.name,
          'description': action.description,
          'status': action.status.name,
          'created_at': action.createdAt.toIso8601String(),
          'started_at': action.startedAt?.toIso8601String(),
          'completed_at': action.completedAt?.toIso8601String(),
          'execution_time': action.executionTime?.inMilliseconds,
          'result': action.result,
          'error': action.error,
        }).toList(),
      };
    }).toList();
  }

  @override
  void dispose() {
    _projectSubscription?.cancel();
    _actionSubscription?.cancel();
    _aiAgent.dispose();
    super.dispose();
  }
}
