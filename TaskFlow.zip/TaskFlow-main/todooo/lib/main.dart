import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:animations/animations.dart';
import 'providers/agent_provider.dart';
import 'providers/user_provider.dart';
import 'screens/agent_screen.dart';
import 'screens/auth_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/task_details_screen.dart';
import 'screens/calendar_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/chatbot_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => UserProvider()),
        ChangeNotifierProvider(create: (context) => AgentProvider()),
      ],
      child: MaterialApp(
      debugShowCheckedModeBanner: false,
        title: 'AI Agent Todo System',
      theme: ThemeData(
          scaffoldBackgroundColor: const Color(0xFFF8FAFC),
        colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF3B82F6),
            primary: const Color(0xFF3B82F6),
            secondary: const Color(0xFF10B981),
            surface: Colors.white,
        ),
        useMaterial3: true,
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.white,
            foregroundColor: Color(0xFF1F2937),
            elevation: 0,
            systemOverlayStyle: SystemUiOverlayStyle(
              statusBarColor: Colors.transparent,
              statusBarIconBrightness: Brightness.dark,
            ),
          ),
          cardTheme: CardThemeData(
            color: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            shadowColor: Colors.black.withOpacity(0.05),
          ),
          textTheme: GoogleFonts.interTextTheme().copyWith(
            titleLarge: GoogleFonts.inter(fontWeight: FontWeight.bold, color: const Color(0xFF1F2937)),
            titleMedium: GoogleFonts.inter(fontWeight: FontWeight.w600, color: const Color(0xFF1F2937)),
            bodyMedium: GoogleFonts.inter(color: const Color(0xFF6B7280)),
            bodySmall: GoogleFonts.inter(color: const Color(0xFF9CA3AF)),
          ),
        ),
        home: Consumer<UserProvider>(
          builder: (context, userProvider, child) {
            // Initialize user data on app start
            WidgetsBinding.instance.addPostFrameCallback((_) {
              userProvider.initializeUser();
            });
            
            // Show loading screen while checking authentication
            if (userProvider.isLoading) {
              return const Scaffold(
                body: Center(
                  child: CircularProgressIndicator(),
                ),
              );
            }
            
            // Navigate based on authentication status
            return userProvider.isLoggedIn 
                ? const MainNavigationScreen() 
                : const AuthScreen();
          },
        ),
      ),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const DashboardScreen(),
    const CalendarScreen(),
    const ChatbotScreen(),
    const TaskDetailsScreen(),
    const AgentScreen(),
    const ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageTransitionSwitcher(
        duration: const Duration(milliseconds: 300),
        transitionBuilder: (child, primaryAnimation, secondaryAnimation) {
          return SharedAxisTransition(
            animation: primaryAnimation,
            secondaryAnimation: secondaryAnimation,
            transitionType: SharedAxisTransitionType.horizontal,
            child: child,
          );
        },
        child: _screens[_currentIndex],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF3B82F6),
        unselectedItemColor: const Color(0xFF9CA3AF),
        backgroundColor: Colors.white,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home, color: _currentIndex == 0 ? const Color(0xFFEF4444) : const Color(0xFF9CA3AF)),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_month, color: _currentIndex == 1 ? const Color(0xFF3B82F6) : const Color(0xFF9CA3AF)),
            label: 'Calendar',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat, color: _currentIndex == 2 ? const Color(0xFF3B82F6) : const Color(0xFF9CA3AF)),
            label: 'Chatbot',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.checklist, color: _currentIndex == 3 ? const Color(0xFF3B82F6) : const Color(0xFF9CA3AF)),
            label: 'Tasks',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.smart_toy, color: _currentIndex == 4 ? const Color(0xFF3B82F6) : const Color(0xFF9CA3AF)),
            label: 'Agent',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person, color: _currentIndex == 5 ? const Color(0xFF3B82F6) : const Color(0xFF9CA3AF)),
            label: 'Profile',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() => _currentIndex = 2);
        },
        backgroundColor: const Color(0xFF3B82F6),
        shape: const CircleBorder(),
        child: const Icon(Icons.chat, color: Colors.white),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}