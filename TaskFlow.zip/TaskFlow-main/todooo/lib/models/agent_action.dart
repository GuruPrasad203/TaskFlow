import 'package:json_annotation/json_annotation.dart';
import 'package:uuid/uuid.dart';

part 'agent_action.g.dart';

enum ActionType {
  @JsonValue('web_search')
  webSearch,
  @JsonValue('data_analysis')
  dataAnalysis,
  @JsonValue('task_creation')
  taskCreation,
  @JsonValue('task_update')
  taskUpdate,
  @JsonValue('context_update')
  contextUpdate,
  @JsonValue('decision_making')
  decisionMaking,
  @JsonValue('planning')
  planning,
}

enum ActionStatus {
  @JsonValue('pending')
  pending,
  @JsonValue('executing')
  executing,
  @JsonValue('completed')
  completed,
  @JsonValue('failed')
  failed,
}

@JsonSerializable()
class AgentAction {
  final String id;
  final ActionType type;
  final String description;
  final ActionStatus status;
  final DateTime createdAt;
  final DateTime? startedAt;
  final DateTime? completedAt;
  final Map<String, dynamic> parameters;
  final Map<String, dynamic>? result;
  final String? error;
  final String? taskId;
  final String? projectId;

  const AgentAction({
    required this.id,
    required this.type,
    required this.description,
    required this.status,
    required this.createdAt,
    this.startedAt,
    this.completedAt,
    this.parameters = const {},
    this.result,
    this.error,
    this.taskId,
    this.projectId,
  });

  factory AgentAction.create({
    required ActionType type,
    required String description,
    Map<String, dynamic> parameters = const {},
    String? taskId,
    String? projectId,
  }) {
    return AgentAction(
      id: const Uuid().v4(),
      type: type,
      description: description,
      status: ActionStatus.pending,
      createdAt: DateTime.now(),
      parameters: parameters,
      taskId: taskId,
      projectId: projectId,
    );
  }

  AgentAction copyWith({
    String? id,
    ActionType? type,
    String? description,
    ActionStatus? status,
    DateTime? createdAt,
    DateTime? startedAt,
    DateTime? completedAt,
    Map<String, dynamic>? parameters,
    Map<String, dynamic>? result,
    String? error,
    String? taskId,
    String? projectId,
  }) {
    return AgentAction(
      id: id ?? this.id,
      type: type ?? this.type,
      description: description ?? this.description,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      startedAt: startedAt ?? this.startedAt,
      completedAt: completedAt ?? this.completedAt,
      parameters: parameters ?? this.parameters,
      result: result ?? this.result,
      error: error ?? this.error,
      taskId: taskId ?? this.taskId,
      projectId: projectId ?? this.projectId,
    );
  }

  AgentAction markExecuting() {
    return copyWith(
      status: ActionStatus.executing,
      startedAt: DateTime.now(),
    );
  }

  AgentAction markCompleted({Map<String, dynamic>? result}) {
    return copyWith(
      status: ActionStatus.completed,
      completedAt: DateTime.now(),
      result: result,
    );
  }

  AgentAction markFailed({String? error}) {
    return copyWith(
      status: ActionStatus.failed,
      completedAt: DateTime.now(),
      error: error,
    );
  }

  bool get isCompleted => status == ActionStatus.completed;
  bool get isExecuting => status == ActionStatus.executing;
  bool get isPending => status == ActionStatus.pending;
  bool get isFailed => status == ActionStatus.failed;

  Duration? get executionTime {
    if (startedAt == null) return null;
    final endTime = completedAt ?? DateTime.now();
    return endTime.difference(startedAt!);
  }

  factory AgentAction.fromJson(Map<String, dynamic> json) => _$AgentActionFromJson(json);
  Map<String, dynamic> toJson() => _$AgentActionToJson(this);

  @override
  String toString() {
    return 'AgentAction(id: $id, type: $type, status: $status, description: $description)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is AgentAction && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}
