// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'project.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Project _$ProjectFromJson(Map<String, dynamic> json) => Project(
  id: json['id'] as String,
  title: json['title'] as String,
  description: json['description'] as String,
  originalGoal: json['originalGoal'] as String,
  status: $enumDecode(_$ProjectStatusEnumMap, json['status']),
  createdAt: DateTime.parse(json['createdAt'] as String),
  updatedAt: json['updatedAt'] == null
      ? null
      : DateTime.parse(json['updatedAt'] as String),
  completedAt: json['completedAt'] == null
      ? null
      : DateTime.parse(json['completedAt'] as String),
  tasks:
      (json['tasks'] as List<dynamic>?)
          ?.map((e) => Task.fromJson(e as Map<String, dynamic>))
          .toList() ??
      const [],
  context: json['context'] as Map<String, dynamic>? ?? const {},
  currentPhase: json['currentPhase'] as String?,
  progress: (json['progress'] as num?)?.toDouble() ?? 0.0,
);

Map<String, dynamic> _$ProjectToJson(Project instance) => <String, dynamic>{
  'id': instance.id,
  'title': instance.title,
  'description': instance.description,
  'originalGoal': instance.originalGoal,
  'status': _$ProjectStatusEnumMap[instance.status]!,
  'createdAt': instance.createdAt.toIso8601String(),
  'updatedAt': instance.updatedAt?.toIso8601String(),
  'completedAt': instance.completedAt?.toIso8601String(),
  'tasks': instance.tasks,
  'context': instance.context,
  'currentPhase': instance.currentPhase,
  'progress': instance.progress,
};

const _$ProjectStatusEnumMap = {
  ProjectStatus.planning: 'planning',
  ProjectStatus.active: 'active',
  ProjectStatus.paused: 'paused',
  ProjectStatus.completed: 'completed',
  ProjectStatus.cancelled: 'cancelled',
};
