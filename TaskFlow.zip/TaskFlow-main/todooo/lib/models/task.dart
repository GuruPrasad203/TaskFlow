import 'package:json_annotation/json_annotation.dart';
import 'package:uuid/uuid.dart';

part 'task.g.dart';

enum TaskStatus {
  @JsonValue('pending')
  pending,
  @JsonValue('in_progress')
  inProgress,
  @JsonValue('completed')
  completed,
  @JsonValue('failed')
  failed,
  @JsonValue('cancelled')
  cancelled,
}

enum TaskPriority {
  @JsonValue('low')
  low,
  @JsonValue('medium')
  medium,
  @JsonValue('high')
  high,
  @JsonValue('critical')
  critical,
}

@JsonSerializable()
class Task {
  final String id;
  final String title;
  final String description;
  final TaskStatus status;
  final TaskPriority priority;
  final DateTime createdAt;
  final DateTime? updatedAt;
  final DateTime? completedAt;
  final List<String> dependencies;
  final Map<String, dynamic> metadata;
  final String? result;
  final String? error;

  const Task({
    required this.id,
    required this.title,
    required this.description,
    required this.status,
    required this.priority,
    required this.createdAt,
    this.updatedAt,
    this.completedAt,
    this.dependencies = const [],
    this.metadata = const {},
    this.result,
    this.error,
  });

  factory Task.create({
    required String title,
    required String description,
    TaskPriority priority = TaskPriority.medium,
    List<String> dependencies = const [],
    Map<String, dynamic> metadata = const {},
  }) {
    final now = DateTime.now();
    return Task(
      id: const Uuid().v4(),
      title: title,
      description: description,
      status: TaskStatus.pending,
      priority: priority,
      createdAt: now,
      dependencies: dependencies,
      metadata: metadata,
    );
  }

  Task copyWith({
    String? id,
    String? title,
    String? description,
    TaskStatus? status,
    TaskPriority? priority,
    DateTime? createdAt,
    DateTime? updatedAt,
    DateTime? completedAt,
    List<String>? dependencies,
    Map<String, dynamic>? metadata,
    String? result,
    String? error,
  }) {
    return Task(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      status: status ?? this.status,
      priority: priority ?? this.priority,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      completedAt: completedAt ?? this.completedAt,
      dependencies: dependencies ?? this.dependencies,
      metadata: metadata ?? this.metadata,
      result: result ?? this.result,
      error: error ?? this.error,
    );
  }

  Task markInProgress() {
    return copyWith(
      status: TaskStatus.inProgress,
      updatedAt: DateTime.now(),
    );
  }

  Task markCompleted({String? result}) {
    return copyWith(
      status: TaskStatus.completed,
      updatedAt: DateTime.now(),
      completedAt: DateTime.now(),
      result: result,
    );
  }

  Task markFailed({String? error}) {
    return copyWith(
      status: TaskStatus.failed,
      updatedAt: DateTime.now(),
      error: error,
    );
  }

  bool get isCompleted => status == TaskStatus.completed;
  bool get isInProgress => status == TaskStatus.inProgress;
  bool get isPending => status == TaskStatus.pending;
  bool get isFailed => status == TaskStatus.failed;

  factory Task.fromJson(Map<String, dynamic> json) => _$TaskFromJson(json);
  Map<String, dynamic> toJson() => _$TaskToJson(this);

  @override
  String toString() {
    return 'Task(id: $id, title: $title, status: $status, priority: $priority)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Task && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}
