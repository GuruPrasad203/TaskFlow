import 'package:json_annotation/json_annotation.dart';
import 'package:uuid/uuid.dart';
import 'task.dart';

part 'project.g.dart';

enum ProjectStatus {
  @JsonValue('planning')
  planning,
  @JsonValue('active')
  active,
  @JsonValue('paused')
  paused,
  @JsonValue('completed')
  completed,
  @JsonValue('cancelled')
  cancelled,
}

@JsonSerializable()
class Project {
  final String id;
  final String title;
  final String description;
  final String originalGoal;
  final ProjectStatus status;
  final DateTime createdAt;
  final DateTime? updatedAt;
  final DateTime? completedAt;
  final List<Task> tasks;
  final Map<String, dynamic> context;
  final String? currentPhase;
  final double progress;

  const Project({
    required this.id,
    required this.title,
    required this.description,
    required this.originalGoal,
    required this.status,
    required this.createdAt,
    this.updatedAt,
    this.completedAt,
    this.tasks = const [],
    this.context = const {},
    this.currentPhase,
    this.progress = 0.0,
  });

  factory Project.create({
    required String originalGoal,
    String? title,
    String? description,
  }) {
    final now = DateTime.now();
    return Project(
      id: const Uuid().v4(),
      title: title ?? _generateTitle(originalGoal),
      description: description ?? 'AI-generated project plan for: $originalGoal',
      originalGoal: originalGoal,
      status: ProjectStatus.planning,
      createdAt: now,
    );
  }

  static String _generateTitle(String goal) {
    if (goal.length > 50) {
      return '${goal.substring(0, 47)}...';
    }
    return goal;
  }

  Project copyWith({
    String? id,
    String? title,
    String? description,
    String? originalGoal,
    ProjectStatus? status,
    DateTime? createdAt,
    DateTime? updatedAt,
    DateTime? completedAt,
    List<Task>? tasks,
    Map<String, dynamic>? context,
    String? currentPhase,
    double? progress,
  }) {
    return Project(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      originalGoal: originalGoal ?? this.originalGoal,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      completedAt: completedAt ?? this.completedAt,
      tasks: tasks ?? this.tasks,
      context: context ?? this.context,
      currentPhase: currentPhase ?? this.currentPhase,
      progress: progress ?? this.progress,
    );
  }

  Project addTask(Task task) {
    final updatedTasks = List<Task>.from(tasks)..add(task);
    return copyWith(
      tasks: updatedTasks,
      updatedAt: DateTime.now(),
    );
  }

  Project updateTask(Task updatedTask) {
    final updatedTasks = tasks.map((task) {
      return task.id == updatedTask.id ? updatedTask : task;
    }).toList();
    
    final newProgress = _calculateProgress(updatedTasks);
    
    return copyWith(
      tasks: updatedTasks,
      progress: newProgress,
      updatedAt: DateTime.now(),
    );
  }

  Project removeTask(String taskId) {
    final updatedTasks = tasks.where((task) => task.id != taskId).toList();
    final newProgress = _calculateProgress(updatedTasks);
    
    return copyWith(
      tasks: updatedTasks,
      progress: newProgress,
      updatedAt: DateTime.now(),
    );
  }

  double _calculateProgress(List<Task> taskList) {
    if (taskList.isEmpty) return 0.0;
    
    final completedTasks = taskList.where((task) => task.isCompleted).length;
    return completedTasks / taskList.length;
  }

  Project markActive() {
    return copyWith(
      status: ProjectStatus.active,
      updatedAt: DateTime.now(),
    );
  }

  Project markCompleted() {
    return copyWith(
      status: ProjectStatus.completed,
      updatedAt: DateTime.now(),
      completedAt: DateTime.now(),
    );
  }

  Project updateContext(Map<String, dynamic> newContext) {
    final mergedContext = Map<String, dynamic>.from(context)..addAll(newContext);
    return copyWith(
      context: mergedContext,
      updatedAt: DateTime.now(),
    );
  }

  List<Task> get pendingTasks => tasks.where((task) => task.isPending).toList();
  List<Task> get inProgressTasks => tasks.where((task) => task.isInProgress).toList();
  List<Task> get completedTasks => tasks.where((task) => task.isCompleted).toList();
  List<Task> get failedTasks => tasks.where((task) => task.isFailed).toList();

  bool get isCompleted => status == ProjectStatus.completed;
  bool get isActive => status == ProjectStatus.active;
  bool get isPlanning => status == ProjectStatus.planning;

  factory Project.fromJson(Map<String, dynamic> json) => _$ProjectFromJson(json);
  Map<String, dynamic> toJson() => _$ProjectToJson(this);

  @override
  String toString() {
    return 'Project(id: $id, title: $title, status: $status, progress: ${(progress * 100).toStringAsFixed(1)}%)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Project && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}
