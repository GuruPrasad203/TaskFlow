// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'agent_action.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AgentAction _$AgentActionFromJson(Map<String, dynamic> json) => AgentAction(
  id: json['id'] as String,
  type: $enumDecode(_$ActionTypeEnumMap, json['type']),
  description: json['description'] as String,
  status: $enumDecode(_$ActionStatusEnumMap, json['status']),
  createdAt: DateTime.parse(json['createdAt'] as String),
  startedAt: json['startedAt'] == null
      ? null
      : DateTime.parse(json['startedAt'] as String),
  completedAt: json['completedAt'] == null
      ? null
      : DateTime.parse(json['completedAt'] as String),
  parameters: json['parameters'] as Map<String, dynamic>? ?? const {},
  result: json['result'] as Map<String, dynamic>?,
  error: json['error'] as String?,
  taskId: json['taskId'] as String?,
  projectId: json['projectId'] as String?,
);

Map<String, dynamic> _$AgentActionToJson(AgentAction instance) =>
    <String, dynamic>{
      'id': instance.id,
      'type': _$ActionTypeEnumMap[instance.type]!,
      'description': instance.description,
      'status': _$ActionStatusEnumMap[instance.status]!,
      'createdAt': instance.createdAt.toIso8601String(),
      'startedAt': instance.startedAt?.toIso8601String(),
      'completedAt': instance.completedAt?.toIso8601String(),
      'parameters': instance.parameters,
      'result': instance.result,
      'error': instance.error,
      'taskId': instance.taskId,
      'projectId': instance.projectId,
    };

const _$ActionTypeEnumMap = {
  ActionType.webSearch: 'web_search',
  ActionType.dataAnalysis: 'data_analysis',
  ActionType.taskCreation: 'task_creation',
  ActionType.taskUpdate: 'task_update',
  ActionType.contextUpdate: 'context_update',
  ActionType.decisionMaking: 'decision_making',
  ActionType.planning: 'planning',
};

const _$ActionStatusEnumMap = {
  ActionStatus.pending: 'pending',
  ActionStatus.executing: 'executing',
  ActionStatus.completed: 'completed',
  ActionStatus.failed: 'failed',
};
