String computeBackendBaseUrl() => 'http://localhost:4000/api';
