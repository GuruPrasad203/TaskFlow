import 'dart:io';

String computeBackendBaseUrl() {
  if (Platform.isAndroid) {
    // Android emulator uses 10.0.2.2 to access host machine's localhost
    return 'http://10.0.2.2:4000/api';
  }

  // For iOS simulator, desktop, etc., localhost points to host machine
  return 'http://localhost:4000/api';
}
