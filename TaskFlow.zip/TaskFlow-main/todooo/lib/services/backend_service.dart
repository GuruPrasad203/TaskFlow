import 'dart:convert';
import 'dart:developer' as developer;
import 'package:http/http.dart' as http;

import 'backend_service_platform_stub.dart'
    if (dart.library.io) 'backend_service_platform_io.dart';

class BackendService {
  static String get _baseUrl {
    const override = String.fromEnvironment('BACKEND_API_URL');
    final base = override.isNotEmpty ? override : computeBackendBaseUrl();
    return _normalizeBaseUrl(base);
  }

  static String _normalizeBaseUrl(String value) {
    var normalized = value.trim();

    if (normalized.isEmpty) {
      normalized = computeBackendBaseUrl();
    }

    // Remove trailing slash
    if (normalized.endsWith('/')) {
      normalized = normalized.substring(0, normalized.length - 1);
    }

    if (!normalized.endsWith('/api')) {
      normalized = '$normalized/api';
    }

    return normalized;
  }

  static String get _healthUrl {
    final base = _baseUrl;
    if (base.endsWith('/api')) {
      return '${base.substring(0, base.length - 4)}/health';
    }
    return '$base/health';
  }
  
  // Auth endpoints
  static String get _authUrl => '$_baseUrl/auth';
  static String get _goalsUrl => '$_baseUrl/goals';
  static String get _dashboardUrl => '$_baseUrl/dashboard';
  static String get _chatbotUrl => '$_baseUrl/chatbot';

  // Helper method to make authenticated requests
  static Future<Map<String, String>> _getHeaders({String? token}) async {
    final headers = {
      'Content-Type': 'application/json',
    };
    
    if (token != null) {
      headers['Authorization'] = 'Bearer $token';
    }
    
    return headers;
  }

  // Auth methods
  static Future<Map<String, dynamic>> sendOTP(String email) async {
    try {
      developer.log('Sending OTP to: $email', name: 'BackendService');
      
      final response = await http.post(
        Uri.parse('$_authUrl/send-otp'),
        headers: await _getHeaders(),
        body: jsonEncode({
          'email': email,
        }),
      );

      developer.log('Send OTP response: ${response.statusCode}', name: 'BackendService');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return {
          'success': true,
          'message': data['message'],
          'otp': data['otp'], // Only available in development
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to send OTP',
        };
      }
    } catch (e) {
      developer.log('Send OTP error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  static Future<Map<String, dynamic>> verifyOTP(String email, String otp) async {
    try {
      developer.log('Verifying OTP for: $email', name: 'BackendService');
      
      final response = await http.post(
        Uri.parse('$_authUrl/verify-otp'),
        headers: await _getHeaders(),
        body: jsonEncode({
          'email': email,
          'otp': otp,
        }),
      );

      developer.log('Verify OTP response: ${response.statusCode}', name: 'BackendService');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return {
          'success': true,
          'message': data['message'],
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to verify OTP',
        };
      }
    } catch (e) {
      developer.log('Verify OTP error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  static Future<Map<String, dynamic>> signupWithOTP(String name, String email, String password, String otp) async {
    try {
      developer.log('Signing up with OTP for: $email', name: 'BackendService');
      
      final response = await http.post(
        Uri.parse('$_authUrl/signup-with-otp'),
        headers: await _getHeaders(),
        body: jsonEncode({
          'name': name,
          'email': email,
          'password': password,
          'otp': otp,
        }),
      );

      developer.log('Signup with OTP response: ${response.statusCode}', name: 'BackendService');

      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        return {
          'success': true,
          'token': data['token'],
          'user': data['user'],
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to signup',
        };
      }
    } catch (e) {
      developer.log('Signup with OTP error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  static Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      developer.log('Backend login attempt for: $email', name: 'BackendService');
      
      final response = await http.post(
        Uri.parse('$_authUrl/login'),
        headers: await _getHeaders(),
        body: jsonEncode({
          'email': email,
          'password': password,
        }),
      );

      developer.log('Login response: ${response.statusCode}', name: 'BackendService');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return {
          'success': true,
          'token': data['token'],
          'user': data['user'],
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Login failed',
        };
      }
    } catch (e) {
      developer.log('Login error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  static Future<Map<String, dynamic>> register(String name, String email, String password) async {
    try {
      developer.log('Backend register attempt for: $email', name: 'BackendService');
      
      final response = await http.post(
        Uri.parse('$_authUrl/register'),
        headers: await _getHeaders(),
        body: jsonEncode({
          'name': name,
          'email': email,
          'password': password,
        }),
      );

      developer.log('Register response: ${response.statusCode}', name: 'BackendService');

      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        return {
          'success': true,
          'token': data['token'],
          'user': data['user'],
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Registration failed',
        };
      }
    } catch (e) {
      developer.log('Register error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  // Goal methods
  static Future<Map<String, dynamic>> createGoal(String token, Map<String, dynamic> goalData) async {
    try {
      developer.log('Creating goal: ${goalData['title']}', name: 'BackendService');
      
      final response = await http.post(
        Uri.parse(_goalsUrl),
        headers: await _getHeaders(token: token),
        body: jsonEncode(goalData),
      );

      if (response.statusCode == 201) {
        return {
          'success': true,
          'goal': jsonDecode(response.body),
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to create goal',
        };
      }
    } catch (e) {
      developer.log('Create goal error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  static Future<Map<String, dynamic>> getGoals(String token) async {
    try {
      developer.log('Fetching goals', name: 'BackendService');
      
      final response = await http.get(
        Uri.parse(_goalsUrl),
        headers: await _getHeaders(token: token),
      );

      if (response.statusCode == 200) {
        return {
          'success': true,
          'goals': jsonDecode(response.body),
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to fetch goals',
        };
      }
    } catch (e) {
      developer.log('Get goals error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  static Future<Map<String, dynamic>> getGoal(String token, String goalId) async {
    try {
      developer.log('Fetching goal: $goalId', name: 'BackendService');
      
      final response = await http.get(
        Uri.parse('$_goalsUrl/$goalId'),
        headers: await _getHeaders(token: token),
      );

      if (response.statusCode == 200) {
        return {
          'success': true,
          'goal': jsonDecode(response.body),
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to fetch goal',
        };
      }
    } catch (e) {
      developer.log('Get goal error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  // Task methods
  static Future<Map<String, dynamic>> createTask(String token, String goalId, Map<String, dynamic> taskData) async {
    try {
      developer.log('Creating task for goal: $goalId', name: 'BackendService');
      
      final response = await http.post(
        Uri.parse('$_goalsUrl/$goalId/tasks'),
        headers: await _getHeaders(token: token),
        body: jsonEncode(taskData),
      );

      if (response.statusCode == 201) {
        return {
          'success': true,
          'task': jsonDecode(response.body),
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to create task',
        };
      }
    } catch (e) {
      developer.log('Create task error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  static Future<Map<String, dynamic>> getTasks(String token, String goalId) async {
    try {
      developer.log('Fetching tasks for goal: $goalId', name: 'BackendService');
      
      final response = await http.get(
        Uri.parse('$_goalsUrl/$goalId/tasks'),
        headers: await _getHeaders(token: token),
      );

      if (response.statusCode == 200) {
        return {
          'success': true,
          'tasks': jsonDecode(response.body),
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to fetch tasks',
        };
      }
    } catch (e) {
      developer.log('Get tasks error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  // Dashboard methods
  static Future<Map<String, dynamic>> getDashboard(String token) async {
    try {
      developer.log('Fetching dashboard data', name: 'BackendService');
      
      final response = await http.get(
        Uri.parse(_dashboardUrl),
        headers: await _getHeaders(token: token),
      );

      if (response.statusCode == 200) {
        return {
          'success': true,
          'data': jsonDecode(response.body),
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to fetch dashboard data',
        };
      }
    } catch (e) {
      developer.log('Get dashboard error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  // Chatbot methods
  static Future<Map<String, dynamic>> sendChatMessage(String token, String message) async {
    try {
      developer.log('Sending chat message', name: 'BackendService');
      
      final response = await http.post(
        Uri.parse(_chatbotUrl),
        headers: await _getHeaders(token: token),
        body: jsonEncode({
          'message': message,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return {
          'success': true,
          'response': data['response'],
          'model': data['model'],
          'timestamp': data['timestamp'],
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to send message',
        };
      }
    } catch (e) {
      developer.log('Send chat message error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  static Future<Map<String, dynamic>> sendTravelPlanMessage(String token, String message) async {
    try {
      developer.log('Sending travel plan message', name: 'BackendService');
      
      final response = await http.post(
        Uri.parse('$_chatbotUrl/travel-plan'),
        headers: await _getHeaders(token: token),
        body: jsonEncode({
          'message': message,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return {
          'success': true,
          'structuredResponse': data['structuredResponse'],
          'model': data['model'],
          'timestamp': data['timestamp'],
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to process travel plan',
        };
      }
    } catch (e) {
      developer.log('Send travel plan message error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  static Future<Map<String, dynamic>> sendTripPlanMessage(String token, String message, {Map<String, dynamic>? metadata, bool autoExecute = true}) async {
    try {
      developer.log('Sending trip plan message', name: 'BackendService');
      
      final response = await http.post(
        Uri.parse('$_chatbotUrl/trip-plan'),
        headers: await _getHeaders(token: token),
        body: jsonEncode({
          'message': message,
          'metadata': metadata,
          'autoExecute': autoExecute,
        }),
      );

      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        return {
          'success': true,
          'message': data['message'],
          'structuredRequest': data['structuredRequest'],
          'goal': data['goal'],
          'progressSnapshot': data['progressSnapshot'],
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to process trip plan',
        };
      }
    } catch (e) {
      developer.log('Send trip plan message error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  static Future<Map<String, dynamic>> sendMessage(String token, String message) async {
    try {
      developer.log('Sending chatbot message', name: 'BackendService');
      
      final response = await http.post(
        Uri.parse(_chatbotUrl),
        headers: await _getHeaders(token: token),
        body: jsonEncode({
          'message': message,
        }),
      );

      if (response.statusCode == 200) {
        return {
          'success': true,
          'response': jsonDecode(response.body),
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to send message',
        };
      }
    } catch (e) {
      developer.log('Send message error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  // Password reset methods
  static Future<Map<String, dynamic>> resetPassword(String email, String otp, String newPassword) async {
    try {
      developer.log('Resetting password for: $email', name: 'BackendService');
      
      final response = await http.post(
        Uri.parse('$_authUrl/reset-password'),
        headers: await _getHeaders(),
        body: jsonEncode({
          'email': email,
          'otp': otp,
          'newPassword': newPassword,
        }),
      );

      developer.log('Reset password response: ${response.statusCode}', name: 'BackendService');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return {
          'success': true,
          'message': data['message'],
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'error': error['message'] ?? 'Failed to reset password',
        };
      }
    } catch (e) {
      developer.log('Reset password error: $e', name: 'BackendService');
      return {
        'success': false,
        'error': 'Network error: $e',
      };
    }
  }

  // Health check
  static Future<bool> checkHealth() async {
    try {
      final response = await http.get(
        Uri.parse(_healthUrl),
        headers: {'Content-Type': 'application/json'},
      );
      
      return response.statusCode == 200;
    } catch (e) {
      developer.log('Health check failed: $e', name: 'BackendService');
      return false;
    }
  }
}
