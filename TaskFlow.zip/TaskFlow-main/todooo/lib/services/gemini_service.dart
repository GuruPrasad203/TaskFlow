import 'dart:convert';
import 'dart:developer' as developer;
import 'package:http/http.dart' as http;

class GeminiService {
  static const String _apiKey = String.fromEnvironment('GEMINI_API_KEY');
  static const List<String> _defaultModelOrder = [
    'gemini-2.5-pro-exp',
    'gemini-2.0-pro-exp',
    'gemini-1.5-pro-latest',
    'gemini-1.5-flash-latest',
    'gemini-pro',
  ];
  static const String _baseUrl = 'https://generativelanguage.googleapis.com';

  static List<String> _resolveCandidateModels() {
    const override = String.fromEnvironment('GEMINI_MODELS', defaultValue: '');
    if (override.trim().isEmpty) {
      return _defaultModelOrder;
    }

    final models = override
        .split(',')
        .map((m) => m.trim())
        .where((m) => m.isNotEmpty)
        .toList();

    return models.isEmpty ? _defaultModelOrder : models;
  }

  static Future<(String model, http.Response response)> _postWithFallback(
    Map<String, dynamic> body,
  ) async {
    if (_apiKey.isEmpty) {
      throw Exception(
        'Gemini API key missing. Provide it via --dart-define=GEMINI_API_KEY=<your_key> or define GEMINI_API_KEY in your launch configuration.',
      );
    }

    final models = _resolveCandidateModels();
    final List<String> errors = [];

    for (final model in models) {
      final url = Uri.parse('$_baseUrl/v1/models/$model:generateContent?key=$_apiKey');
      developer.log(
        'POST ${url.pathSegments.last} | model=$model',
        name: 'GeminiService',
        level: 800,
      );

      try {
        final response = await http.post(
          url,
          headers: {
            'Content-Type': 'application/json',
          },
          body: jsonEncode(body),
        );

        developer.log(
          'Gemini response ${response.statusCode} for model $model',
          name: 'GeminiService',
          level: 800,
        );

        if (response.statusCode == 404 || response.statusCode == 403) {
          errors.add('model $model -> ${response.statusCode}: ${response.body}');
          continue;
        }

        if (response.statusCode >= 200 && response.statusCode < 300) {
          return (model, response);
        }

        errors.add('model $model -> ${response.statusCode}: ${response.body}');
      } catch (e, stackTrace) {
        errors.add('model $model -> exception: $e');
        developer.log(
          'Gemini call failed for model $model',
          name: 'GeminiService',
          error: e,
          stackTrace: stackTrace,
          level: 1000,
        );
      }
    }

    throw Exception('All Gemini models failed. Details: ${errors.join(' | ')}');
  }

  static Future<String> generateRoutine(String prompt) async {
    try {
      developer.log(
        'Calling Gemini generateRoutine | promptLength=${prompt.length}',
        name: 'GeminiService',
        level: 800,
      );

      final body = {
          'contents': [
            {
              'parts': [
                {
                  'text': '''
You are an AI Routine Generator. Create detailed, actionable plans based on user prompts. 

For travel itineraries, include:
- Day-by-day breakdown with specific times
- Activities with duration estimates
- Local tips and recommendations
- Transportation and logistics
- Meal suggestions
- Must-see attractions

For daily routines, include:
- Time-based schedule
- Activity categories (work, personal, health, etc.)
- Duration for each activity
- Breaks and transition time
- Priority levels

Format your response as a structured plan with:
1. Title
2. Overview
3. Day-by-day or time-based breakdown
4. Key highlights
5. Tips and recommendations

User prompt: $prompt

Please create a comprehensive, actionable plan that the user can follow step by step.
'''
                }
              ]
            }
          ],
          'generationConfig': {
            'temperature': 0.7,
            'topK': 40,
            'topP': 0.95,
            'maxOutputTokens': 2048,
          }
      };

      final (model, response) = await _postWithFallback(body);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['candidates'] != null && 
            data['candidates'].isNotEmpty && 
            data['candidates'][0]['content'] != null &&
            data['candidates'][0]['content']['parts'] != null &&
            data['candidates'][0]['content']['parts'].isNotEmpty) {
          developer.log(
            'Gemini generateRoutine succeeded with model $model',
            name: 'GeminiService',
            level: 800,
          );
          return data['candidates'][0]['content']['parts'][0]['text'];
        } else {
          throw Exception('Invalid response format from Gemini API');
        }
      } else {
        throw Exception('Failed to generate routine: ${response.statusCode} - ${response.body}');
      }
    } catch (e, stackTrace) {
      developer.log(
        'Gemini generateRoutine failed',
        name: 'GeminiService',
        error: e,
        stackTrace: stackTrace,
        level: 1000,
      );
      throw Exception('Error generating routine: $e');
    }
  }

  static Future<List<Map<String, dynamic>>> extractTasksFromRoutine(String routine) async {
    try {
      developer.log(
        'Calling Gemini extractTasks | routineLength=${routine.length}',
        name: 'GeminiService',
        level: 800,
      );

      final body = {
          'contents': [
            {
              'parts': [
                {
                  'text': '''
Extract actionable tasks from this routine/plan and return them as a JSON array. Each task should have:
- title: Short, clear task name
- description: Detailed description
- estimatedDuration: Duration in minutes
- category: One of "travel", "food", "activity", "transportation", "accommodation", "shopping", "health", "work", "personal"
- priority: "high", "medium", or "low"
- day: Day number (1, 2, 3, etc.) or "daily" for recurring tasks
- time: Specific time if mentioned (e.g., "8:00 AM") or null

Return ONLY a valid JSON array, no other text.

Routine/Plan:
$routine
'''
                }
              ]
            }
          ],
          'generationConfig': {
            'temperature': 0.3,
            'topK': 20,
            'topP': 0.8,
            'maxOutputTokens': 1024,
          }
      };

      final (model, response) = await _postWithFallback(body);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['candidates'] != null && 
            data['candidates'].isNotEmpty && 
            data['candidates'][0]['content'] != null &&
            data['candidates'][0]['content']['parts'] != null &&
            data['candidates'][0]['content']['parts'].isNotEmpty) {
          developer.log(
            'Gemini extractTasks succeeded with model $model',
            name: 'GeminiService',
            level: 800,
          );
          
          final tasksText = data['candidates'][0]['content']['parts'][0]['text'];
          final tasksJson = jsonDecode(tasksText);
          
          if (tasksJson is List) {
            return List<Map<String, dynamic>>.from(tasksJson);
          } else {
            throw Exception('Invalid tasks format');
          }
        } else {
          throw Exception('Invalid response format from Gemini API');
        }
      } else {
        throw Exception('Failed to extract tasks: ${response.statusCode} - ${response.body}');
      }
    } catch (e, stackTrace) {
      developer.log(
        'Gemini extractTasks failed',
        name: 'GeminiService',
        error: e,
        stackTrace: stackTrace,
        level: 1000,
      );
      throw Exception('Error extracting tasks: $e');
    }
  }
}
