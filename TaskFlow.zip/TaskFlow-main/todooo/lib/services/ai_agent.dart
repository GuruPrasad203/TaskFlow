import 'dart:async';
import 'dart:math';
import '../models/task.dart';
import '../models/project.dart';
import '../models/agent_action.dart';
import 'tool_executor.dart';

class AIAgent {
  final ToolExecutor _toolExecutor;
  final StreamController<AgentAction> _actionStreamController;
  final StreamController<Project> _projectStreamController;
  
  Stream<AgentAction> get actionStream => _actionStreamController.stream;
  Stream<Project> get projectStream => _projectStreamController.stream;

  AIAgent({ToolExecutor? toolExecutor}) 
      : _toolExecutor = toolExecutor ?? ToolExecutor(),
        _actionStreamController = StreamController<AgentAction>.broadcast(),
        _projectStreamController = StreamController<Project>.broadcast();

  /// Main entry point: Takes a high-level goal and creates a self-driving project
  Future<Project> executeGoal(String goal) async {
    final project = Project.create(originalGoal: goal);
    _projectStreamController.add(project);

    try {
      // Phase 1: Goal Analysis and Decomposition
      final analyzedProject = await _analyzeAndDecomposeGoal(project);
      _projectStreamController.add(analyzedProject);

      // Phase 2: Autonomous Execution
      final executedProject = await _autonomousExecution(analyzedProject);
      _projectStreamController.add(executedProject);

      return executedProject;
    } catch (e) {
      final failedProject = project.copyWith(
        status: ProjectStatus.cancelled,
        updatedAt: DateTime.now(),
      );
      _projectStreamController.add(failedProject);
      rethrow;
    }
  }

  /// Phase 1: Analyze the goal and decompose it into manageable tasks
  Future<Project> _analyzeAndDecomposeGoal(Project project) async {
    final action = AgentAction.create(
      type: ActionType.planning,
      description: 'Analyzing goal and creating project plan',
      projectId: project.id,
    );
    _actionStreamController.add(action);

    final executingAction = action.markExecuting();
    _actionStreamController.add(executingAction);

    try {
      // Simulate AI analysis and planning
      await Future.delayed(const Duration(seconds: 2));

      final tasks = await _generateInitialTasks(project.originalGoal);
      var updatedProject = project.copyWith(
        status: ProjectStatus.active,
        currentPhase: 'Planning Complete',
        updatedAt: DateTime.now(),
      );

      for (final task in tasks) {
        updatedProject = updatedProject.addTask(task);
      }

      final completedAction = executingAction.markCompleted(
        result: {
          'tasks_created': tasks.length,
          'phase': 'Planning Complete',
        },
      );
      _actionStreamController.add(completedAction);

      return updatedProject;
    } catch (e) {
      final failedAction = executingAction.markFailed(error: e.toString());
      _actionStreamController.add(failedAction);
      rethrow;
    }
  }

  /// Phase 2: Autonomous execution of tasks
  Future<Project> _autonomousExecution(Project project) async {
    var currentProject = project;
    
    while (currentProject.pendingTasks.isNotEmpty || currentProject.inProgressTasks.isNotEmpty) {
      // Find next task to execute
      final nextTask = _findNextTask(currentProject);
      if (nextTask == null) break;

      // Execute the task
      currentProject = await _executeTask(currentProject, nextTask);
      
      // Small delay to simulate real execution time
      await Future.delayed(const Duration(milliseconds: 500));
    }

    // Mark project as completed if all tasks are done
    if (currentProject.completedTasks.length == currentProject.tasks.length) {
      currentProject = currentProject.markCompleted();
    }

    return currentProject;
  }

  /// Find the next task to execute based on dependencies and priority
  Task? _findNextTask(Project project) {
    // First, try to find pending tasks with no unmet dependencies
    for (final task in project.pendingTasks) {
      if (_areDependenciesMet(project, task)) {
        return task;
      }
    }
    
    // If no pending tasks are ready, return null
    return null;
  }

  /// Check if all dependencies for a task are completed
  bool _areDependenciesMet(Project project, Task task) {
    for (final depId in task.dependencies) {
      final depTask = project.tasks.firstWhere(
        (t) => t.id == depId,
        orElse: () => throw Exception('Dependency not found: $depId'),
      );
      if (!depTask.isCompleted) {
        return false;
      }
    }
    return true;
  }

  /// Execute a single task autonomously
  Future<Project> _executeTask(Project project, Task task) async {
    // Mark task as in progress
    var updatedTask = task.markInProgress();
    var updatedProject = project.updateTask(updatedTask);

    final action = AgentAction.create(
      type: ActionType.taskUpdate,
      description: 'Executing task: ${task.title}',
      taskId: task.id,
      projectId: project.id,
    );
    _actionStreamController.add(action);

    final executingAction = action.markExecuting();
    _actionStreamController.add(executingAction);

    try {
      // Execute the task based on its type/metadata
      final result = await _executeTaskLogic(updatedProject, updatedTask);
      
      // Mark task as completed
      updatedTask = updatedTask.markCompleted(result: result);
      updatedProject = updatedProject.updateTask(updatedTask);

      final completedAction = executingAction.markCompleted(
        result: {
          'task_id': task.id,
          'result': result,
          'status': 'completed',
        },
      );
      _actionStreamController.add(completedAction);

      return updatedProject;
    } catch (e) {
      // Mark task as failed
      updatedTask = updatedTask.markFailed(error: e.toString());
      updatedProject = updatedProject.updateTask(updatedTask);

      final failedAction = executingAction.markFailed(error: e.toString());
      _actionStreamController.add(failedAction);

      return updatedProject;
    }
  }

  /// Execute the actual logic for a task
  Future<String> _executeTaskLogic(Project project, Task task) async {
    // Determine task type from metadata or title
    final taskType = task.metadata['type'] as String? ?? _inferTaskType(task.title);
    
    switch (taskType) {
      case 'research':
        return await _executeResearchTask(task, project);
      case 'booking':
        return await _executeBookingTask(task, project);
      case 'analysis':
        return await _executeAnalysisTask(task, project);
      case 'planning':
        return await _executePlanningTask(task, project);
      default:
        return await _executeGenericTask(task, project);
    }
  }

  /// Infer task type from title
  String _inferTaskType(String title) {
    final lowerTitle = title.toLowerCase();
    if (lowerTitle.contains('research') || lowerTitle.contains('find') || lowerTitle.contains('search')) {
      return 'research';
    } else if (lowerTitle.contains('book') || lowerTitle.contains('reserve') || lowerTitle.contains('hotel')) {
      return 'booking';
    } else if (lowerTitle.contains('analyze') || lowerTitle.contains('compare') || lowerTitle.contains('evaluate')) {
      return 'analysis';
    } else if (lowerTitle.contains('plan') || lowerTitle.contains('schedule') || lowerTitle.contains('organize')) {
      return 'planning';
    }
    return 'generic';
  }

  /// Execute research tasks using web search simulation
  Future<String> _executeResearchTask(Task task, Project project) async {
    final searchQuery = task.metadata['search_query'] as String? ?? task.title;
    
    final action = AgentAction.create(
      type: ActionType.webSearch,
      description: 'Searching for: $searchQuery',
      parameters: {'query': searchQuery},
      taskId: task.id,
      projectId: project.id,
    );
    _actionStreamController.add(action);

    final executingAction = action.markExecuting();
    _actionStreamController.add(executingAction);

    try {
      final searchResults = await _toolExecutor.simulateWebSearch(searchQuery);
      
      final completedAction = executingAction.markCompleted(
        result: {'results': searchResults, 'query': searchQuery},
      );
      _actionStreamController.add(completedAction);

      return _formatSearchResults(searchResults);
    } catch (e) {
      final failedAction = executingAction.markFailed(error: e.toString());
      _actionStreamController.add(failedAction);
      rethrow;
    }
  }

  /// Execute booking tasks
  Future<String> _executeBookingTask(Task task, Project project) async {
    // Simulate booking process
    await Future.delayed(const Duration(seconds: 1));
    
    final bookingDetails = _generateBookingDetails(task, project);
    return 'Booking completed: $bookingDetails';
  }

  /// Execute analysis tasks
  Future<String> _executeAnalysisTask(Task task, Project project) async {
    // Simulate analysis process
    await Future.delayed(const Duration(seconds: 1));
    
    final analysis = _generateAnalysis(task, project);
    return 'Analysis completed: $analysis';
  }

  /// Execute planning tasks
  Future<String> _executePlanningTask(Task task, Project project) async {
    // Simulate planning process
    await Future.delayed(const Duration(seconds: 1));
    
    final plan = _generatePlan(task, project);
    return 'Plan created: $plan';
  }

  /// Execute generic tasks
  Future<String> _executeGenericTask(Task task, Project project) async {
    // Simulate generic task execution
    await Future.delayed(const Duration(milliseconds: 500));
    return 'Task completed successfully';
  }

  /// Generate initial tasks based on the goal
  Future<List<Task>> _generateInitialTasks(String goal) async {
    final tasks = <Task>[];
    
    // Analyze the goal to determine what type of project this is
    if (_isTravelGoal(goal)) {
      tasks.addAll(_generateTravelTasks(goal));
    } else if (_isBusinessGoal(goal)) {
      tasks.addAll(_generateBusinessTasks(goal));
    } else {
      tasks.addAll(_generateGenericTasks(goal));
    }

    return tasks;
  }

  /// Check if the goal is travel-related
  bool _isTravelGoal(String goal) {
    final travelKeywords = ['trip', 'vacation', 'travel', 'hotel', 'flight', 'beach', 'city', 'visit'];
    final lowerGoal = goal.toLowerCase();
    return travelKeywords.any((keyword) => lowerGoal.contains(keyword));
  }

  /// Check if the goal is business-related
  bool _isBusinessGoal(String goal) {
    final businessKeywords = ['business', 'proposal', 'meeting', 'client', 'project', 'presentation'];
    final lowerGoal = goal.toLowerCase();
    return businessKeywords.any((keyword) => lowerGoal.contains(keyword));
  }

  /// Generate tasks for travel goals
  List<Task> _generateTravelTasks(String goal) {
    return [
      Task.create(
        title: 'Research destination options',
        description: 'Find and research potential destinations based on the goal',
        priority: TaskPriority.high,
        metadata: {
          'type': 'research',
          'search_query': _extractDestinationQuery(goal),
        },
      ),
      Task.create(
        title: 'Find accommodation options',
        description: 'Search for hotels, resorts, or other accommodation',
        priority: TaskPriority.high,
        dependencies: [], // Will be updated after first task
        metadata: {
          'type': 'research',
          'search_query': 'accommodation ${_extractDestinationQuery(goal)}',
        },
      ),
      Task.create(
        title: 'Estimate budget requirements',
        description: 'Calculate estimated costs for the trip',
        priority: TaskPriority.medium,
        metadata: {
          'type': 'analysis',
        },
      ),
      Task.create(
        title: 'Create detailed itinerary',
        description: 'Plan daily activities and schedule',
        priority: TaskPriority.medium,
        metadata: {
          'type': 'planning',
        },
      ),
    ];
  }

  /// Generate tasks for business goals
  List<Task> _generateBusinessTasks(String goal) {
    return [
      Task.create(
        title: 'Research market and competitors',
        description: 'Gather information about the market and competitive landscape',
        priority: TaskPriority.high,
        metadata: {
          'type': 'research',
          'search_query': _extractBusinessQuery(goal),
        },
      ),
      Task.create(
        title: 'Analyze requirements and constraints',
        description: 'Identify key requirements and potential constraints',
        priority: TaskPriority.high,
        metadata: {
          'type': 'analysis',
        },
      ),
      Task.create(
        title: 'Create project timeline',
        description: 'Develop a detailed timeline for the project',
        priority: TaskPriority.medium,
        metadata: {
          'type': 'planning',
        },
      ),
      Task.create(
        title: 'Prepare presentation materials',
        description: 'Create slides, documents, and other presentation materials',
        priority: TaskPriority.medium,
        metadata: {
          'type': 'planning',
        },
      ),
    ];
  }

  /// Generate generic tasks for other goals
  List<Task> _generateGenericTasks(String goal) {
    return [
      Task.create(
        title: 'Research and gather information',
        description: 'Collect relevant information for the goal',
        priority: TaskPriority.high,
        metadata: {
          'type': 'research',
          'search_query': goal,
        },
      ),
      Task.create(
        title: 'Analyze requirements',
        description: 'Break down and analyze the requirements',
        priority: TaskPriority.high,
        metadata: {
          'type': 'analysis',
        },
      ),
      Task.create(
        title: 'Create action plan',
        description: 'Develop a detailed plan of action',
        priority: TaskPriority.medium,
        metadata: {
          'type': 'planning',
        },
      ),
    ];
  }

  /// Extract destination query from travel goal
  String _extractDestinationQuery(String goal) {
    // Simple extraction - in a real system, this would be more sophisticated
    final words = goal.toLowerCase().split(' ');
    final locationWords = <String>[];
    
    for (final word in words) {
      if (word.length > 3 && !_isCommonWord(word)) {
        locationWords.add(word);
      }
    }
    
    return locationWords.take(3).join(' ');
  }

  /// Extract business query from business goal
  String _extractBusinessQuery(String goal) {
    return goal.toLowerCase().replaceAll(RegExp(r'\b(business|proposal|meeting|client)\b'), '').trim();
  }

  /// Check if a word is a common word
  bool _isCommonWord(String word) {
    const commonWords = {
      'the', 'and', 'for', 'with', 'plan', 'weekend', 'trip', 'vacation',
      'beach', 'near', 'people', 'two', 'business', 'proposal'
    };
    return commonWords.contains(word);
  }

  /// Format search results for display
  String _formatSearchResults(List<Map<String, dynamic>> results) {
    if (results.isEmpty) {
      return 'No results found';
    }

    final formatted = results.take(3).map((result) {
      return '• ${result['title']}: ${result['description']}';
    }).join('\n');

    return 'Found ${results.length} results:\n$formatted';
  }

  /// Generate booking details
  String _generateBookingDetails(Task task, Project project) {
    final random = Random();
    final options = ['Hotel A', 'Hotel B', 'Hotel C', 'Resort X', 'Inn Y'];
    final selected = options[random.nextInt(options.length)];
    final price = 50 + random.nextInt(200);
    
    return '$selected - \$$price/night';
  }

  /// Generate analysis results
  String _generateAnalysis(Task task, Project project) {
    final random = Random();
    final insights = [
      'Cost-effective options identified',
      'Quality vs price analysis completed',
      'Risk assessment completed',
      'Timeline feasibility confirmed',
    ];
    
    return insights[random.nextInt(insights.length)];
  }

  /// Generate plan details
  String _generatePlan(Task task, Project project) {
    return 'Detailed plan with timeline and milestones created';
  }

  /// Dispose resources
  void dispose() {
    _actionStreamController.close();
    _projectStreamController.close();
  }
}
