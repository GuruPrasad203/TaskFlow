import 'dart:math';

class ToolExecutor {
  static final Random _random = Random();

  /// Simulate web search with realistic results
  Future<List<Map<String, dynamic>>> simulateWebSearch(String query) async {
    // Simulate network delay
    await Future.delayed(Duration(milliseconds: 500 + _random.nextInt(1000)));

    // Generate realistic search results based on query
    final results = <Map<String, dynamic>>[];
    
    if (_isTravelQuery(query)) {
      results.addAll(_generateTravelResults(query));
    } else if (_isBusinessQuery(query)) {
      results.addAll(_generateBusinessResults(query));
    } else {
      results.addAll(_generateGenericResults(query));
    }

    return results;
  }

  /// Check if query is travel-related
  bool _isTravelQuery(String query) {
    final travelKeywords = ['beach', 'hotel', 'trip', 'vacation', 'travel', 'chennai', 'resort'];
    final lowerQuery = query.toLowerCase();
    return travelKeywords.any((keyword) => lowerQuery.contains(keyword));
  }

  /// Check if query is business-related
  bool _isBusinessQuery(String query) {
    final businessKeywords = ['business', 'proposal', 'market', 'competitor', 'analysis'];
    final lowerQuery = query.toLowerCase();
    return businessKeywords.any((keyword) => lowerQuery.contains(keyword));
  }

  /// Generate travel-related search results
  List<Map<String, dynamic>> _generateTravelResults(String query) {
    final results = <Map<String, dynamic>>[];
    
    if (query.toLowerCase().contains('beach') && query.toLowerCase().contains('chennai')) {
      results.addAll([
        {
          'title': 'Marina Beach - Chennai',
          'description': 'The second longest urban beach in the world, perfect for weekend getaways with family and friends.',
          'url': 'https://example.com/marina-beach',
          'rating': 4.5,
          'price_range': 'Free',
        },
        {
          'title': 'Covelong Beach - Near Chennai',
          'description': 'A beautiful beach resort destination just 40km from Chennai, ideal for water sports and relaxation.',
          'url': 'https://example.com/covelong-beach',
          'rating': 4.2,
          'price_range': '₹2000-5000',
        },
        {
          'title': 'Mahabalipuram Beach - UNESCO Heritage',
          'description': 'Historic beach town with ancient temples and beautiful coastline, 60km from Chennai.',
          'url': 'https://example.com/mahabalipuram',
          'rating': 4.7,
          'price_range': '₹1500-4000',
        },
      ]);
    }
    
    if (query.toLowerCase().contains('hotel') || query.toLowerCase().contains('accommodation')) {
      results.addAll([
        {
          'title': 'Taj Coromandel Chennai',
          'description': 'Luxury 5-star hotel in the heart of Chennai with excellent amenities and service.',
          'url': 'https://example.com/taj-coromandel',
          'rating': 4.8,
          'price_range': '₹8000-15000',
        },
        {
          'title': 'ITC Grand Chola',
          'description': 'Premium business hotel with modern facilities and great location.',
          'url': 'https://example.com/itc-grand-chola',
          'rating': 4.6,
          'price_range': '₹6000-12000',
        },
        {
          'title': 'Radisson Blu Chennai',
          'description': 'Contemporary hotel with good value for money and convenient location.',
          'url': 'https://example.com/radisson-blu',
          'rating': 4.3,
          'price_range': '₹4000-8000',
        },
      ]);
    }

    return results;
  }

  /// Generate business-related search results
  List<Map<String, dynamic>> _generateBusinessResults(String query) {
    return [
      {
        'title': 'Market Analysis Report 2024',
        'description': 'Comprehensive market analysis with trends, opportunities, and competitive landscape.',
        'url': 'https://example.com/market-analysis',
        'relevance': 0.95,
      },
      {
        'title': 'Industry Best Practices Guide',
        'description': 'Latest industry best practices and methodologies for business development.',
        'url': 'https://example.com/best-practices',
        'relevance': 0.87,
      },
      {
        'title': 'Competitive Intelligence Report',
        'description': 'Detailed analysis of key competitors and market positioning strategies.',
        'url': 'https://example.com/competitive-intel',
        'relevance': 0.92,
      },
    ];
  }

  /// Generate generic search results
  List<Map<String, dynamic>> _generateGenericResults(String query) {
    return [
      {
        'title': 'Comprehensive Guide: $query',
        'description': 'Detailed information and resources related to your query with expert insights.',
        'url': 'https://example.com/guide-${query.replaceAll(' ', '-')}',
        'relevance': 0.88,
      },
      {
        'title': 'Latest Updates on $query',
        'description': 'Recent developments and news in the field with current information.',
        'url': 'https://example.com/updates-${query.replaceAll(' ', '-')}',
        'relevance': 0.82,
      },
      {
        'title': 'Expert Recommendations: $query',
        'description': 'Professional recommendations and tips from industry experts.',
        'url': 'https://example.com/recommendations-${query.replaceAll(' ', '-')}',
        'relevance': 0.85,
      },
    ];
  }

  /// Simulate API call to external service
  Future<Map<String, dynamic>> simulateApiCall(String endpoint, Map<String, dynamic> parameters) async {
    // Simulate network delay
    await Future.delayed(Duration(milliseconds: 300 + _random.nextInt(700)));

    // Simulate different API responses based on endpoint
    switch (endpoint) {
      case '/hotels/search':
        return _simulateHotelSearch(parameters);
      case '/flights/search':
        return _simulateFlightSearch(parameters);
      case '/weather/current':
        return _simulateWeatherData(parameters);
      case '/currency/convert':
        return _simulateCurrencyConversion(parameters);
      default:
        return {
          'status': 'success',
          'data': 'API call completed successfully',
          'timestamp': DateTime.now().toIso8601String(),
        };
    }
  }

  /// Simulate hotel search API
  Map<String, dynamic> _simulateHotelSearch(Map<String, dynamic> params) {
    final location = params['location'] as String? ?? 'Chennai';
    final checkIn = params['check_in'] as String? ?? DateTime.now().toIso8601String();
    final guests = params['guests'] as int? ?? 2;

    return {
      'status': 'success',
      'data': {
        'hotels': [
          {
            'id': 'hotel_001',
            'name': 'Taj Coromandel',
            'location': location,
            'rating': 4.8,
            'price_per_night': 8500,
            'amenities': ['WiFi', 'Pool', 'Spa', 'Restaurant'],
            'availability': true,
          },
          {
            'id': 'hotel_002',
            'name': 'ITC Grand Chola',
            'location': location,
            'rating': 4.6,
            'price_per_night': 6500,
            'amenities': ['WiFi', 'Gym', 'Business Center', 'Restaurant'],
            'availability': true,
          },
          {
            'id': 'hotel_003',
            'name': 'Radisson Blu',
            'location': location,
            'rating': 4.3,
            'price_per_night': 4500,
            'amenities': ['WiFi', 'Pool', 'Restaurant'],
            'availability': true,
          },
        ],
        'total_results': 3,
        'search_params': {
          'location': location,
          'check_in': checkIn,
          'guests': guests,
        },
      },
    };
  }

  /// Simulate flight search API
  Map<String, dynamic> _simulateFlightSearch(Map<String, dynamic> params) {
    final from = params['from'] as String? ?? 'Mumbai';
    final to = params['to'] as String? ?? 'Chennai';
    final date = params['date'] as String? ?? DateTime.now().add(const Duration(days: 7)).toIso8601String();

    return {
      'status': 'success',
      'data': {
        'flights': [
          {
            'id': 'flight_001',
            'airline': 'Air India',
            'flight_number': 'AI 123',
            'departure': '08:00',
            'arrival': '10:30',
            'duration': '2h 30m',
            'price': 4500,
            'stops': 0,
          },
          {
            'id': 'flight_002',
            'airline': 'IndiGo',
            'flight_number': '6E 456',
            'departure': '14:00',
            'arrival': '16:45',
            'duration': '2h 45m',
            'price': 3800,
            'stops': 0,
          },
          {
            'id': 'flight_003',
            'airline': 'SpiceJet',
            'flight_number': 'SG 789',
            'departure': '19:30',
            'arrival': '22:15',
            'duration': '2h 45m',
            'price': 4200,
            'stops': 0,
          },
        ],
        'total_results': 3,
        'search_params': {
          'from': from,
          'to': to,
          'date': date,
        },
      },
    };
  }

  /// Simulate weather data API
  Map<String, dynamic> _simulateWeatherData(Map<String, dynamic> params) {
    final location = params['location'] as String? ?? 'Chennai';
    
    return {
      'status': 'success',
      'data': {
        'location': location,
        'temperature': 28,
        'condition': 'Partly Cloudy',
        'humidity': 75,
        'wind_speed': 12,
        'forecast': [
          {'day': 'Today', 'high': 32, 'low': 26, 'condition': 'Partly Cloudy'},
          {'day': 'Tomorrow', 'high': 31, 'low': 25, 'condition': 'Sunny'},
          {'day': 'Day After', 'high': 30, 'low': 24, 'condition': 'Light Rain'},
        ],
      },
    };
  }

  /// Simulate currency conversion API
  Map<String, dynamic> _simulateCurrencyConversion(Map<String, dynamic> params) {
    final from = params['from'] as String? ?? 'USD';
    final to = params['to'] as String? ?? 'INR';
    final amount = params['amount'] as double? ?? 100.0;

    // Simulate exchange rates
    final rates = {
      'USD_INR': 83.25,
      'EUR_INR': 90.15,
      'GBP_INR': 105.30,
    };

    final rateKey = '${from}_$to';
    final rate = rates[rateKey] ?? 1.0;
    final convertedAmount = amount * rate;

    return {
      'status': 'success',
      'data': {
        'from_currency': from,
        'to_currency': to,
        'amount': amount,
        'converted_amount': convertedAmount,
        'exchange_rate': rate,
        'timestamp': DateTime.now().toIso8601String(),
      },
    };
  }

  /// Simulate data analysis tool
  Future<Map<String, dynamic>> simulateDataAnalysis(List<Map<String, dynamic>> data) async {
    await Future.delayed(Duration(milliseconds: 800 + _random.nextInt(1200)));

    return {
      'status': 'success',
      'analysis': {
        'total_records': data.length,
        'insights': [
          'Data quality: 95% complete',
          'Key trends identified',
          'Anomalies detected: 2',
          'Recommendations generated',
        ],
        'summary': 'Analysis completed successfully with actionable insights',
      },
    };
  }

  /// Simulate booking confirmation
  Future<Map<String, dynamic>> simulateBooking(Map<String, dynamic> bookingDetails) async {
    await Future.delayed(Duration(milliseconds: 1000 + _random.nextInt(2000)));

    final bookingId = 'BK${_random.nextInt(999999).toString().padLeft(6, '0')}';
    
    return {
      'status': 'success',
      'booking': {
        'id': bookingId,
        'status': 'confirmed',
        'details': bookingDetails,
        'confirmation_code': bookingId,
        'total_amount': bookingDetails['amount'] ?? 0,
        'booking_date': DateTime.now().toIso8601String(),
      },
    };
  }
}
