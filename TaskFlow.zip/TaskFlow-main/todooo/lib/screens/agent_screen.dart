import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/agent_provider.dart';
import '../models/project.dart';
import '../widgets/goal_input_dialog.dart';
import '../widgets/agent_execution_view.dart';
import '../widgets/task_list_view.dart';
import '../widgets/action_timeline.dart';

class AgentScreen extends StatefulWidget {
  const AgentScreen({super.key});

  @override
  State<AgentScreen> createState() => _AgentScreenState();
}

class _AgentScreenState extends State<AgentScreen> with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tasks'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF1F2937),
        elevation: 0,
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.dark,
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: const Color(0xFF3B82F6),
          labelColor: const Color(0xFF3B82F6),
          unselectedLabelColor: const Color(0xFF9CA3AF),
          tabs: const [
            Tab(icon: Icon(Icons.rocket_launch), text: 'Execute'),
            Tab(icon: Icon(Icons.list_alt), text: 'Tasks'),
            Tab(icon: Icon(Icons.timeline), text: 'Timeline'),
          ],
        ),
        actions: [
          Consumer<AgentProvider>(
            builder: (context, agentProvider, child) {
              if (agentProvider.currentProject != null) {
                return IconButton(
                  icon: const Icon(Icons.refresh),
                  onPressed: () => _showClearProjectDialog(context, agentProvider),
                  tooltip: 'Clear Task',
                );
              }
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildExecuteTab(),
          _buildTasksTab(),
          _buildTimelineTab(),
        ],
      ),
    );
  }

  Widget _buildExecuteTab() {
    return Consumer<AgentProvider>(
      builder: (context, agentProvider, child) {
        if (agentProvider.currentProject == null) {
          return _buildGoalInputView(agentProvider);
        } else {
          return _buildExecutionView(agentProvider);
        }
      },
    );
  }

  Widget _buildGoalInputView(AgentProvider agentProvider) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.psychology,
            size: 80,
            color: const Color(0xFF3B82F6).withOpacity(0.7),
          ),
          const SizedBox(height: 24),
          Text(
            'Task Management System',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: const Color(0xFF3B82F6),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Transform your high-level goals into self-driving task plans',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
              color: Colors.grey[600],
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 32),
          _buildExampleGoals(),
          const SizedBox(height: 32),
          ElevatedButton.icon(
            onPressed: () => _showGoalInputDialog(context, agentProvider),
            icon: const Icon(Icons.add),
            label: const Text('Start New Task'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF3B82F6),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildExampleGoals() {
    final examples = [
      'Plan a weekend trip to a beach near Chennai for two people',
      'Research and create a business proposal for a new mobile app',
      'Organize a team building event for 20 people',
      'Plan a home renovation project with budget constraints',
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Example Goals:',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        ...examples.map((example) => Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                Icons.lightbulb_outline,
                size: 16,
                color: const Color(0xFF3B82F6),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  example,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Colors.grey[700],
                  ),
                ),
              ),
            ],
          ),
        )),
      ],
    );
  }

  Widget _buildExecutionView(AgentProvider agentProvider) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildProjectHeader(agentProvider),
          const SizedBox(height: 16),
          _buildProgressCard(agentProvider),
          const SizedBox(height: 16),
          _buildPhaseDescription(agentProvider),
          const SizedBox(height: 16),
          _buildExecutionStats(agentProvider),
          const SizedBox(height: 16),
          const AgentExecutionView(),
        ],
      ),
    );
  }

  Widget _buildProjectHeader(AgentProvider agentProvider) {
    final project = agentProvider.currentProject!;
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.rocket_launch,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    project.title,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getStatusColor(project.status).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _getStatusColor(project.status).withOpacity(0.3)),
                  ),
                  child: Text(
                    project.status.name.toUpperCase(),
                    style: TextStyle(
                      color: _getStatusColor(project.status),
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Original Goal: ${project.originalGoal}',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressCard(AgentProvider agentProvider) {
    final project = agentProvider.currentProject!;
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Progress',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  '${(project.progress * 100).toStringAsFixed(1)}%',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF3B82F6),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            LinearProgressIndicator(
              value: project.progress,
              backgroundColor: Colors.grey[300],
              valueColor: const AlwaysStoppedAnimation<Color>(
                Color(0xFF3B82F6),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatItem('Total', '${project.tasks.length}', Icons.list),
                _buildStatItem('Completed', '${project.completedTasks.length}', Icons.check_circle),
                _buildStatItem('In Progress', '${project.inProgressTasks.length}', Icons.hourglass_empty),
                _buildStatItem('Pending', '${project.pendingTasks.length}', Icons.pending),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon) {
    return Column(
      children: [
        Icon(icon, color: const Color(0xFF3B82F6)),
        const SizedBox(height: 4),
        Text(
          value,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildPhaseDescription(AgentProvider agentProvider) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
              Row(
                children: [
                  Icon(
                    Icons.info_outline,
                    color: const Color(0xFF3B82F6),
                  ),
                const SizedBox(width: 8),
                Text(
                  'Current Phase',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              agentProvider.getCurrentPhaseDescription(),
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExecutionStats(AgentProvider agentProvider) {
    final stats = agentProvider.getExecutionStats();
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
              Row(
                children: [
                  Icon(
                    Icons.analytics,
                    color: const Color(0xFF3B82F6),
                  ),
                const SizedBox(width: 8),
                Text(
                  'Execution Statistics',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatItem('Actions', '${stats['total_actions']}', Icons.play_arrow),
                _buildStatItem('Success Rate', '${(stats['success_rate'] * 100).toStringAsFixed(1)}%', Icons.trending_up),
                _buildStatItem('Failed', '${stats['failed_actions']}', Icons.error_outline),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTasksTab() {
    return Consumer<AgentProvider>(
      builder: (context, agentProvider, child) {
        if (agentProvider.currentProject == null) {
          return const Center(
            child: Text('No active project. Start by creating a new goal.'),
          );
        }
        return const TaskListView();
      },
    );
  }

  Widget _buildTimelineTab() {
    return Consumer<AgentProvider>(
      builder: (context, agentProvider, child) {
        if (agentProvider.currentProject == null) {
          return const Center(
            child: Text('No active project. Start by creating a new goal.'),
          );
        }
        return const ActionTimeline();
      },
    );
  }

  Color _getStatusColor(ProjectStatus status) {
    switch (status) {
      case ProjectStatus.planning:
        return Colors.blue;
      case ProjectStatus.active:
        return Colors.green;
      case ProjectStatus.paused:
        return Colors.orange;
      case ProjectStatus.completed:
        return Colors.purple;
      case ProjectStatus.cancelled:
        return Colors.red;
    }
  }

  void _showGoalInputDialog(BuildContext context, AgentProvider agentProvider) {
    showDialog(
      context: context,
      builder: (context) => GoalInputDialog(
        onGoalSubmitted: (goal) {
          agentProvider.executeGoal(goal);
          _tabController.animateTo(0); // Switch to execute tab
        },
      ),
    );
  }

  void _showClearProjectDialog(BuildContext context, AgentProvider agentProvider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Current Project'),
        content: const Text('Are you sure you want to clear the current project? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              agentProvider.clearProject();
              Navigator.of(context).pop();
            },
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }
}
