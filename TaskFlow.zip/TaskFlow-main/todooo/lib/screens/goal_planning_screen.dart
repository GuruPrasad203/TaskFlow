import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:animations/animations.dart';
import '../main.dart';

class GoalPlanningScreen extends StatefulWidget {
  final String userName;
  final String userEmail;

  const GoalPlanningScreen({
    super.key,
    required this.userName,
    required this.userEmail,
  });

  @override
  State<GoalPlanningScreen> createState() => _GoalPlanningScreenState();
}

class _GoalPlanningScreenState extends State<GoalPlanningScreen> {
  final TextEditingController _goalController = TextEditingController();
  final List<TaskItem> _tasks = [];

  @override
  void dispose() {
    _goalController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text('Plan Your Goal'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF1F2937),
        elevation: 0,
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.dark,
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Welcome Section
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: const Color(0xFF3B82F6).withOpacity(0.1),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.rocket_launch,
                            color: Color(0xFF3B82F6),
                            size: 24,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Welcome, ${widget.userName}!',
                                style: GoogleFonts.inter(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: const Color(0xFF1F2937),
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Let\'s break down your goal into actionable tasks',
                                style: GoogleFonts.inter(
                                  fontSize: 14,
                                  color: const Color(0xFF6B7280),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // Goal Input Section
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'What\'s your goal?',
                      style: GoogleFonts.inter(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF1F2937),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _goalController,
                      decoration: InputDecoration(
                        hintText: 'e.g., Plan a weekend trip to a beach near Chennai',
                        hintStyle: GoogleFonts.inter(
                          color: const Color(0xFF9CA3AF),
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(
                            color: Color(0xFFE5E7EB),
                          ),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(
                            color: Color(0xFFE5E7EB),
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(
                            color: Color(0xFF3B82F6),
                            width: 2,
                          ),
                        ),
                        filled: true,
                        fillColor: const Color(0xFFF9FAFB),
                      ),
                      style: GoogleFonts.inter(
                        fontSize: 16,
                        color: const Color(0xFF1F2937),
                      ),
                      maxLines: 2,
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _generateTasks,
                        icon: const Icon(Icons.auto_awesome, color: Colors.white),
                        label: Text(
                          'Generate Tasks',
                          style: GoogleFonts.inter(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF3B82F6),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              if (_tasks.isNotEmpty) ...[
                const SizedBox(height: 24),

                // Tasks Section
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 20,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            'Generated Tasks',
                            style: GoogleFonts.inter(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: const Color(0xFF1F2937),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: const Color(0xFF3B82F6).withOpacity(0.1),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              '${_tasks.length} tasks',
                              style: GoogleFonts.inter(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: const Color(0xFF3B82F6),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      ..._tasks.asMap().entries.map((entry) {
                        int index = entry.key;
                        TaskItem task = entry.value;
                        return _buildTaskItem(task, index);
                      }),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // Action Buttons
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _addCustomTask,
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          side: const BorderSide(color: Color(0xFF3B82F6)),
                        ),
                        child: Text(
                          'Add Custom Task',
                          style: GoogleFonts.inter(
                            color: const Color(0xFF3B82F6),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _startGoal,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF10B981),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: Text(
                          'Start Goal',
                          style: GoogleFonts.inter(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTaskItem(TaskItem task, int index) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FAFB),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFE5E7EB),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: task.category.color.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              task.category.icon,
              color: task.category.color,
              size: 16,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  task.title,
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF1F2937),
                  ),
                ),
                if (task.description.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    task.description,
                    style: GoogleFonts.inter(
                      fontSize: 12,
                      color: const Color(0xFF6B7280),
                    ),
                  ),
                ],
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: task.category.color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              task.category.name,
              style: GoogleFonts.inter(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: task.category.color,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _generateTasks() {
    if (_goalController.text.trim().isEmpty) {
      _showSnackBar('Please enter your goal first');
      return;
    }

    // Simulate AI task generation
    Future.delayed(const Duration(seconds: 2), () {
      setState(() {
        _tasks.clear();
        
        // Generate tasks based on common goal patterns
        String goal = _goalController.text.toLowerCase();
        
        if (goal.contains('trip') || goal.contains('travel') || goal.contains('beach')) {
          _tasks.addAll([
            TaskItem(
              title: 'Research and choose destination',
              description: 'Find the best beach spots near Chennai with good reviews',
              category: TaskCategory.research,
            ),
            TaskItem(
              title: 'Book transportation',
              description: 'Arrange cab, bus, or train tickets to the destination',
              category: TaskCategory.transportation,
            ),
            TaskItem(
              title: 'Check accommodation options',
              description: 'Find and book hotels, resorts, or homestays',
              category: TaskCategory.accommodation,
            ),
            TaskItem(
              title: 'Plan budget and expenses',
              description: 'Calculate total cost including travel, stay, food, and activities',
              category: TaskCategory.finance,
            ),
            TaskItem(
              title: 'Pack essential items',
              description: 'Prepare clothes, toiletries, beach gear, and travel documents',
              category: TaskCategory.preparation,
            ),
            TaskItem(
              title: 'Check weather forecast',
              description: 'Monitor weather conditions for the travel dates',
              category: TaskCategory.research,
            ),
            TaskItem(
              title: 'Research local attractions',
              description: 'Find nearby places to visit, restaurants, and activities',
              category: TaskCategory.research,
            ),
            TaskItem(
              title: 'Check crowd density',
              description: 'Research peak times and crowd levels at the destination',
              category: TaskCategory.research,
            ),
          ]);
        } else if (goal.contains('learn') || goal.contains('study')) {
          _tasks.addAll([
            TaskItem(
              title: 'Set learning objectives',
              description: 'Define what you want to achieve and by when',
              category: TaskCategory.planning,
            ),
            TaskItem(
              title: 'Find learning resources',
              description: 'Research courses, books, tutorials, or mentors',
              category: TaskCategory.research,
            ),
            TaskItem(
              title: 'Create study schedule',
              description: 'Plan daily/weekly time blocks for learning',
              category: TaskCategory.planning,
            ),
            TaskItem(
              title: 'Set up learning environment',
              description: 'Prepare study space and necessary tools',
              category: TaskCategory.preparation,
            ),
          ]);
        } else {
          // Generic tasks for any goal
          _tasks.addAll([
            TaskItem(
              title: 'Research and gather information',
              description: 'Learn about the requirements and best practices',
              category: TaskCategory.research,
            ),
            TaskItem(
              title: 'Create detailed plan',
              description: 'Break down the goal into smaller milestones',
              category: TaskCategory.planning,
            ),
            TaskItem(
              title: 'Gather necessary resources',
              description: 'Collect tools, materials, or support needed',
              category: TaskCategory.preparation,
            ),
            TaskItem(
              title: 'Set timeline and deadlines',
              description: 'Establish realistic timeframes for completion',
              category: TaskCategory.planning,
            ),
          ]);
        }
      });
    });
  }

  void _addCustomTask() {
    showDialog(
      context: context,
      builder: (context) => _CustomTaskDialog(
        onAdd: (task) {
          setState(() {
            _tasks.add(task);
          });
        },
      ),
    );
  }

  void _startGoal() {
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => const MainNavigationScreen(),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return SharedAxisTransition(
            animation: animation,
            secondaryAnimation: secondaryAnimation,
            transitionType: SharedAxisTransitionType.horizontal,
            child: child,
          );
        },
      ),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: const Color(0xFF3B82F6),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }
}

class TaskItem {
  final String title;
  final String description;
  final TaskCategory category;

  TaskItem({
    required this.title,
    required this.description,
    required this.category,
  });
}

class TaskCategory {
  final String name;
  final IconData icon;
  final Color color;

  const TaskCategory({
    required this.name,
    required this.icon,
    required this.color,
  });

  static const research = TaskCategory(
    name: 'Research',
    icon: Icons.search,
    color: Color(0xFF3B82F6),
  );

  static const planning = TaskCategory(
    name: 'Planning',
    icon: Icons.assignment,
    color: Color(0xFF8B5CF6),
  );

  static const preparation = TaskCategory(
    name: 'Preparation',
    icon: Icons.build,
    color: Color(0xFFF59E0B),
  );

  static const transportation = TaskCategory(
    name: 'Transport',
    icon: Icons.directions_car,
    color: Color(0xFF10B981),
  );

  static const accommodation = TaskCategory(
    name: 'Accommodation',
    icon: Icons.hotel,
    color: Color(0xFFEF4444),
  );

  static const finance = TaskCategory(
    name: 'Finance',
    icon: Icons.attach_money,
    color: Color(0xFF06B6D4),
  );
}

class _CustomTaskDialog extends StatefulWidget {
  final Function(TaskItem) onAdd;

  const _CustomTaskDialog({required this.onAdd});

  @override
  State<_CustomTaskDialog> createState() => _CustomTaskDialogState();
}

class _CustomTaskDialogState extends State<_CustomTaskDialog> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  TaskCategory _selectedCategory = TaskCategory.planning;

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        'Add Custom Task',
        style: GoogleFonts.inter(fontWeight: FontWeight.bold),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _titleController,
            decoration: InputDecoration(
              labelText: 'Task Title',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _descriptionController,
            decoration: InputDecoration(
              labelText: 'Description (optional)',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            maxLines: 2,
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<TaskCategory>(
            value: _selectedCategory,
            decoration: InputDecoration(
              labelText: 'Category',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            items: const [
              DropdownMenuItem(value: TaskCategory.research, child: Text('Research')),
              DropdownMenuItem(value: TaskCategory.planning, child: Text('Planning')),
              DropdownMenuItem(value: TaskCategory.preparation, child: Text('Preparation')),
              DropdownMenuItem(value: TaskCategory.transportation, child: Text('Transportation')),
              DropdownMenuItem(value: TaskCategory.accommodation, child: Text('Accommodation')),
              DropdownMenuItem(value: TaskCategory.finance, child: Text('Finance')),
            ],
            onChanged: (value) {
              setState(() {
                _selectedCategory = value!;
              });
            },
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            if (_titleController.text.trim().isNotEmpty) {
              widget.onAdd(TaskItem(
                title: _titleController.text.trim(),
                description: _descriptionController.text.trim(),
                category: _selectedCategory,
              ));
              Navigator.pop(context);
            }
          },
          child: const Text('Add Task'),
        ),
      ],
    );
  }
}
