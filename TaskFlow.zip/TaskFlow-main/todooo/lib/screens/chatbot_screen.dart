import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../services/backend_service.dart';
import '../providers/user_provider.dart';

class ChatbotScreen extends StatefulWidget {
  const ChatbotScreen({super.key});

  @override
  State<ChatbotScreen> createState() => _ChatbotScreenState();
}

class _ChatbotScreenState extends State<ChatbotScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<ChatMessage> _messages = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _addWelcomeMessage();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _addWelcomeMessage() {
    _messages.add(ChatMessage(
      text: "🌍 Welcome to Smart Trip Planner!\n\n"
          "I'll help you plan the perfect trip with:\n"
          "✅ Budget-friendly hotels near attractions\n"
          "✅ Must-try local food recommendations\n"
          "✅ Weather information\n"
          "✅ Essential items to pack\n"
          "✅ Complete itinerary\n\n"
          "Tell me: Where do you want to go and what's your budget?\n"
          "Example: \"Plan a 2-day Chennai trip with ₹15,000\"",
      isUser: false,
      timestamp: DateTime.now(),
    ));
  }

  Future<void> _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty || _isLoading) return;

    // Add user message
    setState(() {
      _messages.add(ChatMessage(
        text: message,
        isUser: true,
        timestamp: DateTime.now(),
      ));
      _isLoading = true;
    });

    _messageController.clear();
    _scrollToBottom();

    try {
      // Get user token from UserProvider
      final userProvider = Provider.of<UserProvider>(context, listen: false);
      final user = userProvider.currentUser;
      
      if (user?.token == null) {
        setState(() {
          _isLoading = false;
        });
        
        _messages.add(ChatMessage(
          text: "Please log in to use the chatbot. You need to be authenticated to chat with me.",
          isUser: false,
          timestamp: DateTime.now(),
        ));
        _scrollToBottom();
        return;
      }

      // Check if this is a travel planning request
      final isTravelRequest = _isTravelPlanningRequest(message);
      
      Map<String, dynamic> result;
      if (isTravelRequest) {
        // Use travel planning endpoint for structured responses
        result = await BackendService.sendTravelPlanMessage(user!.token!, message);
      } else {
        // Use general chat endpoint for conversational responses
        result = await BackendService.sendChatMessage(user!.token!, message);
      }

      setState(() {
        _isLoading = false;
      });

      if (result['success']) {
        String responseText;
        Map<String, dynamic>? travelPlanData;
        
        if (isTravelRequest && result['structuredResponse'] != null) {
          // Store the full structured data
          travelPlanData = result['structuredResponse'];
          
          // Format structured travel plan response
          final structured = result['structuredResponse'];
          responseText = "${structured['acknowledgment']}\n\n";
          
          if (structured['destination'] != null) {
            responseText += "📍 **Destination**: ${structured['destination']}\n";
          }
          if (structured['duration'] != null) {
            responseText += "📅 **Duration**: ${structured['duration']}\n";
          }
          if (structured['budget'] != null) {
            responseText += "💰 **Budget**: ${structured['budget']}\n";
          }
          
          // Budget Breakdown
          if (structured['budgetBreakdown'] != null) {
            responseText += "\n� **Budget Breakdown**:\n";
            final breakdown = structured['budgetBreakdown'];
            if (breakdown['accommodation'] != null) {
              responseText += "🏨 Accommodation: ${breakdown['accommodation']}\n";
            }
            if (breakdown['food'] != null) {
              responseText += "🍽️ Food: ${breakdown['food']}\n";
            }
            if (breakdown['transport'] != null) {
              responseText += "🚗 Transport: ${breakdown['transport']}\n";
            }
            if (breakdown['activities'] != null) {
              responseText += "🎯 Activities: ${breakdown['activities']}\n";
            }
            if (breakdown['miscellaneous'] != null) {
              responseText += "🛍️ Miscellaneous: ${breakdown['miscellaneous']}\n";
            }
          }
          
          if (structured['highlights'] != null && structured['highlights'].isNotEmpty) {
            responseText += "\n🌟 **Highlights**:\n";
            for (String highlight in structured['highlights']) {
              responseText += "• $highlight\n";
            }
          }
          
          if (structured['recommendations'] != null) {
            final recs = structured['recommendations'];
            responseText += "\n💡 **Recommendations**:\n";
            if (recs['accommodation'] != null) {
              responseText += "🏨 **Accommodation**: ${recs['accommodation']}\n";
            }
            if (recs['transportation'] != null) {
              responseText += "🚗 **Transportation**: ${recs['transportation']}\n";
            }
            if (recs['activities'] != null && recs['activities'].isNotEmpty) {
              responseText += "🎯 **Activities**:\n";
              for (String activity in recs['activities']) {
                responseText += "• $activity\n";
              }
            }
          }
          
          if (structured['nextSteps'] != null && structured['nextSteps'].isNotEmpty) {
            responseText += "\n📋 **Next Steps**:\n";
            for (String step in structured['nextSteps']) {
              responseText += "• $step\n";
            }
          }
        } else {
          // Use direct response for general chat
          responseText = result['response'] ?? result['fallback'] ?? "I'm here to help with your travel planning!";
        }

        _messages.add(ChatMessage(
          text: responseText,
          isUser: false,
          timestamp: DateTime.now(),
          travelPlan: travelPlanData, // Include structured travel data
          model: result['model'],
        ));
      } else {
        String errorMessage = result['error'] ?? 'Unknown error occurred';
        if (errorMessage.contains('Authentication') || errorMessage.contains('token')) {
          errorMessage = "Authentication required. Please log in to use the chatbot.";
        } else if (errorMessage.contains('Ollama') || errorMessage.contains('Phi3')) {
          errorMessage = "The AI model is currently unavailable. Please try again later.";
        }
        
        _messages.add(ChatMessage(
          text: "Sorry, I encountered an error: $errorMessage\n\nPlease try again or contact support if the issue persists.",
          isUser: false,
          timestamp: DateTime.now(),
        ));
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });

      _messages.add(ChatMessage(
        text: "I'm having trouble connecting to the server. Please check your internet connection and try again.\n\nError: $e",
        isUser: false,
        timestamp: DateTime.now(),
      ));
    }

    _scrollToBottom();
  }

  bool _isTravelPlanningRequest(String message) {
    final lowerMessage = message.toLowerCase();
    final travelKeywords = [
      'plan', 'trip', 'travel', 'vacation', 'holiday', 'itinerary',
      'destination', 'visit', 'go to', 'explore', 'tour', 'journey',
      'budget', 'cost', 'days', 'nights', 'accommodation', 'hotel',
      'flight', 'transport', 'activities', 'sightseeing'
    ];
    
    return travelKeywords.any((keyword) => lowerMessage.contains(keyword));
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Travel Assistant'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF1F2937),
        elevation: 0,
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.dark,
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.help_outline),
            onPressed: _showHelpDialog,
          ),
        ],
      ),
      body: Column(
        children: [
          // Chat messages
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length + (_isLoading ? 1 : 0),
              itemBuilder: (context, index) {
                if (index == _messages.length && _isLoading) {
                  return _buildTypingIndicator();
                }
                return _buildMessageBubble(_messages[index]);
              },
            ),
          ),
          
          // Input area
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border(
                top: BorderSide(
                  color: Colors.grey.withOpacity(0.2),
                  width: 1,
                ),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8FAFC),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(
                        color: Colors.grey.withOpacity(0.3),
                        width: 1,
                      ),
                    ),
                    child: TextField(
                      controller: _messageController,
                      decoration: InputDecoration(
                        hintText: 'Ask me to plan a trip...',
                        hintStyle: GoogleFonts.inter(
                          color: const Color(0xFF9CA3AF),
                          fontSize: 14,
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                      ),
                      maxLines: null,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF3B82F6), Color(0xFF1E40AF)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: _isLoading ? null : _sendMessage,
                      borderRadius: BorderRadius.circular(24),
                      child: Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: _isLoading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                ),
                              )
                            : const Icon(
                                Icons.send,
                                color: Colors.white,
                                size: 20,
                              ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage message) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Row(
        mainAxisAlignment: message.isUser 
            ? MainAxisAlignment.end 
            : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!message.isUser) ...[
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF3B82F6), Color(0xFF1E40AF)],
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(
                Icons.smart_toy,
                color: Colors.white,
                size: 18,
              ),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.75,
              ),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: message.isUser 
                    ? const Color(0xFF3B82F6)
                    : Colors.white,
                borderRadius: BorderRadius.circular(16).copyWith(
                  bottomLeft: message.isUser 
                      ? const Radius.circular(16)
                      : const Radius.circular(4),
                  bottomRight: message.isUser 
                      ? const Radius.circular(4)
                      : const Radius.circular(16),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    message.text,
                    style: GoogleFonts.inter(
                      color: message.isUser 
                          ? Colors.white
                          : const Color(0xFF1F2937),
                      fontSize: 14,
                      height: 1.4,
                    ),
                  ),
                  if (message.goalData != null) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: message.isUser 
                            ? Colors.white.withOpacity(0.1)
                            : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.check_circle,
                            color: message.isUser 
                                ? Colors.white
                                : const Color(0xFF10B981),
                            size: 16,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Goal created successfully',
                            style: GoogleFonts.inter(
                              color: message.isUser 
                                  ? Colors.white
                                  : const Color(0xFF10B981),
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          if (message.isUser) ...[
            const SizedBox(width: 8),
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: const Color(0xFFE5E7EB),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(
                Icons.person,
                color: Color(0xFF6B7280),
                size: 18,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTypingIndicator() {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF3B82F6), Color(0xFF1E40AF)],
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(
              Icons.smart_toy,
              color: Colors.white,
              size: 18,
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16).copyWith(
                bottomLeft: const Radius.circular(4),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildTypingDot(0),
                const SizedBox(width: 4),
                _buildTypingDot(1),
                const SizedBox(width: 4),
                _buildTypingDot(2),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTypingDot(int index) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 600),
      builder: (context, value, child) {
        final delay = index * 0.2;
        final animationValue = (value - delay).clamp(0.0, 1.0);
        final opacity = (animationValue * 2 - 1).abs();
        
        return Container(
          width: 6,
          height: 6,
          decoration: BoxDecoration(
            color: const Color(0xFF3B82F6).withOpacity(opacity),
            shape: BoxShape.circle,
          ),
        );
      },
    );
  }

  void _showHelpDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'How to use the AI Travel Assistant',
          style: GoogleFonts.inter(fontWeight: FontWeight.w600),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'I can help you plan amazing trips! Here are some examples:',
              style: GoogleFonts.inter(fontSize: 14),
            ),
            const SizedBox(height: 12),
            _buildExampleChip('Plan a 5-day trip to Goa with ₹50,000 budget'),
            _buildExampleChip('Weekend getaway to Shimla for 2 people'),
            _buildExampleChip('Adventure trip to Manali with trekking'),
            _buildExampleChip('Romantic honeymoon in Kerala'),
            const SizedBox(height: 12),
            Text(
              'I\'ll create a detailed travel plan with tasks, budget estimates, and itinerary suggestions!',
              style: GoogleFonts.inter(
                fontSize: 12,
                color: const Color(0xFF6B7280),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'Got it!',
              style: GoogleFonts.inter(
                color: const Color(0xFF3B82F6),
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildExampleChip(String text) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFFF3F4F6),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        text,
        style: GoogleFonts.inter(
          fontSize: 12,
          color: const Color(0xFF374151),
        ),
      ),
    );
  }
}

class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;
  final Map<String, dynamic>? goalData;
  final Map<String, dynamic>? travelPlan; // New field for structured travel plan
  final String? model;

  ChatMessage({
    required this.text,
    required this.isUser,
    required this.timestamp,
    this.goalData,
    this.travelPlan,
    this.model,
  });
}
