import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/agent_provider.dart';

class ActionTimeline extends StatelessWidget {
  const ActionTimeline({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AgentProvider>(
      builder: (context, agentProvider, child) {
        final actions = agentProvider.actions;
        
        if (actions.isEmpty) {
          return const Center(
            child: Text('No actions recorded yet'),
          );
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTimelineHeader(context, actions),
              const SizedBox(height: 16),
              _buildTimeline(context, actions),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTimelineHeader(BuildContext context, List<dynamic> actions) {
    final stats = _calculateStats(actions);
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Action Timeline',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatItem('Total', '${stats['total']}', Icons.play_arrow, Colors.blue),
                _buildStatItem('Completed', '${stats['completed']}', Icons.check_circle, Colors.green),
                _buildStatItem('Failed', '${stats['failed']}', Icons.error, Colors.red),
                _buildStatItem('Executing', '${stats['executing']}', Icons.hourglass_empty, Colors.orange),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: color,
            fontSize: 16,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildTimeline(BuildContext context, List<dynamic> actions) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: actions.length,
      itemBuilder: (context, index) {
        final action = actions[index];
        final isLast = index == actions.length - 1;
        
        return _buildTimelineItem(context, action, isLast);
      },
    );
  }

  Widget _buildTimelineItem(BuildContext context, dynamic action, bool isLast) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildTimelineIndicator(context, action, isLast),
        const SizedBox(width: 16),
        Expanded(
          child: _buildActionCard(context, action),
        ),
      ],
    );
  }

  Widget _buildTimelineIndicator(BuildContext context, dynamic action, bool isLast) {
    return Column(
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _getStatusColor(action.status),
            border: Border.all(
              color: Colors.white,
              width: 2,
            ),
          ),
        ),
        if (!isLast)
          Container(
            width: 2,
            height: 60,
            color: Colors.grey[300],
            margin: const EdgeInsets.only(top: 4),
          ),
      ],
    );
  }

  Widget _buildActionCard(BuildContext context, dynamic action) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _getActionIcon(action.type),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    action.description,
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                _getStatusChip(action.status),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Text(
                  _formatTime(action.createdAt),
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.grey[600],
                  ),
                ),
                if (action.startedAt != null) ...[
                  const SizedBox(width: 16),
                  Text(
                    'Started: ${_formatTime(action.startedAt)}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey[600],
                    ),
                  ),
                ],
                if (action.completedAt != null) ...[
                  const SizedBox(width: 16),
                  Text(
                    'Completed: ${_formatTime(action.completedAt)}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ],
            ),
            if (action.executionTime != null) ...[
              const SizedBox(height: 4),
              Text(
                'Duration: ${_formatDuration(action.executionTime)}',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Colors.grey[600],
                ),
              ),
            ],
            if (action.result != null) ...[
              const SizedBox(height: 12),
              _buildResultSection(context, action.result),
            ],
            if (action.error != null) ...[
              const SizedBox(height: 12),
              _buildErrorSection(context, action.error),
            ],
            if (action.parameters.isNotEmpty) ...[
              const SizedBox(height: 12),
              _buildParametersSection(context, action.parameters),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildResultSection(BuildContext context, dynamic result) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.green[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.green[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.check_circle, color: Colors.green[700], size: 16),
              const SizedBox(width: 8),
              Text(
                'Result',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Colors.green[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            _formatResult(result),
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Colors.green[800],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorSection(BuildContext context, String error) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.red[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.red[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.error, color: Colors.red[700], size: 16),
              const SizedBox(width: 8),
              Text(
                'Error',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Colors.red[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            error,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Colors.red[800],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildParametersSection(BuildContext context, Map<String, dynamic> parameters) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.blue[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.blue[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.settings, color: Colors.blue[700], size: 16),
              const SizedBox(width: 8),
              Text(
                'Parameters',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Colors.blue[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ...parameters.entries.map((entry) => Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: 80,
                  child: Text(
                    '${entry.key}:',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Colors.blue[800],
                    ),
                  ),
                ),
                Expanded(
                  child: Text(
                    entry.value.toString(),
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.blue[800],
                    ),
                  ),
                ),
              ],
            ),
          )),
        ],
      ),
    );
  }

  Color _getStatusColor(dynamic status) {
    switch (status.toString()) {
      case 'ActionStatus.pending':
        return Colors.grey;
      case 'ActionStatus.executing':
        return Colors.blue;
      case 'ActionStatus.completed':
        return Colors.green;
      case 'ActionStatus.failed':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  Widget _getActionIcon(dynamic type) {
    IconData icon;
    Color color;
    
    switch (type.toString()) {
      case 'ActionType.webSearch':
        icon = Icons.search;
        color = Colors.blue;
        break;
      case 'ActionType.dataAnalysis':
        icon = Icons.analytics;
        color = Colors.purple;
        break;
      case 'ActionType.taskCreation':
        icon = Icons.add_task;
        color = Colors.green;
        break;
      case 'ActionType.taskUpdate':
        icon = Icons.update;
        color = Colors.orange;
        break;
      case 'ActionType.contextUpdate':
        icon = Icons.info;
        color = Colors.teal;
        break;
      case 'ActionType.decisionMaking':
        icon = Icons.psychology;
        color = Colors.indigo;
        break;
      case 'ActionType.planning':
        icon = Icons.rocket_launch;
        color = Colors.red;
        break;
      default:
        icon = Icons.help;
        color = Colors.grey;
    }
    
    return Icon(icon, size: 20, color: color);
  }

  Widget _getStatusChip(dynamic status) {
    Color color;
    String label;
    
    switch (status.toString()) {
      case 'ActionStatus.pending':
        color = Colors.grey;
        label = 'Pending';
        break;
      case 'ActionStatus.executing':
        color = Colors.blue;
        label = 'Executing';
        break;
      case 'ActionStatus.completed':
        color = Colors.green;
        label = 'Completed';
        break;
      case 'ActionStatus.failed':
        color = Colors.red;
        label = 'Failed';
        break;
      default:
        color = Colors.grey;
        label = 'Unknown';
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final difference = now.difference(time);
    
    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }

  String _formatDuration(Duration duration) {
    if (duration.inMinutes < 1) {
      return '${duration.inSeconds}s';
    } else if (duration.inHours < 1) {
      return '${duration.inMinutes}m';
    } else {
      return '${duration.inHours}h ${duration.inMinutes % 60}m';
    }
  }

  String _formatResult(dynamic result) {
    if (result is Map) {
      return result.entries
          .map((e) => '${e.key}: ${e.value}')
          .join('\n');
    }
    return result.toString();
  }

  Map<String, int> _calculateStats(List<dynamic> actions) {
    int total = actions.length;
    int completed = 0;
    int failed = 0;
    int executing = 0;
    
    for (final action in actions) {
      switch (action.status.toString()) {
        case 'ActionStatus.completed':
          completed++;
          break;
        case 'ActionStatus.failed':
          failed++;
          break;
        case 'ActionStatus.executing':
          executing++;
          break;
      }
    }
    
    return {
      'total': total,
      'completed': completed,
      'failed': failed,
      'executing': executing,
    };
  }
}
