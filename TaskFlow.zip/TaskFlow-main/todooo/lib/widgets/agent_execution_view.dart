import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/agent_provider.dart';
import '../models/agent_action.dart';

class AgentExecutionView extends StatelessWidget {
  const AgentExecutionView({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AgentProvider>(
      builder: (context, agentProvider, child) {
        if (agentProvider.isExecuting) {
          return _buildExecutingView(context, agentProvider);
        } else if (agentProvider.currentProject?.isCompleted == true) {
          return _buildCompletedView(context, agentProvider);
        } else {
          return _buildIdleView(context, agentProvider);
        }
      },
    );
  }

  Widget _buildExecutingView(BuildContext context, AgentProvider agentProvider) {
    final recentActions = agentProvider.recentActions.take(5).toList();
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  'AI Agent is Working...',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            if (recentActions.isNotEmpty) ...[
              Text(
                'Recent Actions:',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              ...recentActions.map((action) => _buildActionItem(context, action)),
            ] else ...[
              const Text('Preparing to execute tasks...'),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildCompletedView(BuildContext context, AgentProvider agentProvider) {
    final stats = agentProvider.getExecutionStats();
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.check_circle,
                  color: Colors.green,
                  size: 24,
                ),
                const SizedBox(width: 12),
                Text(
                  'Project Completed Successfully!',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.green,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _buildCompletionStats(context, stats),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _showProjectSummary(context, agentProvider),
                    icon: const Icon(Icons.summarize),
                    label: const Text('View Summary'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Theme.of(context).colorScheme.primary,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => agentProvider.clearProject(),
                    icon: const Icon(Icons.refresh),
                    label: const Text('New Project'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildIdleView(BuildContext context, AgentProvider agentProvider) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.pause_circle,
                  color: Colors.orange,
                  size: 24,
                ),
                const SizedBox(width: 12),
                Text(
                  'Project Paused',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.orange,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'The project is currently paused. All tasks have been planned and are ready for execution.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionItem(BuildContext context, AgentAction action) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Row(
        children: [
          _getActionIcon(action.type),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  action.description,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    _getStatusChip(action.status),
                    const SizedBox(width: 8),
                    Text(
                      _formatTime(action.createdAt),
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (action.isExecuting)
            SizedBox(
              width: 16,
              height: 16,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(
                  Theme.of(context).colorScheme.primary,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildCompletionStats(BuildContext context, Map<String, dynamic> stats) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.green[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.green[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Execution Summary:',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatItem('Actions', '${stats['total_actions']}', Icons.play_arrow),
              _buildStatItem('Success Rate', '${(stats['success_rate'] * 100).toStringAsFixed(1)}%', Icons.trending_up),
              _buildStatItem('Time', _formatDuration(stats['total_execution_time']), Icons.timer),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon) {
    return Column(
      children: [
        Icon(icon, size: 16, color: Colors.green[700]),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
        ),
        Text(
          label,
          style: TextStyle(fontSize: 10, color: Colors.green[700]),
        ),
      ],
    );
  }

  Widget _getActionIcon(ActionType type) {
    IconData icon;
    Color color;
    
    switch (type) {
      case ActionType.webSearch:
        icon = Icons.search;
        color = Colors.blue;
        break;
      case ActionType.dataAnalysis:
        icon = Icons.analytics;
        color = Colors.purple;
        break;
      case ActionType.taskCreation:
        icon = Icons.add_task;
        color = Colors.green;
        break;
      case ActionType.taskUpdate:
        icon = Icons.update;
        color = Colors.orange;
        break;
      case ActionType.contextUpdate:
        icon = Icons.info;
        color = Colors.teal;
        break;
      case ActionType.decisionMaking:
        icon = Icons.psychology;
        color = Colors.indigo;
        break;
      case ActionType.planning:
        icon = Icons.rocket_launch;
        color = Colors.red;
        break;
    }
    
    return Icon(icon, size: 20, color: color);
  }

  Widget _getStatusChip(ActionStatus status) {
    Color color;
    String label;
    
    switch (status) {
      case ActionStatus.pending:
        color = Colors.grey;
        label = 'Pending';
        break;
      case ActionStatus.executing:
        color = Colors.blue;
        label = 'Executing';
        break;
      case ActionStatus.completed:
        color = Colors.green;
        label = 'Completed';
        break;
      case ActionStatus.failed:
        color = Colors.red;
        label = 'Failed';
        break;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final difference = now.difference(time);
    
    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }

  String _formatDuration(Duration duration) {
    if (duration.inMinutes < 1) {
      return '${duration.inSeconds}s';
    } else if (duration.inHours < 1) {
      return '${duration.inMinutes}m';
    } else {
      return '${duration.inHours}h ${duration.inMinutes % 60}m';
    }
  }

  void _showProjectSummary(BuildContext context, AgentProvider agentProvider) {
    final summary = agentProvider.getProjectSummary();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Project Summary'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildSummaryItem('Title', summary['title']),
              _buildSummaryItem('Original Goal', summary['original_goal']),
              _buildSummaryItem('Status', summary['status']),
              _buildSummaryItem('Progress', '${(summary['progress'] * 100).toStringAsFixed(1)}%'),
              _buildSummaryItem('Total Tasks', '${summary['total_tasks']}'),
              _buildSummaryItem('Completed Tasks', '${summary['completed_tasks']}'),
              _buildSummaryItem('Success Rate', '${(summary['execution_stats']['success_rate'] * 100).toStringAsFixed(1)}%'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }
}
