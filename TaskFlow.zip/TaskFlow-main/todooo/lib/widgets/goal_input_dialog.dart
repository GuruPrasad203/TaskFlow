import 'package:flutter/material.dart';

class GoalInputDialog extends StatefulWidget {
  final Function(String) onGoalSubmitted;

  const GoalInputDialog({
    super.key,
    required this.onGoalSubmitted,
  });

  @override
  State<GoalInputDialog> createState() => _GoalInputDialogState();
}

class _GoalInputDialogState extends State<GoalInputDialog> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    // Auto-focus the text field
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Row(
        children: [
          Icon(
            Icons.psychology,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(width: 8),
          const Text('AI Agent Goal'),
        ],
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Describe your high-level goal and let the AI agent break it down into actionable tasks:',
            style: TextStyle(fontSize: 14, color: Colors.grey),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _controller,
            focusNode: _focusNode,
            maxLines: 4,
            decoration: const InputDecoration(
              hintText: 'e.g., Plan a weekend trip to a beach near Chennai for two people',
              border: OutlineInputBorder(),
              contentPadding: EdgeInsets.all(12),
            ),
            onSubmitted: (_) => _submitGoal(),
          ),
          const SizedBox(height: 16),
          _buildExampleGoals(),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _controller.text.trim().isEmpty ? null : _submitGoal,
          style: ElevatedButton.styleFrom(
            backgroundColor: Theme.of(context).colorScheme.primary,
            foregroundColor: Colors.white,
          ),
          child: const Text('Execute Goal'),
        ),
      ],
    );
  }

  Widget _buildExampleGoals() {
    final examples = [
      'Plan a weekend trip to a beach near Chennai for two people',
      'Research and create a business proposal for a new mobile app',
      'Organize a team building event for 20 people',
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Examples:',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
        ),
        const SizedBox(height: 8),
        ...examples.map((example) => GestureDetector(
          onTap: () {
            _controller.text = example;
            setState(() {});
          },
          child: Container(
            margin: const EdgeInsets.only(bottom: 4),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: Colors.grey[300]!),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.lightbulb_outline,
                  size: 14,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    example,
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        )),
      ],
    );
  }

  void _submitGoal() {
    final goal = _controller.text.trim();
    if (goal.isNotEmpty) {
      widget.onGoalSubmitted(goal);
      Navigator.of(context).pop();
    }
  }
}
