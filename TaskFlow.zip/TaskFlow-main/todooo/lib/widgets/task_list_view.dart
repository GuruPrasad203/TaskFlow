import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/agent_provider.dart';
import '../models/task.dart';

class TaskListView extends StatelessWidget {
  const TaskListView({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AgentProvider>(
      builder: (context, agentProvider, child) {
        final project = agentProvider.currentProject!;
        final tasks = project.tasks;
        
        if (tasks.isEmpty) {
          return const Center(
            child: Text('No tasks available'),
          );
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTaskSummary(context, project),
              const SizedBox(height: 16),
              ...tasks.map((task) => _buildTaskCard(context, task, agentProvider)),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTaskSummary(BuildContext context, project) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Task Overview',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildSummaryItem(
                  context,
                  'Total',
                  '${project.tasks.length}',
                  Icons.list,
                  Colors.blue,
                ),
                _buildSummaryItem(
                  context,
                  'Completed',
                  '${project.completedTasks.length}',
                  Icons.check_circle,
                  Colors.green,
                ),
                _buildSummaryItem(
                  context,
                  'In Progress',
                  '${project.inProgressTasks.length}',
                  Icons.hourglass_empty,
                  Colors.orange,
                ),
                _buildSummaryItem(
                  context,
                  'Pending',
                  '${project.pendingTasks.length}',
                  Icons.pending,
                  Colors.grey,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryItem(BuildContext context, String label, String value, IconData icon, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 24),
        const SizedBox(height: 4),
        Text(
          value,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildTaskCard(BuildContext context, Task task, AgentProvider agentProvider) {
    final taskActions = agentProvider.getActionsForTask(task.id);
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ExpansionTile(
        title: Row(
          children: [
            _getStatusIcon(task.status),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                task.title,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            _getPriorityChip(task.priority),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(
              task.description,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                _getStatusChip(task.status),
                const SizedBox(width: 8),
                Text(
                  _formatTime(task.createdAt),
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.grey[500],
                  ),
                ),
                if (task.completedAt != null) ...[
                  const SizedBox(width: 8),
                  Text(
                    'Completed ${_formatTime(task.completedAt!)}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.green[600],
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (task.result != null) ...[
                  _buildResultSection(context, task.result!),
                  const SizedBox(height: 12),
                ],
                if (task.error != null) ...[
                  _buildErrorSection(context, task.error!),
                  const SizedBox(height: 12),
                ],
                if (task.dependencies.isNotEmpty) ...[
                  _buildDependenciesSection(context, task.dependencies, agentProvider),
                  const SizedBox(height: 12),
                ],
                if (taskActions.isNotEmpty) ...[
                  _buildActionsSection(context, taskActions),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultSection(BuildContext context, String result) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.green[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.green[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.check_circle, color: Colors.green[700], size: 16),
              const SizedBox(width: 8),
              Text(
                'Result',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Colors.green[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            result,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Colors.green[800],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorSection(BuildContext context, String error) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.red[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.red[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.error, color: Colors.red[700], size: 16),
              const SizedBox(width: 8),
              Text(
                'Error',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Colors.red[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            error,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Colors.red[800],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDependenciesSection(BuildContext context, List<String> dependencies, AgentProvider agentProvider) {
    final project = agentProvider.currentProject!;
    
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.blue[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.blue[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.link, color: Colors.blue[700], size: 16),
              const SizedBox(width: 8),
              Text(
                'Dependencies',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Colors.blue[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ...dependencies.map((depId) {
            final depTask = project.tasks.firstWhere(
              (t) => t.id == depId,
              orElse: () => throw Exception('Dependency not found: $depId'),
            );
            return Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Row(
                children: [
                  _getStatusIcon(depTask.status, size: 12),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      depTask.title,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.blue[800],
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildActionsSection(BuildContext context, List<dynamic> actions) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.history, color: Colors.grey[700], size: 16),
              const SizedBox(width: 8),
              Text(
                'Actions (${actions.length})',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ...actions.take(3).map((action) => Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Row(
              children: [
                Icon(
                  _getActionIcon(action.type),
                  size: 12,
                  color: Colors.grey[600],
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    action.description,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey[700],
                    ),
                  ),
                ),
                _getStatusChip(action.status),
              ],
            ),
          )),
          if (actions.length > 3)
            Text(
              '... and ${actions.length - 3} more',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey[500],
                fontStyle: FontStyle.italic,
              ),
            ),
        ],
      ),
    );
  }

  Widget _getStatusIcon(TaskStatus status, {double size = 16}) {
    IconData icon;
    Color color;
    
    switch (status) {
      case TaskStatus.pending:
        icon = Icons.pending;
        color = Colors.grey;
        break;
      case TaskStatus.inProgress:
        icon = Icons.hourglass_empty;
        color = Colors.orange;
        break;
      case TaskStatus.completed:
        icon = Icons.check_circle;
        color = Colors.green;
        break;
      case TaskStatus.failed:
        icon = Icons.error;
        color = Colors.red;
        break;
      case TaskStatus.cancelled:
        icon = Icons.cancel;
        color = Colors.grey;
        break;
    }
    
    return Icon(icon, size: size, color: color);
  }

  Widget _getPriorityChip(TaskPriority priority) {
    Color color;
    String label;
    
    switch (priority) {
      case TaskPriority.low:
        color = Colors.green;
        label = 'Low';
        break;
      case TaskPriority.medium:
        color = Colors.orange;
        label = 'Med';
        break;
      case TaskPriority.high:
        color = Colors.red;
        label = 'High';
        break;
      case TaskPriority.critical:
        color = Colors.purple;
        label = 'Critical';
        break;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _getStatusChip(dynamic status) {
    Color color;
    String label;
    
    switch (status.toString()) {
      case 'ActionStatus.pending':
        color = Colors.grey;
        label = 'Pending';
        break;
      case 'ActionStatus.executing':
        color = Colors.blue;
        label = 'Executing';
        break;
      case 'ActionStatus.completed':
        color = Colors.green;
        label = 'Completed';
        break;
      case 'ActionStatus.failed':
        color = Colors.red;
        label = 'Failed';
        break;
      default:
        color = Colors.grey;
        label = 'Unknown';
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(3),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 8,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  IconData _getActionIcon(dynamic type) {
    switch (type.toString()) {
      case 'ActionType.webSearch':
        return Icons.search;
      case 'ActionType.dataAnalysis':
        return Icons.analytics;
      case 'ActionType.taskCreation':
        return Icons.add_task;
      case 'ActionType.taskUpdate':
        return Icons.update;
      case 'ActionType.contextUpdate':
        return Icons.info;
      case 'ActionType.decisionMaking':
        return Icons.psychology;
      case 'ActionType.planning':
        return Icons.rocket_launch;
      default:
        return Icons.help;
    }
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final difference = now.difference(time);
    
    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }
}
