# 🤖 Chatbot Architecture Explanation

## Overview: You Have TWO AI Systems Working Together!

Your application uses **TWO DIFFERENT AI models** for different purposes:

---

## 1️⃣ **Ollama (Phi3 Model)** - Backend Travel Planning Agent

### What It Does
- **Powers the main chatbot** in your Flutter app
- **Creates structured travel plans** from natural language
- **Decomposes goals into actionable tasks**
- **Executes autonomous agent workflows**

### Where It's Used

#### Backend Files:
- `Backend/src/services/ollamaService.js` - Core Ollama integration
- `Backend/src/controllers/chatController.js` - Chat message handling
- `Backend/src/controllers/chatbotController.js` - Trip planning logic
- `Backend/src/services/agenticAI/freeAgent.js` - AI agent wrapper
- `Backend/src/services/agenticAI/autonomousExecutor.js` - Task execution

#### Frontend Files:
- `todooo/lib/screens/chatbot_screen.dart` - Main chatbot UI
- `todooo/lib/services/backend_service.dart` - API calls to backend

### How It Works
```
User Message → Flutter App → Backend API → Ollama Phi3 → Structured Response → Flutter UI
```

### Example Flow (What You Showed in Screenshot):
1. User types: **"I want to visit Salem, Tamil Nadu for 2 days with ₹15,000 budget"**
2. Flutter sends to: `POST /api/chatbot/trip-plan`
3. Backend calls Ollama Phi3 model
4. Ollama returns structured JSON:
   ```json
   {
     "destination": "Salem, Tamil Nadu",
     "duration": "2 days",
     "budget": "₹15,000",
     "highlights": [
       "Vaishnodevi Temple in Sattur",
       "Gaja Pir temple complex"
     ],
     "recommendations": {
       "accommodation": "Luxury Tamilnadu Beach Resort",
       "transportation": "Budget domestic flights and local trains"
     },
     "nextSteps": [
       "Research the best flight deals",
       "Book accommodation in Salem",
       "Plan day trips including temple visits"
     ]
   }
   ```
5. Flutter formats and displays this beautifully

### Configuration
**Environment Variables** (`Backend/.env` or system):
```env
OLLAMA_MODEL=phi3              # Model to use (default: phi3)
OLLAMA_HOST=http://localhost:11434  # Ollama server URL
```

### Requirements
- **Ollama must be installed** on your machine
- **Phi3 model must be pulled**: `ollama pull phi3`
- **Ollama must be running**: Check with `ollama list`

---

## 2️⃣ **Google Gemini API** - Frontend AI Assistant

### What It Does
- **Generates daily routines** from goal descriptions
- **Creates task breakdowns** for complex goals
- **Provides AI-powered suggestions** in the Flutter app
- **DOES NOT require Ollama** - uses Google's cloud API

### Where It's Used

#### Frontend Files ONLY:
- `todooo/lib/services/gemini_service.dart` - Direct Gemini API calls
- `todooo/lib/screens/goal_planning_screen.dart` - Uses Gemini for routines
- `todooo/lib/providers/agent_provider.dart` - AI agent features

### How It Works
```
Flutter App → Google Gemini API (Cloud) → AI Response → Flutter UI
```

### Example Usage:
When creating a goal, user can click "Generate Routine" and Gemini creates a detailed schedule.

### Configuration
**Dart Define** (when running Flutter):
```bash
flutter run --dart-define=GEMINI_API_KEY=your_google_api_key_here
```

Or set in VS Code `launch.json`:
```json
{
  "args": [
    "--dart-define=GEMINI_API_KEY=AIza..."
  ]
}
```

### Fallback Models (Gemini tries these in order):
1. `gemini-2.5-pro-exp`
2. `gemini-2.0-pro-exp`
3. `gemini-1.5-pro-latest`
4. `gemini-1.5-flash-latest`
5. `gemini-pro`

---

## 🔄 How They Work Together

| Feature | AI Model | Where | Purpose |
|---------|----------|-------|---------|
| **Chatbot Screen** | Ollama Phi3 | Backend | Travel planning conversations |
| **Trip Planning** | Ollama Phi3 | Backend | Structured itinerary generation |
| **Task Decomposition** | Ollama Phi3 | Backend | Break goals into tasks |
| **Autonomous Agent** | Ollama Phi3 | Backend | Execute tasks automatically |
| **Goal Routine Generator** | Google Gemini | Frontend | Create daily schedules |
| **AI Suggestions** | Google Gemini | Frontend | Quick recommendations |

---

## 📊 Current Status

### ✅ What's Working
- **Backend**: Running with Ollama service configured
- **Frontend**: Running on Chrome
- **Chatbot UI**: Connected to backend `/api/chatbot` endpoints

### ⚠️ What Needs Setup

#### For Ollama Chatbot to Work:
1. **Install Ollama** (if not already):
   ```powershell
   # Download from https://ollama.ai/download
   # Or use the installer in Backend/ollama-windows-amd64.exe
   ```

2. **Pull Phi3 Model**:
   ```powershell
   ollama pull phi3
   ```

3. **Start Ollama Server**:
   ```powershell
   ollama serve
   # Should run on http://localhost:11434
   ```

4. **Verify It's Working**:
   ```powershell
   # Test Ollama directly
   ollama run phi3 "Tell me about Salem, Tamil Nadu"
   ```

#### For Gemini to Work:
1. **Get API Key**: https://makersuite.google.com/app/apikey
2. **Run Flutter with key**:
   ```powershell
   flutter run --dart-define=GEMINI_API_KEY=AIza...
   ```

---

## 🧪 Testing the Chatbot

### 1. Check Ollama Health
```powershell
# From your machine
curl http://localhost:11434/api/tags

# From backend API
curl http://localhost:4000/api/chatbot/health
```

### 2. Test Travel Planning
```powershell
Invoke-RestMethod -Method Post `
  -Uri 'http://localhost:4000/api/chatbot/trip-plan' `
  -Headers @{ 
    'Content-Type' = 'application/json'
    'Authorization' = 'Bearer YOUR_TOKEN'
  } `
  -Body (@{ 
    message = 'I want to visit Chennai for 3 days with 20000 rupees budget'
  } | ConvertTo-Json)
```

### 3. Test in Flutter App
1. **Login** to the app
2. **Navigate to Chatbot tab** (bottom nav)
3. **Type a travel request**: "Plan a trip to Ooty for 2 days"
4. **Watch backend console** for Ollama processing

---

## 🐛 Troubleshooting

### Chatbot Says "Ollama service is not running"
```powershell
# Check if Ollama is installed
ollama --version

# Start Ollama server
ollama serve

# In another terminal, check if model exists
ollama list
```

### "Failed to send message" in Flutter
1. **Check backend is running**: `http://localhost:4000/health`
2. **Check you're logged in**: Token must be valid
3. **Check backend logs**: Look for Ollama errors
4. **Verify Ollama is responding**: `curl http://localhost:11434/api/tags`

### Gemini API Errors in Flutter
1. **Check API key is set**: `--dart-define=GEMINI_API_KEY=...`
2. **Verify key is valid**: Test at https://makersuite.google.com
3. **Check quota**: Free tier has rate limits

---

## 📝 Key Backend API Endpoints

### Chatbot Routes (`/api/chatbot`)
```javascript
POST /api/chatbot              // General chat (Ollama)
POST /api/chatbot/travel-plan  // Structured travel planning (Ollama)
POST /api/chatbot/trip-plan    // Create goal + tasks from chat (Ollama)
GET  /api/chatbot/health       // Check Ollama status
```

### What Happens Behind the Scenes:

#### 1. `/api/chatbot/trip-plan` (What you're using)
```
Input: "Visit Salem for 2 days with ₹15,000"
   ↓
Ollama Phi3: Interpret request + Generate structured plan
   ↓
Backend: Create Goal in MongoDB
   ↓
Backend: Create Tasks for the goal
   ↓
Backend: Start autonomous execution (if autoExecute=true)
   ↓
Response: Goal + Tasks + Progress snapshot
```

#### 2. Autonomous Execution
The backend agent can automatically:
- Research destinations
- Find hotels
- Calculate distances
- Book recommendations
- Update task statuses

---

## 🎯 Summary

### The Screenshot You Showed:
✅ **That's Ollama Phi3** working through the backend!

The chatbot you're using:
- **Runs on backend** (Node.js)
- **Uses Ollama Phi3 model** (local AI)
- **Creates structured travel plans**
- **Returns formatted responses** to Flutter

### Gemini is Different:
- **Runs in Flutter app** (direct API calls)
- **Used for goal routines**, not travel chat
- **Doesn't talk to backend**
- **Cloud-based** (Google API)

---

## 🚀 Next Steps to Fully Enable Chatbot

1. **Ensure Ollama is running**:
   ```powershell
   ollama serve
   ```

2. **Check Phi3 model exists**:
   ```powershell
   ollama list
   # Should show phi3
   ```

3. **Test from backend**:
   ```powershell
   curl http://localhost:4000/api/chatbot/health
   ```

4. **Use chatbot in Flutter app** - it should work! 🎉

---

Need help setting up Ollama or testing the chatbot? Let me know! 🤖
